package org.d2j.game.model;

import org.d2j.game.game.spells.ISpellLevel;
import org.d2j.game.game.spells.effects.Effect;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 15/12/11
 * Time: 15:54
 * IDE : IntelliJ IDEA
 */
public class SpellLevel implements ISpellLevel {
    private final SpellTemplate template;

    private Collection<Effect> effects;
    private Collection<Effect> criticalEffects;
    private short cost;
    private short minRange, maxRange;
    private short criticRate, criticalFailRate;

    public SpellLevel(SpellTemplate template, short cost, short minRange, short maxRange, short criticRate, short criticalFailRate) {
        this.template = template;
        this.cost = cost;
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.criticRate = criticRate;
        this.criticalFailRate = criticalFailRate;
    }

    @Override
    public SpellTemplate getTemplate() {
        return template;
    }

    @Override
    public Collection<Effect> getEffects() {
        return effects;
    }

    @Override
    public Collection<Effect> getCriticalEffects() {
        return criticalEffects;
    }

    public void setEffects(Collection<Effect> effects) {
        this.effects = effects;
    }

    public void setCriticalEffects(Collection<Effect> criticalEffects) {
        this.criticalEffects = criticalEffects;
    }

    @Override
    public short getCost() {
        return cost;
    }

    @Override
    public short getMinRange() {
        return minRange;
    }

    @Override
    public short getMaxRange() {
        return maxRange;
    }

    @Override
    public short getCriticRate() {
        return criticRate;
    }

    @Override
    public short getCriticalFailRate() {
        return criticalFailRate;
    }
}
