package org.d2j.game.model;

import org.d2j.utils.database.IEntity;

/**
 * User: Blackrush
 * Date: 03/12/11
 * Time: 17:49
 * IDE : IntelliJ IDEA
 */
public class Item implements IEntity<Long> {
    private long id;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public void beforeCreate() {

    }

    @Override
    public void beforeDelete() {

    }

    @Override
    public void onCreated() {

    }

    @Override
    public void onDeleted() {

    }

    @Override
    public void beforeSave() {

    }

    @Override
    public void onSaved() {

    }
}
