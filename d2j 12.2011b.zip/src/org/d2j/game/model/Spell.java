package org.d2j.game.model;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.EndActionTypeEnum;
import org.d2j.common.client.protocol.type.BaseSpellType;
import org.d2j.game.game.fights.*;
import org.d2j.game.game.pathfinding.Pathfinding;
import org.d2j.game.game.spells.ISpell;
import org.d2j.game.game.spells.ISpellLevel;
import org.d2j.game.game.spells.SpellException;
import org.d2j.game.game.spells.effects.Effect;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.utils.Action;
import org.d2j.utils.AppendableAction;
import org.d2j.utils.database.IEntity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: Blackrush
 * Date: 08/12/11
 * Time: 18:03
 * IDE : IntelliJ IDEA
 */
public class Spell implements IEntity<Long>, ISpell {
    public static Collection<BaseSpellType> toBaseSpellType(Collection<Spell> spells){
        List<BaseSpellType> types = new ArrayList<>();
        for (Spell spell : spells){
            types.add(spell.toBaseSpellType());
        }
        return types;
    }

    private long id;
    private Character character;
    private SpellTemplate template;
    private byte position;
    private short level;

    public Spell() {

    }

    public Spell(int id, Character character, SpellTemplate template, byte position, short level) {
        this.id = id;
        this.character = character;
        this.template = template;
        this.position = position;
        this.level = level;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Character getCharacter() {
        return character;
    }

    public void setCharacter(Character character) {
        this.character = character;
    }

    public SpellTemplate getTemplate() {
        return template;
    }

    public void setTemplate(SpellTemplate template) {
        this.template = template;
    }

    public byte getPosition() {
        return position;
    }

    public void setPosition(byte position) {
        this.position = position;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public void addLevel(short level) {
        this.level += level;
    }

    public ISpellLevel getInfos(){
        return template.getLevels().get(level);
    }

    public boolean apply(final FightLog logs, final Fight fight, final IFighter caster, final FightCell target)
            throws FightException
    {
        final ISpellLevel infos = getInfos();
        final int distance = Pathfinding.distanceBetween(caster.getCurrentCell().getPosition(), target.getPosition());

        if (caster.getStatistics().get(CharacteristicType.ActionPoints).getTotal() < infos.getCost()){
            throw new SpellException("Invalid request: not enough AP.");
        }
        else if (distance > infos.getMaxRange() || distance < infos.getMinRange()){
            throw new SpellException("Invalid request: you're too close or too far from the target.");
        }
        else{
            caster.getHandler().notifyRefreshStatistics();
            AppendableAction<IFightHandler> action = new AppendableAction<>(
                    new Action<IFightHandler>(){
                        @Override
                        public void call(IFightHandler obj) throws Exception {
                            obj.notifyStartAction(caster.getId());
                        }
                    }
            );

            boolean critical = false, //todo
                    failure  = false; //todo

            if (failure){
                action.append(new Action<IFightHandler>() {
                    @Override
                    public void call(IFightHandler obj) throws Exception {
                        obj.notifyBasicAction(
                                ActionTypeEnum.SPELL_FAILURE,
                                caster,
                                template.getId()
                        );
                    }
                });
            }
            else{
                action.append(new Action<IFightHandler>() {
                    @Override
                    public void call(IFightHandler obj) throws Exception {
                        obj.notifyCastSpell(
                                caster,
                                Spell.this,
                                target
                        );
                    }
                });

                if (critical){
                    action.append(new Action<IFightHandler>() {
                        @Override
                        public void call(IFightHandler obj) throws Exception {
                            obj.notifyBasicAction(
                                    ActionTypeEnum.SPELL_CRITICAL,
                                    caster,
                                    template.getId()
                            );
                        }
                    });
                }

                ISpellLevel spellLevel = template.getLevels().get(level);

                for (Effect effect : (critical ? spellLevel.getCriticalEffects() : spellLevel.getEffects())){
                    effect.apply(action, caster, target);
                }

                if (target.getCurrentFighter() != null){
                    logs.add(new FightLog.SpellCast(target.getCurrentFighter(), template));
                }
            }

            caster.getStatistics().get(CharacteristicType.ActionPoints).addContext((short) -infos.getCost());

            action.append(new Action<IFightHandler>() {
                @Override
                public void call(IFightHandler obj) throws Exception {
                    obj.notifyBasicAction(
                            ActionTypeEnum.AP_CHANGEMENT,
                            caster,
                            -infos.getCost()
                    );
                    obj.notifyEndAction(EndActionTypeEnum.SPELL, caster);
                }
            });

            fight.foreach(action);

            return !failure && critical;
        }
    }

    public BaseSpellType toBaseSpellType(){
        return new BaseSpellType(
                template.getId(),
                level,
                position >= 0 ? String.valueOf(StringUtil.HASH.charAt(position)) : ""
        );
    }

    @Override
    public void beforeCreate() {
    }

    @Override
    public void beforeDelete() {
    }

    @Override
    public void onCreated() {
    }

    @Override
    public void onDeleted() {
    }

    @Override
    public void beforeSave() {
    }

    @Override
    public void onSaved() {
    }
}
