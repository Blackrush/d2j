package org.d2j.game.repository;

import org.d2j.common.Permissions;
import org.d2j.common.StringUtil;
import org.d2j.game.model.GameAccount;
import org.d2j.utils.database.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 14:44
 * IDE : IntelliJ IDEA
 */
public class AccountRepository extends EntityRepository<GameAccount, Integer> {
    protected final Map<String, Integer> tickets = new HashMap<>();

    public GameAccount createDefault(Integer id, String nickname, String answer, Permissions rights, int community){
        GameAccount account = new GameAccount(
                id,
                nickname,
                answer,
                rights,
                community,
                "i*#$p%" + (rights.ordinal() > Permissions.MEMBER.ordinal() ? "@¤" : ""),
                new Date(),
                "",
                false,
                false
        );

        create(account);

        return account;
    }

    public AccountRepository(EntitiesContext context) {
        super(context);
    }

    @Override
    protected void setNextId(GameAccount entity) {

    }

    @Override
    protected String getCreateQuery(GameAccount entity) {
        return StringUtil.format(
                "INSERT INTO `accounts`(`id`, `nickname`, `answer`, `rights`, `community`) " +
                "VALUES('{0}', '{1}', '{2}', '{3}', '{4}');",
                entity.getId(),
                entity.getNickname(),
                entity.getAnswer(),
                entity.getRights().ordinal(),
                entity.getCommunity()
        );
    }

    @Override
    protected String getDeleteQuery(GameAccount entity) {
        return "DELETE FROM `accounts` WHERE `id`='" + entity.getId() + "';";
    }

    @Override
    protected String getSaveQuery(GameAccount entity) {
        return StringUtil.format(
                "UPDATE `accounts` SET " +
                "`enabledChannels`='{0}', " +
                "`lastConnection`='{1}', " +
                "`lastAddress`='{2}', " +
                "`muted`='{3}', " +
                "`notifyFriendsOnConnect`='{4}' " +
                " WHERE `id`='{5}';",

                entity.getEnabledChannels(),
                StringUtil.MYSQL_DATETIME_FORMATER.format(entity.getLastConnection()),
                entity.getLastAddress(),
                entity.isMuted() ? "1" : "0",
                entity.isNotifyFriendsOnConnect() ? "1" : "0",

                entity.getId()
        );
    }

    @Override
    protected String getLoadQuery() {
        return "SELECT * FROM `accounts`;";
    }

    @Override
    protected String getLoadOneQuery(Integer id) {
        return "SELECT * FROM `accounts` WHERE `id`='" + id + "';";
    }

    @Override
    protected GameAccount loadOne(ResultSet reader) throws SQLException {
        try {
            return new GameAccount(
                reader.getInt("id"),
                reader.getString("nickname"),
                reader.getString("answer"),
                Permissions.valueOf(reader.getInt("rights")),
                reader.getInt("community"),
                reader.getString("enabledChannels"),
                StringUtil.MYSQL_DATETIME_FORMATER.parse(reader.getString("lastConnection")),
                reader.getString("lastAddress"),
                reader.getBoolean("muted"),
                reader.getBoolean("notifyFriendsOnConnect")
            );
        } catch (ParseException e) {
            throw new SQLException(e.getMessage(), e.getCause());
        }
    }

    public void addTicket(String ticket, Integer accountId){
        tickets.put(ticket, accountId);
    }

    public GameAccount findByTicket(String ticket){
        Integer accountId = tickets.get(ticket);

        if (accountId == null)
            return null;
        else
            tickets.remove(ticket);

        return entities.get(accountId);
    }
}
