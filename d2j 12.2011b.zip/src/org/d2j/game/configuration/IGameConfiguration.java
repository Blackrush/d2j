package org.d2j.game.configuration;

import org.d2j.utils.database.ConnectionStringBuilder;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:19
 * IDE : IntelliJ IDEA
 */
public interface IGameConfiguration {
    String getRemoteAddress();  // for clients
    int getRemotePort();        // for clients
    String getSystemAddress();  // for Loginserver
    int getSystemPort();        // for Loginserver

    ConnectionStringBuilder getDynamicConnectionInformations();
    ConnectionStringBuilder getStaticConnectionInformations();
    long getExecutionInterval();
    long getMapsLoadingLimit();

    int getServerId();
    boolean getCharacterNameSuggestionEnabled();
    short getMaxCharactersPerAccount();
    int getDeletionAnswerRequiredLevel();

    short getStartSize();
    short getStartLevel();
    short getStartEnergy();
    int getStartKamas();
    int getStartMapId();
    short getStartCellId();
    int getDefaultMemorizedMapId();
    short getMaxEnergy();

    int getPreparationDelay();
    int getTurnDelay();

    short getSpellStartLevel();

    short getMaxLevelSpell();

    char getCommandPrefix();
}
