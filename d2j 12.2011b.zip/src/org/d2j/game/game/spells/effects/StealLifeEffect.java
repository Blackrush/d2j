package org.d2j.game.game.spells.effects;

import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.SpellEffectsEnum;
import org.d2j.common.random.Dice;
import org.d2j.game.game.fights.FightCell;
import org.d2j.game.game.fights.FightException;
import org.d2j.game.game.fights.IFightHandler;
import org.d2j.game.game.fights.IFighter;
import org.d2j.game.game.spells.ISpellLevel;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.utils.Action;
import org.d2j.utils.AppendableAction;

/**
 * User: Blackrush
 * Date: 19/12/11
 * Time: 18:11
 * IDE : IntelliJ IDEA
 */
public class StealLifeEffect extends Effect {
    private SpellEffectsEnum effect;
    private CharacteristicType characteristic;
    private Dice dice;

    public StealLifeEffect(ISpellLevel infos, SpellEffectsEnum effect, CharacteristicType characteristic) {
        super(infos);

        this.effect = effect;
        this.characteristic = characteristic;
    }

    @Override
    public SpellEffectsEnum getEffectId() {
        return effect;
    }

    @Override
    public void apply(AppendableAction<IFightHandler> action, final IFighter caster, final FightCell targetCell) throws FightException {
        if (targetCell.getCurrentFighter() == null) return;

        final int damage = targetCell.getCurrentFighter()
                                     .getStatistics()
                                     .addLife((short)-DamageEffect.
                                             getEffect(characteristic, caster.getStatistics(), dice)),

                  regen  = caster.getStatistics().addLife((short)(damage / -2));

        action.append(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyBasicAction(
                        ActionTypeEnum.LIFE_CHANGEMENT,
                        caster,
                        (int)targetCell.getCurrentFighter().getId(),
                        damage
                );

                obj.notifyBasicAction(
                        ActionTypeEnum.LIFE_CHANGEMENT,
                        caster,
                        (int)caster.getId(),
                        regen
                );
            }
        });
    }

    @Override
    public int getValue1() {
        return 0;
    }

    @Override
    public void setValue1(int value1) {
    }

    @Override
    public int getValue2() {
        return 0;
    }

    @Override
    public void setValue2(int value2) {
    }

    @Override
    public int getValue3() {
        return 0;
    }

    @Override
    public void setValue3(int value3) {
    }

    @Override
    public int getNbTurns() {
        return 0;
    }

    @Override
    public void setNbTurns(int nbTurns) {
    }

    @Override
    public int getChance() {
        return 0;
    }

    @Override
    public void setChance(int chance) {
    }

    @Override
    public Dice getDice() {
        return dice;
    }

    @Override
    public void setDice(Dice dice) {
        this.dice = dice;
    }
}
