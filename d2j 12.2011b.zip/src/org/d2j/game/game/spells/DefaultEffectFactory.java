package org.d2j.game.game.spells;

import org.d2j.common.client.protocol.enums.SpellEffectsEnum;
import org.d2j.common.random.Dice;
import org.d2j.game.game.spells.effects.*;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.SpellLevel;
import org.d2j.game.model.SpellTemplate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * User: Blackrush
 * Date: 08/12/11
 * Time: 20:26
 * IDE : IntelliJ IDEA
 */
public class DefaultEffectFactory implements IEffectFactory {
    private static final DefaultEffectFactory self = new DefaultEffectFactory();
    public static IEffectFactory getInstance(){
        return self;
    }

    private HashMap<SpellEffectsEnum, EffectMaker> effects = new HashMap<>();

    private DefaultEffectFactory(){}

    @Override
    public ISpellLevel parse(SpellTemplate template, String str) {
        if (str.equals("-1") || str.isEmpty()) return null;

        String[] stats = str.split(",");

        SpellLevel level = new SpellLevel(
                template,
                Integer.getInteger(stats[2].trim(), 6).shortValue(),
                Short.parseShort(stats[3].trim()),
                Short.parseShort(stats[4].trim()),
                Short.parseShort(stats[5].trim()),
                Short.parseShort(stats[6].trim())
        );
        level.setEffects(parseEffects(level, stats[0]));
        level.setCriticalEffects(parseEffects(level, stats[1]));

        return level;
    }

    @Override
    public void load() {
        effects.put(SpellEffectsEnum.Teleport, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new TeleportationEffect(infos);
            }
        });

        effects.put(SpellEffectsEnum.DamageEarth, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new DamageEffect(infos, CharacteristicType.Strength);
            }
        });
        effects.put(SpellEffectsEnum.DamageFire, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new DamageEffect(infos, CharacteristicType.Intelligence);
            }
        });
        effects.put(SpellEffectsEnum.DamageWater, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new DamageEffect(infos, CharacteristicType.Chance);
            }
        });
        effects.put(SpellEffectsEnum.DamageWind, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new DamageEffect(infos, CharacteristicType.Agility);
            }
        });
        effects.put(SpellEffectsEnum.DamageNeutral, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new DamageEffect(infos, CharacteristicType.Strength);
            }
        });

        effects.put(SpellEffectsEnum.StealEarth, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new StealLifeEffect(infos, SpellEffectsEnum.StealEarth, CharacteristicType.Strength);
            }
        });
        effects.put(SpellEffectsEnum.StealFire, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new StealLifeEffect(infos, SpellEffectsEnum.StealFire, CharacteristicType.Intelligence);
            }
        });
        effects.put(SpellEffectsEnum.StealWater, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new StealLifeEffect(infos, SpellEffectsEnum.StealWater, CharacteristicType.Chance);
            }
        });
        effects.put(SpellEffectsEnum.StealWind, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new StealLifeEffect(infos, SpellEffectsEnum.StealWind, CharacteristicType.Agility);
            }
        });
        effects.put(SpellEffectsEnum.StealNeutral, new EffectMaker() {
            @Override
            public Effect make(ISpellLevel infos) {
                return new StealLifeEffect(infos, SpellEffectsEnum.StealNeutral, CharacteristicType.Strength);
            }
        });
    }

    private Collection<Effect> parseEffects(ISpellLevel level, String str){
        List<Effect> effects = new ArrayList<>();

        for (String effectStr : str.split("\\|")){
            if (effectStr.isEmpty() || effectStr.equals("-1")){
                continue;
            }

            String[] args = effectStr.split(";");

            SpellEffectsEnum effectId = SpellEffectsEnum.valueOf(Integer.parseInt(args[0]));
            EffectMaker maker = this.effects.get(effectId);
            if (maker != null){
                Effect effect = maker.make(level);

                effect.setValue1(Integer.parseInt(args[1]));
                effect.setValue2(Integer.parseInt(args[2]));
                effect.setValue3(Integer.parseInt(args[3]));
                if (args.length > 4){
                    effect.setNbTurns(Integer.parseInt(args[4]));
                }
                if (args.length > 5){
                    effect.setChance(Integer.parseInt(args[5]));
                }
                if (args.length > 6){
                    effect.setDice(Dice.parseDice(args[6]));
                }

                effects.add(effect);
            }
        }

        return effects;
    }
}
