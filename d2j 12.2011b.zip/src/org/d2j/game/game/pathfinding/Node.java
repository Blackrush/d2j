package org.d2j.game.game.pathfinding;

import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.game.game.maps.Cell;
import org.d2j.utils.Point;

/**
 * User: Blackrush
 * Date: 26/11/11
 * Time: 20:19
 * IDE : IntelliJ IDEA
 */
public class Node {
    private short id;
    private Node parent;
    private OrientationEnum direction;
    private Point position;
    private boolean walkable;
    private int g, h;

    public Node(short id, Point position) {
        this.id = id;
        this.position = position;
    }

    public Node(short id, Point position, boolean walkable, OrientationEnum direction) {
        this.id = id;
        this.position = position;
        this.walkable = walkable;
        this.direction = direction;
    }

    public Node(Node parent, OrientationEnum direction, Cell cell) {
        this.id = cell.getId();
        this.parent = parent;
        this.direction = direction;
        this.position = cell.getPosition();
        this.walkable = cell.isWalkable();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Node)
            return equals((Node)obj);
        return false;
    }

    @Override
    public int hashCode() {
        return id;
    }

    public boolean equals(Node node){
        if (node == null)
            return false;
        if (node.getId() == id)
            return true;
        return false;
    }

    public short getId() {
        return id;
    }

    public Node getParent() {
        return parent;
    }

    public OrientationEnum getDirection() {
        return direction;
    }

    public Point getPosition() {
        return position;
    }

    public boolean isWalkable() {
        return walkable;
    }

    public int getF(){
        return g + h;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }
}
