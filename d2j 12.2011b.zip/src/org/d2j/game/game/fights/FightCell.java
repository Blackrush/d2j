package org.d2j.game.game.fights;

import com.sun.istack.internal.Nullable;
import org.d2j.common.StringUtil;
import org.d2j.game.game.maps.Cell;
import org.d2j.utils.Point;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: Blackrush
 * Date: 16/11/11
 * Time: 09:28
 * IDE : IntelliJ IDEA
 */
public class FightCell extends Cell {
    public static FightCell[] toFightCell(Cell[] cells, String places){
        FightCell[] fightCells = new FightCell[cells.length];

        for (short i = 0; i < cells.length; ++i){
            fightCells[i] = new FightCell(
                    cells[i].getId(),
                    cells[i].isLineOfSight(),
                    cells[i].getMovementType(),
                    cells[i].getGroundLevel(),
                    cells[i].getGroundSlope(),
                    cells[i].getPosition()
            );
        }

        String[] aPlaces = places.split("\\|");
        for (int teamId = 0; teamId <= 1; ++teamId){
            String bPlaces = aPlaces[teamId];
            FightTeamEnum team = FightTeamEnum.valueOf(teamId);

            for (int i = 0; i < bPlaces.length(); i += 2){
                short cellId = (short) ((StringUtil.HASH.indexOf(bPlaces.charAt(i)) << 6) +
                                        (StringUtil.HASH.indexOf(bPlaces.charAt(i + 1))));
                fightCells[cellId].setStartCell(team);
            }
        }

        return fightCells;
    }

    public static FightCell getFirstAvailableStartCell(FightTeamEnum team, FightCell[] cells){
        for (FightCell cell : cells) {
            if (cell.isAvailable() && cell.getStartCell() == team) {
                return cell;
            }
        }
        return null;
    }

    public static Collection<FightCell> byTeam(FightCell[] cells, FightTeamEnum team){
        if (team == FightTeamEnum.CHALLENGER || team == FightTeamEnum.DEFENDER)
            return null;

        List<FightCell> startCells = new ArrayList<>(cells.length);

        for (FightCell cell : cells){
            if (cell.getStartCell() == team){
                startCells.add(cell);
            }
        }

        return startCells;
    }

    private FightTeamEnum startCell;

    private IFighter currentFighter;

    public FightCell(short id, boolean lineOfSight, MovementType movementType, int groundLevel, int groundSlope, Point position) {
        super(id, lineOfSight, movementType, groundLevel, groundSlope, position);
    }

    public IFighter getCurrentFighter() {
        return currentFighter;
    }

    public void setCurrentFighter(@Nullable IFighter currentFighter) {
        this.currentFighter = currentFighter;
    }

    public boolean isAvailable(){
        return currentFighter == null;
    }

    public FightTeamEnum getStartCell() {
        return startCell;
    }

    public void setStartCell(FightTeamEnum startCell) {
        this.startCell = startCell;
    }

    public boolean isStartCell(){
        return startCell != null &&
              (startCell == FightTeamEnum.CHALLENGER ||
               startCell == FightTeamEnum.DEFENDER);
    }
}
