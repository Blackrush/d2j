package org.d2j.game.game.fights.actions;

import org.d2j.common.client.protocol.enums.EndActionTypeEnum;
import org.d2j.game.game.fights.Fight;
import org.d2j.game.game.fights.FightException;
import org.d2j.game.game.fights.IFightHandler;
import org.d2j.game.game.fights.IFighter;
import org.d2j.game.game.maps.Cell;
import org.d2j.game.game.pathfinding.PathfindingException;
import org.d2j.utils.Action;

/**
 * User: Blackrush
 * Date: 24/11/11
 * Time: 18:03
 * IDE : IntelliJ IDEA
 */
public class PlayerFightMovement extends FightMovement {
    public PlayerFightMovement(Fight fight, IFighter fighter, Cell start, Cell end) throws PathfindingException {
        super(fight, fighter, start, end);
    }

    @Override
    public boolean isNPC() {
        return false;
    }

    @Override
    public void end() throws FightException {
        super.end();

        fight.foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyEndAction(EndActionTypeEnum.MOVEMENT, getFighter());
            }
        });
    }
}
