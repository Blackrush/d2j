package org.d2j.game.game.fights.actions;

import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.game.game.fights.*;
import org.d2j.game.game.maps.Cell;
import org.d2j.game.game.pathfinding.Node;
import org.d2j.game.game.pathfinding.Pathfinding;
import org.d2j.game.game.pathfinding.PathfindingException;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.utils.Action;

import java.util.Collection;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static org.d2j.common.CollectionUtils.last;

/**
 * User: Blackrush
 * Date: 24/11/11
 * Time: 17:57
 * IDE : IntelliJ IDEA
 */
public class FightMovement implements IFightAction {
    public static void move(IFighter fighter, FightCell target){
        fighter.getCurrentCell().setCurrentFighter(null);
        fighter.setCurrentCell(target);
        target.setCurrentFighter(fighter);
    }

    private final Timer timer;
    protected final Fight fight;
    protected final IFighter fighter;
    protected List<Node> nodes;
    protected String path;
    protected short steps;

    public FightMovement(Fight fight, IFighter fighter, Cell start, Cell end) throws PathfindingException {
        this.fight = fight;
        this.fighter = fighter;

        this.nodes = Pathfinding.bestPath(
                this.fight.getMap().getWidth(),
                this.fight.getMap().getHeight(),
                this.fighter.getCurrentOrientation(),
                this.fight.getCells(),
                start,
                end
        );
        this.path = "a" + Cell.encode(fighter.getCurrentCell().getId()) + Cell.encode(nodes);
        this.steps = (short) this.nodes.size();

        this.timer = new Timer();
    }

    public void begin() throws FightException {
        if (steps > fighter.getStatistics().get(CharacteristicType.MovementPoints).getTotal()){
            throw new FightException("Invalid request: not enough MP! " +
                    "(current: " + fighter.getStatistics().get(CharacteristicType.MovementPoints).getTotal() + ", " +
                     "used: " + steps + ")");
        }
        fighter.getStatistics().get(CharacteristicType.MovementPoints).addContext((short) -steps);

        fight.foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyFighterMovement(FightMovement.this);
            }
        });

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    end();
                } catch (FightException e) {
                    e.printStackTrace();
                }
            }
        }, Pathfinding.estimateTime(nodes.size()));
    }

    public void end() throws FightException {
        move(fighter, fight.getCells()[last(nodes).getId()]);

        fight.foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyBasicAction(ActionTypeEnum.MP_CHANGEMENT, fighter, (int) fighter.getId(), -steps);
            }
        });
    }

    @Override
    public IFighter getFighter() {
        return fighter;
    }

    public boolean isNPC() {
        return true;
    }

    public Collection<Node> getNodes() {
        return nodes;
    }

    public String getPath(){
        return path;
    }
}
