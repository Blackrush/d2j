package org.d2j.game.game.fights;

import org.d2j.common.NumUtils;
import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.common.client.protocol.type.BaseFighterType;
import org.d2j.common.client.protocol.type.CharacterFighterType;
import org.d2j.game.game.statistics.IStatistics;
import org.d2j.game.model.Spell;
import org.d2j.game.service.game.GameClient;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * User: Blackrush
 * Date: 16/11/11
 * Time: 09:08
 * IDE : IntelliJ IDEA
 */
public class Fighter implements IFighter {
    public static Collection<BaseFighterType> toBaseFighterType(Collection<IFighter> fighters){
        List<BaseFighterType> types = new ArrayList<>(fighters.size());
        for (IFighter fighter : fighters){
            if (fighter != null)
                types.add(fighter.toBaseFighterType());
        }
        return types;
    }

    private final Fight fight;
    private Team team;
    private final GameClient client;
    private final IFightHandler handler;
    private final FightLog logs;

    private FightCell currentCell;
    private OrientationEnum currentOrientation;
    private boolean ready;
    private IStatistics statistics;

    public Fighter(Fight fight, GameClient client, IFightHandler handler) {
        this.fight = fight;
        this.client = client;
        this.currentOrientation = OrientationEnum.SOUTH_EAST;
        this.handler = handler;
        this.logs = new FightLog();

        this.statistics = client.getCharacter().getStatistics().copy();
    }

    @Override
    public long getId() {
        return client.getCharacter().getId();
    }

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean ready) {
        this.ready = ready;
    }

    public FightCell getCurrentCell() {
        return currentCell;
    }

    public void setCurrentCell(FightCell currentCell) {
        this.currentCell = currentCell;
    }

    public OrientationEnum getCurrentOrientation() {
        return currentOrientation;
    }

    @Override
    public IStatistics getStatistics() {
        return statistics;
    }

    @Override
    public boolean isAlive() {
        return statistics.getLife() > 0;
    }

    public void setCurrentOrientation(OrientationEnum currentOrientation) {
        this.currentOrientation = currentOrientation;
    }

    public IFightHandler getHandler() {
        return handler;
    }

    @Override
    public FightLog getLogs() {
        return logs;
    }

    public HashMap<Integer, Spell> getSpells(){
        return client.getCharacter().getSpells();
    }

    public BaseFighterType toBaseFighterType() {
        return new CharacterFighterType(
                client.getCharacter().getId(),
                client.getCharacter().getName(),
                client.getCharacter().getBreed().getId(),
                client.getCharacter().getSkin(),
                client.getCharacter().getSize(),
                client.getCharacter().getExperience().getLevel(),
                currentCell.getId(),
                currentOrientation,
                statistics.getLife() <= 0,
                statistics,
                client.getCharacter().getGender(),
                NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, false, //todo alignment
                client.getCharacter().getColor1(),
                client.getCharacter().getColor2(),
                client.getCharacter().getColor3(),
                client.getCharacter().getAccessories(),
                client.getCharacter().getStatistics(),
                team.getTeamType()
        );
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
