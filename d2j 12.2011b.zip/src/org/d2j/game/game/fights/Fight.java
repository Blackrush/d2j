package org.d2j.game.game.fights;

import org.d2j.common.CollectionUtils;
import org.d2j.common.client.protocol.enums.FightStateEnum;
import org.d2j.common.client.protocol.enums.FightTypeEnum;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.game.fights.actions.Turn;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.Map;
import org.d2j.utils.Action;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.util.*;

/**
 * User: Blackrush
 * Date: 14/11/11
 * Time: 20:36
 * IDE : IntelliJ IDEA
 */
public class Fight {
    private final IGameConfiguration configuration;
    private final Map map;
    private final FightTypeEnum type;
    private final FightCell[] cells;
    private final Team challengers, defenders;
    private final long preparationDeadline;
    private final Timer preparationTimer;
    private Queue<Turn> turns;
    private Collection<IFighter> fighters;

    private FightStateEnum state;

    public Fight(IGameConfiguration configuration, Map map, FightTypeEnum type) {
        this.configuration = configuration;
        this.map = map;
        this.type = type;
        this.cells = FightCell.toFightCell(map.getCells(), map.getPlaces());

        this.preparationDeadline = System.currentTimeMillis() + this.configuration.getPreparationDelay() * 1000;
        this.preparationTimer = new Timer(this.configuration.getPreparationDelay() * 1000, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    start();
                } catch (FightException e1) {
                    e1.printStackTrace();
                }
            }
        });

        String[] places = map.getPlaces().split("\\|");
        this.challengers = new Team(this, FightTeamEnum.CHALLENGER, places[0]);
        this.defenders = new Team(this, FightTeamEnum.DEFENDER, places[1]);

        this.state = FightStateEnum.INIT;
    }

    public void foreachFighter(Action<IFighter> action) throws FightException {
        if (state == FightStateEnum.ACTIVE){
            for (IFighter fighter : fighters){
                try {
                    action.call(fighter);
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
        }
        else{
            for (IFighter fighter : challengers.getFighters()){
                try {
                    action.call(fighter);
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
            for (IFighter fighter : defenders.getFighters()){
                try {
                    action.call(fighter);
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
        }
    }

    public void foreach(Action<IFightHandler> action) throws FightException {
        if (state == FightStateEnum.ACTIVE){
            for (IFighter fighter : fighters){
                try {
                    action.call(fighter.getHandler());
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
        }
        else{
            for (IFighter fighter : challengers.getFighters()){
                try {
                    action.call(fighter.getHandler());
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
            for (IFighter fighter : defenders.getFighters()){
                try {
                    action.call(fighter.getHandler());
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
        }

    }

    public void foreachInTeam(FightTeamEnum teamId, Action<IFightHandler> action) throws FightException {
        Team team = getTeam(teamId);
        if (team != null){
            for (IFighter fighter : team.getFighters()){
                try {
                    action.call(fighter.getHandler());
                } catch (Exception e) {
                    throw new FightException(e);
                }
            }
        }
        else{
            throw new FightException("Invalid parameter <teamId> : unknown team.");
        }
    }

    private void generateTurns(){
        LinkedList<Turn> lTurns = new LinkedList<>();

        for (IFighter fighter : challengers.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }
        for (IFighter fighter : defenders.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }

        Collections.sort(lTurns, new Comparator<Turn>() {
            @Override
            public int compare(Turn o1, Turn o2) {
                return o2.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal() -
                        o1.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal();
            }
        });

        turns = lTurns;
    }

    public IGameConfiguration getConfiguration() {
        return configuration;
    }

    public Map getMap() {
        return map;
    }

    public FightStateEnum getState() {
        return state;
    }

    public FightTypeEnum getFightType() {
        return type;
    }

    public FightCell[] getCells() {
        return cells;
    }

    public Collection<IFighter> getFighters(){
        return fighters;
    }

    public Team getTeam(FightTeamEnum teamType){
        switch (teamType){
            case CHALLENGER:
                return challengers;
            case DEFENDER:
                return defenders;
            default:
                return null;
        }
    }

    public int remainingTime() {
        return type == FightTypeEnum.CHALLENGE ?
                -1 :
                (int) (System.currentTimeMillis() - preparationDeadline);
    }

    public Turn getCurrentTurn(){
        return turns.peek();
    }

    public void init() throws FightException {
        if (state != FightStateEnum.INIT){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        state = FightStateEnum.PLACE;

        foreachFighter(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFightJoin(
                        challengers,
                        defenders
                );
            }
        });

        if (type != FightTypeEnum.CHALLENGE){
            preparationTimer.start();
        }
    }

    public boolean startIfYouCan() throws FightException {
        if (state != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }
        else if (challengers.isReady() && defenders.isReady()){
            start();
            return true;
        }
        else{
            return false;
        }
    }

    private void start() throws FightException {
        state = FightStateEnum.ACTIVE;

        preparationTimer.stop();

        //todo remove blades

        generateTurns();

        fighters = CollectionUtils.concat(challengers.getFighters(), defenders.getFighters());

        foreachFighter(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFightStart(turns, fighters);
            }
        });

        turns.peek().begin();
    }

    public void stop() throws FightException {
        FightStateEnum oldState = state;
        state = FightStateEnum.FINISHED;

        if (oldState == FightStateEnum.PLACE){
            foreachFighter(new Action<IFighter>() {
                @Override
                public void call(IFighter obj) throws Exception {
                    obj.getHandler().notifyQuit();
                }
            });
        }
        else if (oldState == FightStateEnum.ACTIVE){
            //todo
        }
        else {
            throw new FightException("Invalid request: fight's state doesn't allow this request.");
        }
    }

    public void nextTurn() throws FightException {
        if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: fight's state doesn't allow this request.");
        }

        Turn turn = turns.poll();
        if (turn.isValid()){
            turns.add(turn);
        }

        turns.peek().begin();
    }

    public void notifyReady(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyFighterReady(fighter);
            }
        });
    }

    public void notifyFighterPlacement(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyFighterPlacement(fighter);
            }
        });
    }

    public void notifyFighterQuit(final IFighter fighter) throws FightException {
        foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyFighterQuit(fighter);
            }
        });

        if (fighter.getTeam().isEmpty()){
            stop();
        }
    }

    public void notifyAddFighter(final IFighter fighter) throws FightException {
        foreach(new Action<IFightHandler>() {
            @Override
            public void call(IFightHandler obj) throws Exception {
                obj.notifyAddFighter(fighter);
            }
        });
    }
}
