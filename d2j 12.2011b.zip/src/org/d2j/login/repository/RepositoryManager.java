package org.d2j.login.repository;

import org.d2j.login.configuration.ILoginConfiguration;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 09:39
 * IDE : IntelliJ IDEA
 */
public class RepositoryManager {
    private static final Logger logger = LoggerFactory.getLogger(RepositoryManager.class);

    private final EntitiesContext context;
    private boolean started;

    private final AccountRepository accounts;

    public RepositoryManager(ILoginConfiguration configuration) throws ClassNotFoundException {
        context = new EntitiesContext(configuration.getConnectionInformations(), configuration.getExecutionInterval());

        accounts = new AccountRepository(context, configuration.getRefreshInterval());
    }

    public void start(){
        if (started) return;

        try {
            context.start();
            accounts.start();

            logger.info("{} accounts loaded.", accounts.loadAll());

            started = true;

            logger.info("successfully started.");
        } catch (SQLException e) {
            logger.error("Can't begin RepositoryManager.", e.getCause());
        } catch (LoadingException e) {
            logger.error("Can't load RepositoryManager.", e.getCause());
        }
    }

    public void stop(){
        if (!started) return;

        try {
            accounts.stop();
            context.stop();

            started = false;

            logger.info("successfully stoped.");
        } catch (SQLException e) {
            logger.error("Can't end RepositoryManager.", e.getCause());
        }
    }

    public AccountRepository getAccounts() {
        return accounts;
    }
}
