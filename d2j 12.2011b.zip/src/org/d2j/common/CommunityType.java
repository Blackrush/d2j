package org.d2j.common;

/**
 * User: Blackrush
 * Date: 29/10/11
 * Time: 19:12
 * IDE : IntelliJ IDEA
 */
public class CommunityType {
    public static final int FRENCH = 0;
    public static final int BRITISH = 1;
    public static final int INETRNATIONAL = 2;
    public static final int GERMAN = 3;
    public static final int SPANISH = 4;
    public static final int RUSSIAN = 5;
    public static final int BRAZILIAN = 6;
    public static final int DUTCH = 7;
    public static final int ITALIAN = 8;
    public static final int JAPANESE = 10;
    public static final int DEBUG = 99;
}
