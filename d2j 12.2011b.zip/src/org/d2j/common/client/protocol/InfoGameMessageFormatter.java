package org.d2j.common.client.protocol;

import org.d2j.common.StringUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: Blackrush
 * Date: 06/11/11
 * Time: 10:22
 * IDE:  IntelliJ IDEA
 */
public class InfoGameMessageFormatter {
    public static final SimpleDateFormat LAST_CONNECTION_FORMATTER = new SimpleDateFormat(
            "yyyy~MM~dd~HH~mm"
    );

    public static String welcomeMessage(){
        return "Im189";
    }

    public static String currentAddressInformationMessage(String currentAddress){
        return "Im153;" + currentAddress;
    }

    public static String lastConnectionInformationMessage(Date lastConnection, String lastAddress){
        return "Im0152;" + LAST_CONNECTION_FORMATTER.format(lastConnection) + "~" + lastAddress;
    }

    public static String accountMutedMessage(){
        return "Im1124;";
    }

    public static String friendConnectedMessage(String friendNickname, String friendCharacterName){
        return StringUtil.format("Im0143;{0} ({1})", friendNickname, urlize(friendCharacterName));
    }

    public static String urlize(String title){
        return StringUtil.format("<b><a href='asfunction:onHref,ShowPlayerPopupMenu,{0}'>{0}</a></b>", title);
    }
}
