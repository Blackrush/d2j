package org.d2j.common.client.protocol;

import org.d2j.common.client.protocol.enums.*;
import org.d2j.common.client.protocol.type.BaseFighterType;
import org.d2j.common.client.protocol.type.CharacterFighterType;
import org.d2j.game.game.fights.FightTeamEnum;
import org.d2j.game.game.statistics.CharacteristicType;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 16/11/11
 * Time: 18:55
 * IDE : IntelliJ IDEA
 */
public class FightGameMessageFormatter {
    public static String newFightMessage(FightStateEnum fightState, boolean canCancel, boolean isChallenge, boolean isSpectator, int remainingTime, FightTypeEnum fightType){
        return "GJK" + fightState.ordinal()     + "|" +
                      (canCancel   ? "1" : "0") + "|" +
                      (isChallenge ? "1" : "0") + "|" +
                      (isSpectator ? "1" : "0") + "|" +
                       remainingTime            + "|" +
                       fightType.ordinal();
    }

    public static String startCellsMessage(String challengersPlaces, String defendersPlaces, FightTeamEnum team){
        return "GP" + challengersPlaces + "|" + defendersPlaces + "|" + team.ordinal();
    }

    public static String teamMessage(FightTeamEnum team, Collection<BaseFighterType> fighters){
        StringBuilder sb = new StringBuilder(10 * fighters.size()).append("Gt").append(team.ordinal());

        for (BaseFighterType fighter : fighters){
            sb.append("|+");
            sb.append(fighter.getId()).append(';');
            sb.append(fighter.getName()).append(';');
            sb.append(fighter.getLevel());
        }

        return sb.toString();
    }

    public static String showFighterMessage(BaseFighterType fighter){
        StringBuilder sb = new StringBuilder(50).append("GM");

        formatShowFighter(fighter, sb);
        fighter.serialize(sb);

        return sb.toString();
    }

    public static String showFightersMessage(Collection<BaseFighterType> fighters){
        StringBuilder sb = new StringBuilder(50 * fighters.size()).append("GM");

        for (BaseFighterType fighter : fighters){
            formatShowFighter(fighter, sb);
            fighter.serialize(sb);
        }

        return sb.toString();
    }

    private static void formatShowFighter(BaseFighterType fighter, StringBuilder sb){
        sb.append("|+");
        sb.append(fighter.getCurrentCellId()).append(';');
        sb.append(fighter.getOrientation().ordinal()).append(';');
        sb.append("0;"); // todo unknown packet parameter
        sb.append(fighter.getId()).append(';');
        sb.append(fighter.getName()).append(';');
    }

    public static String rolePlayFlagMessage(FightTypeEnum fightType, boolean pvpEnabled, CharacterFighterType challenger, CharacterFighterType defender){
        return "Gc+" + challenger.getId() + ";" + fightType.ordinal() + "|" +
                       challenger.getId() + ";" + challenger.getCurrentCellId() + ";0;" + (pvpEnabled ? challenger.getAlignId() : "") + "|" +
                       defender.getId() + ";"   + defender.getCurrentCellId()   + ";0;" + (pvpEnabled ? defender.getAlignId() : "");
    }

    public static String fighterPlacementMessage(long fighterId, short newCellId, OrientationEnum newOrientation){
        return "GIC|" + fighterId + ";" + newCellId + ";" + newOrientation.ordinal();
    }

    public static String fightersPlacementMessage(Collection<BaseFighterType> fighters){
        StringBuilder sb = new StringBuilder(10 * fighters.size()).append("GIC");

        for (BaseFighterType fighter : fighters){
            sb.append('|');

            sb.append(fighter.getId()).append(';');
            sb.append(fighter.getCurrentCellId()).append(';');
            sb.append(fighter.getOrientation().ordinal());
        }

        return sb.toString();
    }

    public static String fighterReadyMessage(long fighterId, boolean ready){
        return "GR" + (ready ? "1" : "0") + fighterId;
    }

    public static String fighterQuitMessage(long fighterId){
        return "GM|-" + fighterId;
    }

    public static String fightStartMessage(){
        return "GS";
    }

    public static String turnListMessage(Collection<Long> fightersId){
        StringBuilder sb = new StringBuilder(3 + 2 * fightersId.size()).append("GTL");

        for (Long fighterId : fightersId){
            sb.append('|');
            sb.append(fighterId);
        }

        return sb.toString();
    }

    public static String fighterInformationsMessage(Collection<BaseFighterType> fighters){
        StringBuilder sb = new StringBuilder(3 + 20 * fighters.size()).append("GTM");

        for (BaseFighterType fighter : fighters){
            sb.append('|');

            sb.append(fighter.getId()).append(';');
            sb.append(fighter.isDead() ? '1' : '0').append(';');

            if (!fighter.isDead()){
                sb.append(fighter.getStatistics().getLife()).append(';');
                sb.append(fighter.getStatistics().get(CharacteristicType.ActionPoints).getSafeTotal()).append(';');
                sb.append(fighter.getStatistics().get(CharacteristicType.MovementPoints).getSafeTotal()).append(';');
                sb.append(fighter.getCurrentCellId()).append(';');
                sb.append(';'); //todo ???
                sb.append(fighter.getStatistics().getMaxLife());
            }
        }

        return sb.toString();
    }

    public static String turnStartMessage(long fighterId, long remainingTime){
        return "GTS" + fighterId + "|" + remainingTime;
    }

    public static String turnEndMessage(long fighterId){
        return "GTF" + fighterId;
    }

    public static String turnReadyMessage(long fighterId){
        return "GTR" + fighterId;
    }

    public static String actionMessage(ActionTypeEnum actionType, long fighterId, Object... args){
        StringBuilder sb = new StringBuilder(15 + 5 * args.length).append("GA;");

        sb.append(actionType.value()).append(';');
        sb.append(fighterId).append(';');

        boolean first = true;
        for (Object arg : args){
            if (first) first = false;
            else sb.append(',');

            sb.append(arg.toString());
        }

        return sb.toString();
    }

    public static String fightActionMessage(ActionTypeEnum actionType, long fighterId, Object... args){
        StringBuilder sb = new StringBuilder(15 + 5 * args.length).append("GA0;");

        sb.append(actionType.value()).append(';');
        sb.append(fighterId).append(';');

        boolean first = true;
        for (Object arg : args){
            if (first) first = false;
            else sb.append(',');

            sb.append(arg.toString());
        }

        return sb.toString();
    }

    public static String fighterMovementMessage(long fighterId, String path){
        return fightActionMessage(ActionTypeEnum.MOVEMENT, fighterId, path);
    }

    public static String endFightActionMessage(EndActionTypeEnum fightAction, long fighterId){
        return "GAF" + fightAction.value() + "|" + fighterId;
    }

    public static String startActionMessage(long fighterId) {
        return "GAS" + fighterId;
    }

    public static String castSpellActionMessage(long fighterId, int spellId, int spellAnimationId, String spellSpriteInfos, int spellLevel, short targetCellId){
        return actionMessage(
                ActionTypeEnum.CAST_SPELL,
                fighterId,
                spellId,
                targetCellId,
                spellAnimationId,
                spellLevel,
                spellSpriteInfos
        );
    }
}
