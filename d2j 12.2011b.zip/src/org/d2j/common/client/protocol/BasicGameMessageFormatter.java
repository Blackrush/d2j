package org.d2j.common.client.protocol;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 19:32
 * IDE : IntelliJ IDEA
 */
public class BasicGameMessageFormatter {
    public static final SimpleDateFormat CURRENT_DATE_FORMATTER = new SimpleDateFormat(
            "yyyy|MM|dd"
    );

    public static String noOperationMessage(){
        return "BN";
    }

    public static String currentDateMessage(Date now){
        return "BD" + CURRENT_DATE_FORMATTER.format(now);
    }
}
