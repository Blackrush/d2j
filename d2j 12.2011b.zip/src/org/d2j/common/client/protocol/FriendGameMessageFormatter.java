package org.d2j.common.client.protocol;

/**
 * User: Blackrush
 * Date: 06/11/11
 * Time: 10:17
 * IDE:  IntelliJ IDEA
 */
public class FriendGameMessageFormatter {
    public static String notifyFriendOnConnectMessage(boolean notifyFriendOnConnect){
        return "FO" + (notifyFriendOnConnect ? "+": "-");
    }
}
