package org.d2j.common;

import java.util.HashMap;
import java.util.Map;

/**
 * User: Blackrush
 * Date: 29/10/11
 * Time: 19:06
 * IDE : IntelliJ IDEA
 */
public enum Permissions {
    BANNED,
    MEMBER,
    GAME_MASTER,
    ADMINISTRATOR;

    private static Map<Integer, Permissions> values = new HashMap<Integer, Permissions>();

    static{
        for (Permissions permissions : values()){
            values.put(permissions.ordinal(), permissions);
        }
    }

    public static Permissions valueOf(Integer ordinal){
        return values.get(ordinal);
    }
}
