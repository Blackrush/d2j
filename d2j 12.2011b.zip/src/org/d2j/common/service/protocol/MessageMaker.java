package org.d2j.common.service.protocol;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 10:14
 * IDE : IntelliJ IDEA
 */
public interface MessageMaker {
    Message make();
}
