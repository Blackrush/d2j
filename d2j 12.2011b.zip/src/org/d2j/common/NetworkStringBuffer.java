package org.d2j.common;

import org.apache.mina.core.session.IoSession;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 10:40
 * IDE : IntelliJ IDEA
 */
public class NetworkStringBuffer implements AutoCloseable {
    public static final char PACKET_SEPARATION = (char)0;

    private IoSession session;
    private List<String> buffer;

    public NetworkStringBuffer(IoSession session) {
        this.session = session;
        this.buffer = new ArrayList<>(10);
    }

    public NetworkStringBuffer(IoSession session, int capacity) {
        this.session = session;
        this.buffer = new ArrayList<>(capacity);
    }

    public NetworkStringBuffer append(String packet){
        buffer.add(packet);
        return this;
    }

    public void flush(){
        StringBuilder sb = new StringBuilder();
        for (String packet : buffer){
            sb.append(packet).append(PACKET_SEPARATION);
        }

        session.write(sb.toString());
    }

    @Override
    public void close() {
        flush();
    }
}
