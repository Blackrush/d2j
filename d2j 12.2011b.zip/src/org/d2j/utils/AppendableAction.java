package org.d2j.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Blackrush
 * Date: 17/12/11
 * Time: 10:56
 * IDE : IntelliJ IDEA
 */
public class AppendableAction<T> implements Action<T> {
    private List<Action<T>> actions = new ArrayList<>();

    @SafeVarargs
    public AppendableAction(Action<T>... actions) {
        for (Action<T> action : actions){
            this.actions.add(action);
        }
    }

    @Override
    public void call(T obj) throws Exception {
        for (Action<T> action : actions){
            action.call(obj);
        }
    }

    public void append(Action<T> action){
        actions.add(action);
    }
}
