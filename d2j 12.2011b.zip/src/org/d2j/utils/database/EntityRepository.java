package org.d2j.utils.database;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 09:13
 * IDE : IntelliJ IDEA
 */
public abstract class EntityRepository<T extends IEntity<TKey>, TKey> extends SaveableEntityRepository<T, TKey> {
    protected EntityRepository(EntitiesContext context) {
        super(context);
    }

    protected abstract void setNextId(T entity);
    protected abstract String getCreateQuery(T entity);
    protected abstract String getDeleteQuery(T entity);

    public synchronized void create(T entity){
        if (entity == null) return;

        entity.beforeCreate();

        setNextId(entity);
        context.execute(getCreateQuery(entity));
        entities.put(entity.getId(), entity);

        entity.onCreated();
    }

    public synchronized void delete(T entity){
        if (entity == null) return;

        entity.beforeDelete();

        context.execute(getDeleteQuery(entity));
        entities.remove(entity.getId());

        entity.onDeleted();
    }
}
