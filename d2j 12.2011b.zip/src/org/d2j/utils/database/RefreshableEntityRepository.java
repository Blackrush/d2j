package org.d2j.utils.database;

import org.d2j.login.model.LoginAccount;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 09:18
 * IDE : IntelliJ IDEA
 */
public abstract class RefreshableEntityRepository<T extends ISaveableEntity<TKey>, TKey>
    extends SaveableEntityRepository<T, TKey>
    implements Runnable
{
    protected boolean started;
    private long refreshInterval;
    private ScheduledExecutorService executor;

    protected RefreshableEntityRepository(EntitiesContext context, long refreshInterval) {
        super(context);

        this.refreshInterval = refreshInterval;
        this.executor = Executors.newScheduledThreadPool(1);
    }

    protected abstract String getRefreshQuery();
    protected abstract String getRefreshedQuery();
    protected abstract TKey readId(ResultSet reader) throws SQLException;
    protected abstract void refresh(T entity, ResultSet reader) throws SQLException;

    public void start(){
        if (started) return;

        executor.schedule(this, refreshInterval, TimeUnit.SECONDS);
    }

    public void stop(){
        if (!started) return;

        executor.shutdown();
    }

    public final void run(){
        context.query(new Query() {
            public void query(Statement statement) throws Exception {
                ResultSet results = statement.executeQuery(getRefreshQuery());
                results.beforeFirst();
                while (results.next()){
                    TKey id = readId(results);
                    T entity = entities.get(id);
                    if (entity != null){
                        refresh(entity, results);
                    } else {
                        entity = loadOne(results);
                        entities.put(id, entity);
                    }
                }
                results.close();
            }
        });

        context.execute(getRefreshedQuery());
    }
}
