* Author:
	Blackrush
	blackrushx[at]gmail[dot]com

* Thanks to :
	http://www.pimpmygame.fr/
	bouh2
	Nathanael
	Hermolf
	mathias52
	Aureus95

* IDE : 
	IntelliJ IDEA 10.5.2

* Tools :
    Java 7.0                http://www.java.com/
    JDK 1.7                 http://jdk7.java.net/
    Apache Mina 2           http://mina.apache.org/
    MySQL Connector/J       http://www.mysql.com/products/connector/
    slf4j                   http://www.slf4j.org/