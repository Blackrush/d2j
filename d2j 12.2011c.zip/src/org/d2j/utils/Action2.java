package org.d2j.utils;

/**
 * User: Blackrush
 * Date: 21/12/11
 * Time: 16:00
 * IDE : IntelliJ IDEA
 */
public interface Action2<A, B> {
    void action(A obj1, B obj2) throws Exception;
}
