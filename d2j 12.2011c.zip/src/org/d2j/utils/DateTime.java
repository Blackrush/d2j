package org.d2j.utils;

import java.util.GregorianCalendar;

/**
 * User: Blackrush
 * Date: 18/11/11
 * Time: 17:42
 * IDE : IntelliJ IDEA
 */
public class DateTime {
    public static DateTime now(){
        return new DateTime(System.currentTimeMillis());
    }

    private long time;

    public DateTime(long time) {
        this.time = time;
    }

    public int milliseconds(){
        return (int) (time % 1000);
    }

    public int seconds(){
        return (int) (time / 1000 % 60);
    }

    public int minutes(){
        return (int) (time / 1000 / 60 % 60);
    }

    public int hours(){
        return (int) (time / 1000 / 60 / 60 % 24);
    }

    public int day(){
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(time);
        return (int) (time / 1000 / 60 / 60 / 24 % 30);
    }

    public int month(){
        return (int) (time / 1000 / 60 / 60 / 30 % 12);
    }

    public int year(){
        return (int) (1970 + (time / 1000 / 60 / 60 / 24 / 365));
    }
}
