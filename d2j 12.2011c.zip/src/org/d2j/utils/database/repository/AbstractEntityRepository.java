package org.d2j.utils.database.repository;

import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.entity.IEntity;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 09:13
 * IDE : IntelliJ IDEA
 */
public abstract class AbstractEntityRepository<T extends IEntity<TKey>, TKey>
        extends AbstractSaveableEntityRepository<T, TKey>
        implements IEntityRepository<T, TKey>
{
    protected AbstractEntityRepository(EntitiesContext context) {
        super(context);
    }

    protected abstract void setNextId(T entity);
    protected abstract String getCreateQuery(T entity);
    protected abstract String getDeleteQuery(T entity);

    public synchronized void create(T entity){
        if (entity == null) return;

        setNextId(entity);
        context.execute(getCreateQuery(entity));
        entities.put(entity.getId(), entity);
    }

    public synchronized void delete(T entity){
        if (entity == null) return;

        context.execute(getDeleteQuery(entity));
        entities.remove(entity.getId());
    }
}
