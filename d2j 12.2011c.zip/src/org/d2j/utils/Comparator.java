package org.d2j.utils;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 12:52
 * IDE : IntelliJ IDEA
 */
public interface Comparator<T> {
    boolean compare(T o1, T o2);
}
