package org.d2j.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Blackrush
 * Date: 17/12/11
 * Time: 10:56
 * IDE : IntelliJ IDEA
 */
public class AppendableAction<T, E extends Exception> implements Action<T, E> {
    private List<Action<T, E>> actions = new ArrayList<>();

    @SafeVarargs
    public AppendableAction(Action<T, E>... actions) {
        for (Action<T, E> action : actions){
            this.actions.add(action);
        }
    }

    @Override
    public void call(T obj) throws E {
        for (Action<T, E> action : actions){
            action.call(obj);
        }
    }

    public void append(Action<T, E> action){
        actions.add(action);
    }
}
