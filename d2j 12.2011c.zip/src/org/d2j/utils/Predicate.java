package org.d2j.utils;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 13:07
 * IDE : IntelliJ IDEA
 */
public interface Predicate<T> {
    boolean test(T o);
}
