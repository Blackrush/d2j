package org.d2j.utils;

/**
 * User: Blackrush
 * Date: 19/11/11
 * Time: 09:50
 * IDE : IntelliJ IDEA
 */
public interface Action<T, E extends Exception> {
    void call(T obj) throws E;
}
