package org.d2j.game;

import com.google.inject.Guice;
import com.google.inject.Injector;
import org.d2j.common.service.protocol.MessageFactory;
import org.d2j.game.game.spells.EffectFactory;
import org.d2j.game.service.game.GameService;
import org.d2j.game.service.login.ILoginServerManager;
import org.d2j.game.service.login.LoginServerManager;

import java.io.IOException;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:18
 * IDE : IntelliJ IDEA
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException, IOException, InterruptedException {
        MessageFactory.getInstance().init();
        EffectFactory.load();

        Injector injector = Guice.createInjector(new D2jGameModule());

        RepositoryManager rm = injector.getInstance(RepositoryManager.class);
        ILoginServerManager lsm = injector.getInstance(LoginServerManager.class);
        GameService gs = injector.getInstance(GameService.class);

        rm.start();
        lsm.start();
        gs.start();

        waitForInput();

        gs.stop();
        lsm.stop();
        rm.stop();
    }

    private static void waitForInput() throws IOException {
        System.in.read();
    }
}
