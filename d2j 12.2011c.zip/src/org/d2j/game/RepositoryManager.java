package org.d2j.game;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.TypeLiteral;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.model.*;
import org.d2j.game.model.Character;
import org.d2j.game.repository.*;
import org.d2j.utils.PeriodicAction;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;
import org.d2j.utils.database.annotation.Dynamic;
import org.d2j.utils.database.annotation.Static;
import org.d2j.utils.database.repository.IBaseEntityRepository;
import org.d2j.utils.database.repository.IEntityRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:19
 * IDE : IntelliJ IDEA
 */
@Singleton
public class RepositoryManager extends PeriodicAction {
    private class RepositoryManagerModule extends AbstractModule {
        @Override
        protected void configure() {
            bind(EntitiesContext.class).annotatedWith(Dynamic.class).toInstance(dynamicContext);
            bind(EntitiesContext.class).annotatedWith(Static.class).toInstance(staticContext);

            bind(new TypeLiteral<IEntityRepository<GameAccount, Integer>>(){}).to(AccountRepository.class);
            bind(new TypeLiteral<IEntityRepository<Character, Long>>(){}).to(CharacterRepository.class);
            bind(new TypeLiteral<IEntityRepository<Spell, Long>>(){}).to(SpellRepository.class);
            bind(new TypeLiteral<IEntityRepository<Item, Long>>(){}).to(ItemRepository.class);

            bind(new TypeLiteral<IBaseEntityRepository<BreedTemplate, Byte>>(){}).to(BreedTemplateRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<ExperienceTemplate, Short>>(){}).to(ExperienceTemplateRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<Map, Integer>>(){}).to(MapRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<MapTrigger, Integer>>(){}).to(MapTriggerRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<SpellTemplate, Integer>>(){}).to(SpellTemplateRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<SpellBreed, Integer>>(){}).to(SpellBreedRepository.class);
            bind(new TypeLiteral<IBaseEntityRepository<ItemTemplate, Integer>>(){}).to(ItemTemplateRepository.class);
        }
    }

    private static final Logger logger = LoggerFactory.getLogger(RepositoryManager.class);

    private final IGameConfiguration configuration;

    private final EntitiesContext dynamicContext;
    private final EntitiesContext staticContext;
    private boolean started;

    private final AccountRepository accounts;
    private final CharacterRepository characters;
    private final SpellRepository spells;
    private final ItemRepository items;

    private final BreedTemplateRepository breedTemplates;
    private final ExperienceTemplateRepository experienceTemplates;
    private final MapRepository maps;
    private final MapTriggerRepository mapTriggers;
    private final SpellTemplateRepository spellTemplates;
    private final SpellBreedRepository spellBreeds;
    private final ItemTemplateRepository itemTemplates;

    @Inject
    public RepositoryManager(IGameConfiguration configuration) throws ClassNotFoundException {
        super(configuration.getSaveDatabaseInterval());

        this.configuration = configuration;

        dynamicContext = new EntitiesContext(
                this.configuration.getDynamicConnectionInformations(),
                this.configuration.getExecutionInterval()
        );
        staticContext = new EntitiesContext(
                this.configuration.getStaticConnectionInformations(),
                -1
        );

        Injector injector = Guice.createInjector(new RepositoryManagerModule());

        accounts = injector.getInstance(AccountRepository.class);
        characters = injector.getInstance(CharacterRepository.class);
        spells = injector.getInstance(SpellRepository.class);
        items = injector.getInstance(ItemRepository.class);

        breedTemplates = injector.getInstance(BreedTemplateRepository.class);
        experienceTemplates = injector.getInstance(ExperienceTemplateRepository.class);
        maps = injector.getInstance(MapRepository.class);
        mapTriggers = injector.getInstance(MapTriggerRepository.class);
        spellTemplates = injector.getInstance(SpellTemplateRepository.class);
        spellBreeds = injector.getInstance(SpellBreedRepository.class);
        itemTemplates = injector.getInstance(ItemTemplateRepository.class);
    }

    private void loadStaticContext() throws SQLException, LoadingException {
        logger.info("{} breed templates loaded.", breedTemplates.loadAll());
        logger.info("{} spell templates loaded.", spellTemplates.loadAll());
        logger.info("{} breed's spells loaded.", spellBreeds.loadAll());
        logger.info("{} experience templates loaded.", experienceTemplates.loadAll());
        logger.info("{} maps loaded.", maps.loadAll(configuration.getMapsLoadingLimit()));
        logger.info("{} map triggers loaded.", mapTriggers.loadAll());
        logger.info("{} item templates loaded.", itemTemplates.loadAll());
    }

    private void loadDynamicContext() throws SQLException, LoadingException {
        logger.info("{} accounts loaded.", accounts.loadAll());
        logger.info("{} characters loaded.", characters.loadAll());
        logger.info("{} spells loaded.", spells.loadAll());
        logger.info("{} items loaded.", items.loadAll());
    }

    private void saveDynamicContext() throws SQLException {
        logger.info("{} characters saved.", characters.saveAll());
        logger.info("{} accounts saved.", accounts.saveAll());
        logger.info("{} spells saved.", spells.saveAll());
        logger.info("{} items saved.", items.saveAll());
    }

    @Override
    protected void action() {
        try {
            saveDynamicContext();
        } catch (SQLException e) {
            logger.error("Can't save dynamic context. Reason: \"" + e.getMessage() + "\".", e.getCause());
        }
    }

    @Override
    public void start(){
        if (started) return;

        try {
            staticContext.start();
            loadStaticContext();
            staticContext.stop();

            dynamicContext.start();
            loadDynamicContext();

            super.start();

            started = true;
        } catch (SQLException e) {
            logger.error("Can't begin RepositoryManager.", e.getCause());
        } catch (LoadingException e){
            logger.error("Can't load RepositoryManager.", e.getCause());
        }
    }

    @Override
    public void stop(){
        if (!started) return;

        try {
            super.stop();

            dynamicContext.commit();

            saveDynamicContext();
            dynamicContext.commit();

            dynamicContext.stop();

            started = false;
        } catch (SQLException e) {
            logger.error("Can't end RepositoryManager.", e.getCause());
        }
    }

    public AccountRepository getAccounts() {
        return accounts;
    }

    public CharacterRepository getCharacters() {
        return characters;
    }

    public BreedTemplateRepository getBreedTemplates() {
        return breedTemplates;
    }

    public ExperienceTemplateRepository getExperienceTemplates() {
        return experienceTemplates;
    }

    public MapRepository getMaps() {
        return maps;
    }

    public MapTriggerRepository getMapTriggers() {
        return mapTriggers;
    }

    public SpellTemplateRepository getSpellTemplates() {
        return spellTemplates;
    }

    public SpellBreedRepository getSpellBreeds() {
        return spellBreeds;
    }

    public SpellRepository getSpells() {
        return spells;
    }

    public ItemTemplateRepository getItemTemplates() {
        return itemTemplates;
    }

    public ItemRepository getItems() {
        return items;
    }
}
