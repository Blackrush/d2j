package org.d2j.game.model;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.enums.CharacteristicsEnum;
import org.d2j.utils.database.entity.IBaseEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User: Blackrush
 * Date: 01/11/11
 * Time: 19:04
 * IDE : IntelliJ IDEA
 */
public class BreedTemplate implements IBaseEntity<Byte> {
    private Byte id;
    private short startAP;
    private short startMP;
    private short startLife;
    private short startProspection;
    private Map<CharacteristicsEnum, Map<short[], short[]>> characteristics = new HashMap<>();
    private List<SpellBreed> spells = new ArrayList<>();

    public BreedTemplate(Byte id, short startAP, short startMP, short startLife, short startProspection,
                         String intelligence, String chance, String agility, String strength, String vitality, String wisdom) {
        this.id = id;
        this.startAP = startAP;
        this.startMP = startMP;
        this.startLife = startLife;
        this.startProspection = startProspection;

        load(CharacteristicsEnum.Intelligence, intelligence);
        load(CharacteristicsEnum.Intelligence, intelligence);
        load(CharacteristicsEnum.Chance, chance);
        load(CharacteristicsEnum.Agility, agility);
        load(CharacteristicsEnum.Strength, strength);
        load(CharacteristicsEnum.Vitality, vitality);
        load(CharacteristicsEnum.Wisdom, wisdom);
    }

    public Byte getId() {
        return id;
    }

    public short getStartAP() {
        return startAP;
    }

    public short getStartMP() {
        return startMP;
    }

    public short getStartLife() {
        return startLife;
    }

    public short getStartProspection() {
        return startProspection;
    }

    public List<SpellBreed> getSpells() {
        return spells;
    }

    private void load(CharacteristicsEnum characteristic, String data)
    {
        HashMap<short[], short[]> c = new HashMap<>();
        for (String a : data.split("\\|")){
            String[] args = a.split(":");

            c.put(
                    StringUtil.toShort(args[0].split(",")),
                    StringUtil.toShort(args[1].split("\\-"))
            );
        }
        characteristics.put(characteristic, c);
    }

    public Short getCost(CharacteristicsEnum characteristic, short stats)
    {
        for (short[] interval : characteristics.get(characteristic).keySet()) {
            if (stats >= interval[0] && (interval.length == 1 || stats < interval[1])){
                return characteristics.get(characteristic).get(interval)[1];
            }
        }

        return null;
    }

    public Short getBonus(CharacteristicsEnum characteristic, short stats) {
        for (short[] interval : characteristics.get(characteristic).keySet()) {
            if (stats >= interval[0] && (interval.length == 1 || stats < interval[1])){
                return characteristics.get(characteristic).get(interval)[0];
            }
        }

        return null;
    }

    public List<SpellBreed> getDefaultSpells(){
        List<SpellBreed> results = new ArrayList<>();
        for (SpellBreed spell : spells){
            if (spell.getDefaultPosition() != -1){
                results.add(spell);
            }
        }
        return results;
    }

    public SpellBreed getNextSpell(short currentLevel){
        SpellBreed spell = spells.get(0);
        for (int i = 1; i < spells.size() && spell.getLevel() < currentLevel; ++i){
            spell = spells.get(i);
        }
        return spell;
    }
}
