package org.d2j.game.model;

import org.d2j.common.client.protocol.enums.ItemTypeEnum;
import org.d2j.game.game.items.ItemEffectTemplate;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 23:29
 * IDE : IntelliJ IDEA
 */
public class UsableItemTemplate extends ItemTemplate {
    private String effects;
    private boolean targetable;

    public UsableItemTemplate(int id, String name, ItemTypeEnum type, short level, int weight, boolean forgemageable, int price, String conditions, Collection<ItemEffectTemplate> stats, String effects, boolean targetable) {
        super(id, name, type, level, weight, forgemageable, price, conditions, stats);
        this.effects = effects;
        this.targetable = targetable;
    }

    @Override
    public boolean isUsable() {
        return true;
    }

    @Override
    public boolean isTargetable() {
        return targetable;
    }

    public String getEffects() {
        return effects;
    }
}
