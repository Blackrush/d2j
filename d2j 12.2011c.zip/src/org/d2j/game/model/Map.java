package org.d2j.game.model;

import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.game.game.Cell;
import org.d2j.game.game.actions.RolePlayMovement;
import org.d2j.game.game.events.MapUpdateActorEvent;
import org.d2j.game.game.events.MessageEvent;
import org.d2j.game.game.fights.Fight;
import org.d2j.utils.database.entity.IBaseEntity;

import java.util.*;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 16:53
 * IDE : IntelliJ IDEA
 */
public class Map extends Observable implements IBaseEntity<Integer> {
    private Integer id;
    private byte abscissa, ordinate;
    private byte width, height;
    private short subarea;
    private String data;
    private String key;
    private String date;
    private boolean subscriberArea;
    private String places;

    private final Cell[] cells;
    private final HashMap<Short, MapTrigger> triggers = new HashMap<>();

    private HashMap<Long, Character> actors = new HashMap<>();
    private List<Fight> fights = new ArrayList<>();

    public Map() {
        this.cells = new Cell[0];
    }

    public Map(Integer id, byte abscissa, byte ordinate, byte width, byte height, short subarea, String data, String key, String date, boolean subscriberArea, String places, Cell[] cells) {
        this.id = id;
        this.abscissa = abscissa;
        this.ordinate = ordinate;
        this.width = width;
        this.height = height;
        this.subarea = subarea;
        this.data = data;
        this.key = key;
        this.date = date;
        this.subscriberArea = subscriberArea;
        this.places = places;
        this.cells = cells;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public byte getAbscissa() {
        return abscissa;
    }

    public byte getOrdinate() {
        return ordinate;
    }

    public byte getWidth() {
        return width;
    }

    public byte getHeight() {
        return height;
    }

    public short getSubarea() {
        return subarea;
    }

    public String getData() {
        return data;
    }

    public String getKey() {
        return key;
    }

    public String getDate() {
        return date;
    }

    public boolean isSubscriberArea() {
        return subscriberArea;
    }

    public String getPlaces() {
        return places;
    }

    public Cell[] getCells() {
        return cells;
    }

    public HashMap<Short, MapTrigger> getTriggers() {
        return triggers;
    }

    public Collection<Character> getActors(){
        return actors.values();
    }

    public void addActor(Character actor){
        if (!actors.containsKey(actor.getId())){
            actors.put(actor.getId(), actor);

            setChanged();
            notifyObservers(new MapUpdateActorEvent(actor, MapUpdateActorEvent.MapUpdateType.ADD));
        }
    }

    public void removeActor(Character actor){
        if (actors.containsKey(actor.getId())){
            actors.remove(actor.getId());

            setChanged();
            notifyObservers(new MapUpdateActorEvent(actor, MapUpdateActorEvent.MapUpdateType.REMOVE));
        }
    }

    public void moveActor(RolePlayMovement movement, Character actor){
        if (actors.containsKey(actor.getId())){
            setChanged();
            notifyObservers(movement);
        }
    }

    public void speak(Character actor, ChannelEnum channel, String message){
        if (actors.containsKey(actor.getId())){
            setChanged();
            notifyObservers(new MessageEvent(actor.getId(), actor.getName(), channel, message));
        }
    }

    public int getNbFights(){
        return fights.size();
    }

    public boolean canFight(){
        return places != null && places.length() > 0 && !places.equals("|");
    }

    public void addFight(Fight fight){
        fights.add(fight);
    }

    public void removeFight(Fight fight){
        fights.remove(fight);
    }
}
