package org.d2j.game.model;

import org.d2j.common.client.protocol.enums.ItemTypeEnum;
import org.d2j.game.game.items.ItemEffectTemplate;
import org.d2j.utils.database.entity.IBaseEntity;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 19:54
 * IDE : IntelliJ IDEA
 */
public class ItemTemplate implements IBaseEntity<Integer> {
    private int id;
    private String name;
    private ItemTypeEnum type;
    private short level;
    private int weight;
    private boolean forgemageable;
    private int price;
    private String conditions;
    private Collection<ItemEffectTemplate> stats;

    public ItemTemplate(int id, String name, ItemTypeEnum type, short level, int weight, boolean forgemageable, int price, String conditions, Collection<ItemEffectTemplate> stats) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.level = level;
        this.weight = weight;
        this.forgemageable = forgemageable;
        this.price = price;
        this.conditions = conditions;
        this.stats = stats;
    }

    public boolean isWeapon(){
        return false;
    }

    public boolean isUsable(){
        return false;
    }

    public boolean isTargetable(){
        return false;
    }

    @Override
    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ItemTypeEnum getType() {
        return type;
    }

    public short getLevel() {
        return level;
    }

    public int getWeight() {
        return weight;
    }

    public boolean isForgemageable() {
        return forgemageable;
    }

    public int getPrice() {
        return price;
    }

    public String getConditions() {
        return conditions;
    }

    public Collection<ItemEffectTemplate> getStats() {
        return stats;
    }

    public Item generate(){
        return new Item(
                this,
                ItemEffectTemplate.generate(stats)
        );
    }
}
