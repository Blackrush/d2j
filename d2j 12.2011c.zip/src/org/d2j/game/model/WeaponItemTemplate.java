package org.d2j.game.model;

import org.d2j.common.client.protocol.enums.ItemTypeEnum;
import org.d2j.game.game.items.ItemEffectTemplate;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 23:27
 * IDE : IntelliJ IDEA
 */
public class WeaponItemTemplate extends ItemTemplate {
    private String infos;
    private boolean twoHands, ethereal;

    public WeaponItemTemplate(int id, String name, ItemTypeEnum type, short level, int weight, boolean forgemageable, int price, String conditions, Collection<ItemEffectTemplate> stats, String infos, boolean twoHands, boolean ethereal) {
        super(id, name, type, level, weight, forgemageable, price, conditions, stats);
        this.infos = infos;
        this.twoHands = twoHands;
        this.ethereal = ethereal;
    }

    @Override
    public boolean isWeapon() {
        return true;
    }

    public String getInfos() {
        return infos;
    }

    public boolean isTwoHands() {
        return twoHands;
    }

    public boolean isEthereal() {
        return ethereal;
    }
}
