package org.d2j.game.game;

import org.d2j.game.model.ExperienceTemplate;
import org.d2j.utils.database.repository.IBaseEntityRepository;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 09:42
 * IDE : IntelliJ IDEA
 */
public class Experience {
    private short level;
    private long experience;

    private IBaseEntityRepository<ExperienceTemplate, Short> experienceTemplates;
    private ExperienceTemplate currentExperienceTemplate;

    public Experience(Short level, long experience, IBaseEntityRepository<ExperienceTemplate, Short> experienceTemplates) {
        this.level = level;
        this.experience = experience;

        this.experienceTemplates = experienceTemplates;
        this.currentExperienceTemplate = experienceTemplates.findById(level);
    }

    public short getLevel() {
        return level;
    }

    public long getExperience() {
        return experience;
    }

    public ExperienceTemplate getTemplate() {
        return currentExperienceTemplate;
    }

    public Experience addLevel(short levels){
        level += levels;
        currentExperienceTemplate = experienceTemplates.findById(level);
        experience = currentExperienceTemplate.getCharacter();

        return this;
    }

    public Experience addExperience(long experiences){
        experience += experiences;

        ExperienceTemplate next = currentExperienceTemplate.next(experienceTemplates);
        if (experience >= next.getCharacter()){
            level = next.getLevel();
            currentExperienceTemplate = next;
        }

        return this;
    }

    public long min(){
        return currentExperienceTemplate.getCharacter();
    }

    public long max(){
        return currentExperienceTemplate.next(experienceTemplates).getCharacter();
    }
}
