package org.d2j.game.game.statistics;

import org.d2j.common.NumUtils;
import org.d2j.common.client.protocol.GameMessageFormatter;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.model.Character;

import java.util.HashMap;
import java.util.Map;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 11:04
 * IDE : IntelliJ IDEA
 */
public class CharacterStatistics implements IStatistics {
    private final Character character;
    private final Map<CharacteristicType, ICharacteristic> characteristics;

    private short life;

    private CharacterStatistics(Character character, Map<CharacteristicType, ICharacteristic>  characteristics, short life){
        this.character = character;
        this.characteristics = characteristics;
        this.life = life;
    }

    public CharacterStatistics(Character character) {
        this.character = character;
        this.characteristics = new HashMap<>();

        for (CharacteristicType type : CharacteristicType.values()){
            switch (type){
                case Initiative:
                    characteristics.put(type, new InitiativeCharacteristic(this));
                    break;

                case Prospection:
                    characteristics.put(type, new ProspectionCharacteristic(this));
                    break;

                default:
                    characteristics.put(type, new Characteristic());
                    break;
            }
        }
    }

    public CharacterStatistics
            (Character character,
             short life, short actionPoints, short movementPoints,
             short vitality, short wisdom,
             short strength, short intelligence,
             short chance, short agility)
    {
        this.character = character;
        this.characteristics = new HashMap<>();

        this.life = life;

        for (CharacteristicType type : CharacteristicType.values()){
            switch (type){
                case Initiative:
                    characteristics.put(type, new InitiativeCharacteristic(this));
                    break;

                case Prospection:
                    characteristics.put(type, new ProspectionCharacteristic(this));
                    break;

                case ActionPoints:
                    characteristics.put(type, new Characteristic(actionPoints, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case MovementPoints:
                    characteristics.put(type, new Characteristic(movementPoints, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Vitality:
                    characteristics.put(type, new Characteristic(vitality, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Wisdom:
                    characteristics.put(type, new Characteristic(wisdom, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Strength:
                    characteristics.put(type, new Characteristic(strength, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Intelligence:
                    characteristics.put(type, new Characteristic(intelligence, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Chance:
                    characteristics.put(type, new Characteristic(chance, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                case Agility:
                    characteristics.put(type, new Characteristic(agility, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO));
                    break;

                default:
                    characteristics.put(type, new Characteristic());
                    break;
            }
        }
    }

    @Override
    public ICharacteristic get(CharacteristicType type) {
        return characteristics.get(type);
    }

    @Override
    public short getLife() {
        return life;
    }

    @Override
    public void setLife(short life) {
        this.life = life;
    }

    @Override
    public short addLife(short life) {
        short initial = this.life;

        this.life += life;

        if (this.life > getMaxLife()){
            this.life = getMaxLife();
        }

        if (this.life < 0){
            this.life = 0;
        }

        return (short) (this.life - initial);
    }

    @Override
    public short getMaxLife() {
        return (short) (character.getBreed().getStartLife() +
                        5 * (character.getExperience().getLevel() - 1) +
                        get(CharacteristicType.Vitality).getTotal());
    }

    @Override
    public short getUsedPods() {
        return 0; //todo items
    }

    @Override
    public short getMaxPods() {
        return (short) (1000 + get(CharacteristicType.Strength).getTotal() * 5);
    }

    @Override
    public void reset() {
        for (ICharacteristic characteristic : characteristics.values()){
            characteristic.reset();
        }
    }

    @Override
    public void resetContext() {
        for (ICharacteristic characteristic : characteristics.values()){
            characteristic.setContext(NumUtils.SHORT_ZERO);
        }
    }

    @Override
    public void resetEquipments() {
        for (ICharacteristic characteristic : characteristics.values()){
            characteristic.setEquipments(NumUtils.SHORT_ZERO);
        }
    }


    @Override
    public void refresh() {

    }

    @Override
    public CharacterStatistics copy(){
        Map<CharacteristicType, ICharacteristic> characs = new HashMap<>(characteristics.size());
        for (Map.Entry<CharacteristicType, ICharacteristic> entry : characteristics.entrySet()){
            characs.put(entry.getKey(), entry.getValue().copy());
        }

        return new CharacterStatistics(character, characs, life);
    }

    public String getStatisticsMessage(IGameConfiguration configuration){
        return GameMessageFormatter.statisticsMessage(
                character.getExperience().getExperience(),
                character.getExperience().min(),
                character.getExperience().max(),
                character.getKamas(),
                character.getStatsPoints(),
                character.getSpellsPoints(),
                0, NumUtils.SHORT_ZERO, NumUtils.SHORT_ZERO, 0, 0, false, //todo alignment
                this.getLife(),
                this.getMaxLife(),
                character.getEnergy(),
                configuration.getMaxEnergy(),
                this.get(CharacteristicType.Initiative).getTotal(),
                this.get(CharacteristicType.Prospection).getTotal(),
                this
        );
    }
}
