package org.d2j.game.game.items;

import org.d2j.common.client.protocol.enums.ItemPositionEnum;
import org.d2j.game.model.Character;
import org.d2j.game.model.Item;
import org.d2j.utils.database.repository.IEntityRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 12:45
 * IDE : IntelliJ IDEA
 */
public class Bag extends HashMap<Long, Item> {
    private static boolean isEquiped(Bag bag, Item item){
        for (Item i : bag.values()){
            if (i.equals(item) && i.isEquiped()){
                return true;
            }
        }
        return false;
    }

    private final Character owner;
    private final IEntityRepository<Item, Long> itemRepository;
    private long kamas;

    public Bag(Character owner, IEntityRepository<Item, Long> itemRepository) {
        this.owner = owner;
        this.itemRepository = itemRepository;
    }

    public long getKamas() {
        return kamas;
    }

    public void setKamas(long kamas) {
        this.kamas = kamas;
    }

    public Bag addKamas(long kamas) {
        this.kamas += kamas;
        return this;
    }

    public void add(Item item){
        put(item.getId(), item);
    }

    public Item get(ItemPositionEnum position){
        for (Item item : values()){
            if (item.getPosition().equals(position)){
                return item;
            }
        }
        return null;
    }

    public void applyEquipedItems(){
        for (Item item : values()){
            if (item.isEquiped()){
                item.apply(owner.getStatistics());
            }
        }
    }

    public boolean equipIfYouCan(long itemId){
        Item item = get(itemId);

        if (item.isEquiped()){
            return false;
        }
        else if (isEquiped(this, item)){
            return false;
        }
        else{
            item.apply(owner.getStatistics());
            return true;
        }
    }

    public void factorize(){
        if (size() <= 1) return;

        List<Item> items = new ArrayList<>(values());

        while (items.size() > 1){
            Item item = items.get(0);
            items.remove(0);

            for (int i = 0; i < items.size(); ++i){
                Item current = items.get(i);
                if (current == item || !current.equals(item)){
                    continue;
                }

                item.addQuantity(current.getQuantity());
                itemRepository.delete(current);
                items.remove(i);
            }
        }
    }

    public Item[] getAccessories(){
        Item[] accessories = new Item[5];

        accessories[0] = get(ItemPositionEnum.Weapon);
        accessories[1] = get(ItemPositionEnum.Hat);
        accessories[2] = get(ItemPositionEnum.Cloak);
        accessories[3] = get(ItemPositionEnum.Pet);
        accessories[4] = get(ItemPositionEnum.Shield);

        return accessories;
    }
}
