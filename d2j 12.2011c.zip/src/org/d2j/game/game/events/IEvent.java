package org.d2j.game.game.events;

/**
 * User: Blackrush
 * Date: 22/12/11
 * Time: 16:57
 * IDE : IntelliJ IDEA
 */
public interface IEvent {
    EventType getEventType();
}
