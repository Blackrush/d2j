package org.d2j.game.game.events;

import org.d2j.game.model.Character;

/**
 * User: Blackrush
 * Date: 22/12/11
 * Time: 17:00
 * IDE : IntelliJ IDEA
 */
public class MapUpdateActorEvent implements IEvent {
    public static enum MapUpdateType {
        ADD,
        REMOVE,
        SKIN,
        SIZE
    }

    private Character actor;
    private MapUpdateType updateType;

    public MapUpdateActorEvent(Character actor, MapUpdateType updateType) {
        this.actor = actor;
        this.updateType = updateType;
    }

    @Override
    public EventType getEventType() {
        return EventType.MAP_UPDATE_ACTOR;
    }

    public MapUpdateType getMapUpdateType(){
        return updateType;
    }

    public Character getActor() {
        return actor;
    }

    public void setActor(Character actor) {
        this.actor = actor;
    }
}
