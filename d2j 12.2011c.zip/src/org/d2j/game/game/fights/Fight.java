package org.d2j.game.game.fights;

import org.d2j.common.CollectionUtils;
import org.d2j.common.client.protocol.enums.FightStateEnum;
import org.d2j.common.client.protocol.enums.FightTypeEnum;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.game.fights.actions.Turn;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.Map;
import org.d2j.utils.Action;

import java.util.*;

/**
 * User: Blackrush
 * Date: 14/11/11
 * Time: 20:36
 * IDE : IntelliJ IDEA
 */
public abstract class Fight {
    private Queue<Turn> turns;
    private FightStateEnum state;
    private long startFight;

    protected final IGameConfiguration configuration;
    protected final Map map;
    protected final FightCell[] cells;
    protected final Team challengers, defenders;
    protected Collection<IFighter> fighters;

    public Fight(IGameConfiguration configuration, Map map) {
        this.configuration = configuration;
        this.map = map;
        this.cells = FightCell.toFightCell(this, map.getCells(), map.getPlaces());

        String[] places = map.getPlaces().split("\\|");
        this.challengers = new Team(this, FightTeamEnum.CHALLENGER, places[0]);
        this.defenders = new Team(this, FightTeamEnum.DEFENDER, places[1]);

        this.state = FightStateEnum.INIT;
    }

    public abstract int remainingTime();
    public abstract FightTypeEnum getFightType();

    public IGameConfiguration getConfiguration() {
        return configuration;
    }

    public Map getMap() {
        return map;
    }

    public FightStateEnum getState() {
        return state;
    }

    public FightCell[] getCells() {
        return cells;
    }

    public Collection<IFighter> getFighters(){
        return fighters;
    }

    public Team getTeam(FightTeamEnum teamType){
        switch (teamType){
            case CHALLENGER:
                return challengers;
            case DEFENDER:
                return defenders;
            default:
                return null;
        }
    }

    public Turn getCurrentTurn(){
        return turns.peek();
    }

    public long getFightDuration(){
        return System.currentTimeMillis() - startFight;
    }

    protected abstract void onInited() throws FightException;

    public abstract boolean startIfYouCan() throws FightException;
    protected abstract void onStarted() throws FightException;

    public abstract boolean stopIfYouCan() throws FightException;
    protected abstract void stopFight(FightStateEnum oldState, FightTeamEnum winnerTeam) throws FightException;

    public void init() throws FightException {
        if (state != FightStateEnum.INIT){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        state = FightStateEnum.PLACE;

        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFightJoin(
                        challengers,
                        defenders
                );
            }
        });

        onInited();
    }

    protected void start() throws FightException {
        state = FightStateEnum.ACTIVE;

        generateTurns();
        fighters = CollectionUtils.concat(challengers.getFighters(), defenders.getFighters());

        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFightStart(turns, fighters);
            }
        });

        onStarted();

        startFight = System.currentTimeMillis();

        turns.peek().begin();
    }

    public void stop() throws FightException {
        if (state != FightStateEnum.PLACE && state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: fight's state doesn't allow this request.");
        }

        FightStateEnum oldState = state;
        state = FightStateEnum.FINISHED;

        turns.peek().end();

        stopFight(oldState, FightUtils.getWinnerTeam(challengers, defenders));
    }

    public void nextTurn() throws FightException {
        if (state == FightStateEnum.FINISHED){
            return;
        }
        else if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: fight's state doesn't allow this request.");
        }

        if (!challengers.isAlive() || !defenders.isAlive()){
            stop();
        }
        else{
            Turn turn = turns.poll();
            if (!turn.hasAbandoned() && turn.getFighter().isAlive()){
                turns.add(turn);
            }

            turns.peek().begin();
        }
    }

    public void notifyReady(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFighterReady(fighter);
            }
        });
    }

    public void notifyFighterPlacement(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }

        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFighterPlacement(fighter);
            }
        });
    }

    public void notifyFighterQuit(final IFighter fighter) throws FightException {
        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFighterQuit(fighter);
            }
        });
    }

    public void notifyAddFighter(final IFighter fighter) throws FightException {
        foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyAddFighter(fighter);
            }
        });
    }

    public void foreachFighter(Action<IFighter, FightException> action) throws FightException {
        if (state == FightStateEnum.ACTIVE){
            for (IFighter fighter : fighters){
                action.call(fighter);
            }
        }
        else{
            for (IFighter fighter : challengers.getFighters()){
                action.call(fighter);
            }
            for (IFighter fighter : defenders.getFighters()){
                action.call(fighter);
            }
        }
    }

    public void foreach(FightHandlerAction action) throws FightException {
        if (state == FightStateEnum.ACTIVE){
            for (IFighter fighter : fighters){
                action.call(fighter.getHandler());
            }
        }
        else{
            for (IFighter fighter : challengers.getFighters()){
                action.call(fighter.getHandler());
            }
            for (IFighter fighter : defenders.getFighters()){
                action.call(fighter.getHandler());
            }
        }

    }

    private void generateTurns(){
        LinkedList<Turn> lTurns = new LinkedList<>();

        for (IFighter fighter : challengers.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }
        for (IFighter fighter : defenders.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }

        Collections.sort(lTurns, new Comparator<Turn>() {
            @Override
            public int compare(Turn o1, Turn o2) {
                return o2.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal() -
                        o1.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal();
            }
        });

        turns = lTurns;
    }
}
