package org.d2j.game.game.fights;

import org.d2j.utils.Action;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 11:46
 * IDE : IntelliJ IDEA
 */
public interface FightHandlerAction extends Action<IFightHandler, FightException> {
}
