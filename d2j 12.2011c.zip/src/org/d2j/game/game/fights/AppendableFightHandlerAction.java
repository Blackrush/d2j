package org.d2j.game.game.fights;

import org.d2j.utils.Action;
import org.d2j.utils.AppendableAction;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 11:49
 * IDE : IntelliJ IDEA
 */
public class AppendableFightHandlerAction extends AppendableAction<IFightHandler, FightException> implements FightHandlerAction {
    public AppendableFightHandlerAction(Action<IFightHandler, FightException>... actions) {
        super(actions);
    }
}
