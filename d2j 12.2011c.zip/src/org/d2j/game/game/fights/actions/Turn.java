package org.d2j.game.game.fights.actions;

import org.d2j.game.game.fights.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * User: Blackrush
 * Date: 20/11/11
 * Time: 21:42
 * IDE : IntelliJ IDEA
 */
public class Turn {
    private final Fight fight;
    private final IFighter fighter;
    private final Timer timer;

    private long end;
    private boolean abandoned;

    public Turn(IFighter fighter, Fight fight) {
        this.fighter = fighter;
        this.fight = fight;
        this.timer = new Timer(fight.getConfiguration().getTurnDelay() * 1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    end();
                } catch (FightException e1) {
                    e1.printStackTrace();
                }
            }
        });
    }

    public void begin() throws FightException {
        int turnDelay = fight.getConfiguration().getTurnDelay() * 1000;
        end = System.currentTimeMillis() + fight.getConfiguration().getTurnDelay() * 1000;

        timer.start();

        onStarted();

        fight.foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyTurnStart(Turn.this);
            }
        });
    }

    public void end() throws FightException {
        timer.stop();

        onEnded();

        fight.foreach(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyFightersInformations(fight.getFighters());
                obj.notifyTurnStop(Turn.this);
            }
        });
        fight.nextTurn();
    }

    private void onStarted() throws FightException {
        fighter.getLogs().clear();
        fighter.getBuffs().apply();
    }

    private void onEnded() throws FightException {
        fighter.getStatistics().resetContext();
        fighter.getHandler().notifyRefreshStatistics();
    }

    public IFighter getFighter() {
        return fighter;
    }

    public long remainingTime(){
        return end - System.currentTimeMillis();
    }

    public boolean hasAbandoned() {
        return abandoned;
    }

    public void setAbandoned(boolean abandoned) {
        this.abandoned = abandoned;
    }
}
