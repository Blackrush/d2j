package org.d2j.game.game.fights;

import org.d2j.game.game.spells.ISpellLevel;

/**
 * User: Blackrush
 * Date: 21/12/11
 * Time: 15:10
 * IDE : IntelliJ IDEA
 */
public class FightUtils {
    public static boolean computeFailure(ISpellLevel infos, IFighter caster) {
        return false;
    }

    public static boolean computeCritical(ISpellLevel infos, IFighter caster) {
        return false;
    }

    public static FightTeamEnum getWinnerTeam(Team team1, Team team2) {
        int nbSurvivors1 = 0,
            nbSurvivors2 = 0;

        for (IFighter fighter : team1.getFighters()){
            if (fighter.isAlive()){
                ++nbSurvivors1;
            }
        }

        for (IFighter fighter : team2.getFighters()){
            if (fighter.isAlive()){
                ++nbSurvivors1;
            }
        }

        if (nbSurvivors1 < nbSurvivors2) {
            return team2.getTeamType();
        }
        else {
            return team1.getTeamType();
        }
    }

    public static FightTeamEnum oppositeTeam(FightTeamEnum team){
        switch (team){
            case CHALLENGER:
                return FightTeamEnum.DEFENDER;
            case DEFENDER:
                return FightTeamEnum.CHALLENGER;
            default:
                return null;
        }
    }
}
