package org.d2j.game.game.fights;

import org.d2j.game.game.spells.effects.Effect;
import org.d2j.game.model.SpellTemplate;
import org.d2j.utils.Action;
import org.d2j.utils.AppendableAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

/**
 * User: Blackrush
 * Date: 21/12/11
 * Time: 12:58
 * IDE : IntelliJ IDEA
 */
public class FightBuffs extends ArrayList<FightBuffs.Buff> {
    private static final Logger logger = LoggerFactory.getLogger(FightBuffs.class);

    public static class Buff {
        private final IFighter caster;
        private final SpellTemplate spell;
        private int remainingTurn;
        private final Effect effect;

        public Buff(int remainingTurn, Effect effect, IFighter caster, SpellTemplate spell) {
            this.remainingTurn = remainingTurn;
            this.effect = effect;
            this.caster = caster;
            this.spell = spell;
        }

        public int getRemainingTurn() {
            return remainingTurn;
        }

        public int addRemainingTurn(int turn) {
            return (this.remainingTurn += turn);
        }

        public Effect getEffect() {
            return effect;
        }

        public IFighter getCaster() {
            return caster;
        }

        public SpellTemplate getSpell() {
            return spell;
        }
    }

    private final Fight fight;
    private final IFighter fighter;

    public FightBuffs(Fight fight, IFighter fighter) {
        this.fight = fight;
        this.fighter = fighter;
    }

    public IFighter getFighter() {
        return fighter;
    }

    public void apply() throws FightException {
        AppendableFightHandlerAction action = new AppendableFightHandlerAction();

        for (int i = 0; i < size(); ++i){
            Buff buff = get(i); // get buff

            buff.getEffect().apply(action, buff.getCaster(), fighter.getCurrentCell()); // use buff

            if (buff.addRemainingTurn(-1) <= 0){ // remove buff if it's finished
                remove(i);
            }
        }

        fight.foreach(action);
    }

    @Override
    public boolean add(final Buff buff) {
        try {
            fight.foreach(new FightHandlerAction() {
                @Override
                public void call(IFightHandler obj) throws FightException {
                    obj.notifyNewBuff(fighter, buff);
                }
            });
        } catch (FightException e) {
            logger.error(e.getMessage(), e.getCause());
        }

        return super.add(buff);
    }
}
