package org.d2j.game.game.fights;

import org.d2j.common.client.protocol.enums.FightStateEnum;
import org.d2j.common.client.protocol.enums.FightTypeEnum;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.model.Map;
import org.d2j.utils.Action;

/**
 * User: Blackrush
 * Date: 21/12/11
 * Time: 15:29
 * IDE : IntelliJ IDEA
 */
public class ChallengeFight extends Fight {
    public ChallengeFight(IGameConfiguration configuration, Map map) {
        super(configuration, map);
    }

    @Override
    public int remainingTime() {
        return -1;
    }

    @Override
    public FightTypeEnum getFightType() {
        return FightTypeEnum.CHALLENGE;
    }

    @Override
    protected void onInited() {
        // todo add blades on map
    }

    @Override
    public boolean startIfYouCan() throws FightException {
        if (getState() != FightStateEnum.PLACE){
            throw new FightException("Fight's state doesn't allow this request.");
        }
        else if (challengers.isReady() && defenders.isReady()){
            start();

            return true;
        }
        else{
            return false;
        }
    }

    @Override
    protected void onStarted() {
        // todo remove blades from map
    }

    @Override
    public boolean stopIfYouCan() throws FightException {
        stop();
        return true;
    }

    @Override
    protected void stopFight(FightStateEnum oldState, final FightTeamEnum winners) throws FightException {
        if (oldState == FightStateEnum.PLACE){
            foreach(new FightHandlerAction() {
                @Override
                public void call(IFightHandler obj) throws FightException {
                    obj.notifyQuit();
                }
            });
        }
        else if (oldState == FightStateEnum.ACTIVE){
            foreach(new FightHandlerAction() {
                @Override
                public void call(IFightHandler obj) throws FightException {
                    obj.notifyFightEnd(
                            getTeam(winners),
                            getTeam(FightUtils.oppositeTeam(winners))
                    );
                }
            });
        }
        else{ // must not happened !!!
            throw new FightException("Invalid request: fight's state doesn't allow this request.");
        }
    }
}
