package org.d2j.game.game;

import org.d2j.common.StringUtil;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.game.events.SystemMessageEvent;
import org.d2j.game.service.IWorld;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 19:13
 * IDE : IntelliJ IDEA
 */
public class PubSystem implements ActionListener {
    private static final String PUB_MESSAGE_FORMAT = "<font color=\"#{0}\"><b>(Pub)</b> {1}</font>";

    private final IGameConfiguration configuration;
    private final IWorld world;
    private Timer timer;
    private String[] messages;
    private String messageColor;
    private int currentMessage;

    public PubSystem(IGameConfiguration configuration, IWorld world) {
        this.configuration = configuration;
        this.world = world;
        this.timer = new Timer(configuration.getPubInterval() * 60 * 1000, this);
        this.messages = this.configuration.getPubMessages();
        this.messageColor = this.configuration.getPubColor();
        this.currentMessage = 0;
    }

    public void start(){
        timer.start();
    }

    public void stop(){
        timer.stop();
    }

    public void setMessage(int index, String message){
        index--; // index 0 = 1st; index 1 = 2nd; index 2 = 3rd
        if (index < 0 || index >= messages.length) return;

        messages[index] = message;
    }

    public void setMessageColor(String messageColor){
        this.messageColor = messageColor;
    }

    public void setInterval(int minutes){
        timer.stop();
        timer.setDelay(minutes * 60000);
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String message = StringUtil.format(
                PUB_MESSAGE_FORMAT,
                messageColor,
                messages[currentMessage]
        );

        world.systemMessage(new SystemMessageEvent(message));

        ++currentMessage;
        if (currentMessage >= configuration.getPubMessages().length){
            currentMessage = 0;
        }
    }
}
