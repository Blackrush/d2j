package org.d2j.game.game.spells;

import org.d2j.game.model.SpellTemplate;

/**
 * User: Blackrush
 * Date: 08/12/11
 * Time: 20:19
 * IDE : IntelliJ IDEA
 */
public interface IEffectFactory {
    ISpellLevel parse(SpellTemplate template, String str);
    void load();
}
