package org.d2j.game.game.spells.effects;

import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.SpellEffectsEnum;
import org.d2j.common.random.Dice;
import org.d2j.game.game.fights.*;
import org.d2j.game.game.spells.ISpellLevel;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.game.statistics.IStatistics;

/**
 * User: Blackrush
 * Date: 16/12/11
 * Time: 17:31
 * IDE : IntelliJ IDEA
 */
public class DamageEffect extends Effect {
    public static int getEffect(CharacteristicType characteristic, IStatistics statistics, Dice dice){
        int base = dice.roll(),
            charac = statistics.get(characteristic).getSafeTotal(),
            domPercent = statistics.get(CharacteristicType.DamagePer).getSafeTotal(),
            dom = statistics.get(CharacteristicType.Damage).getSafeTotal();

        return base * (100 + charac + domPercent) / 100 + dom;
    }

    private final CharacteristicType characteristic;

    private Dice dice;

    public DamageEffect(ISpellLevel infos, CharacteristicType characteristic) {
        super(infos);

        this.characteristic = characteristic;
    }

    @Override
    public SpellEffectsEnum getEffectId() {
        return null;
    }

    @Override
    public void apply(AppendableFightHandlerAction action, final IFighter caster, final FightCell targetCell) throws FightException {
        if (targetCell.getCurrentFighter() == null || !targetCell.getCurrentFighter().isAlive()) return;

        final IFighter target = targetCell.getCurrentFighter();

        final int effect = target.getStatistics()
                                 .addLife((short) -getEffect(characteristic, caster.getStatistics(), dice));

        action.append(new FightHandlerAction() {
            @Override
            public void call(IFightHandler obj) throws FightException {
                obj.notifyBasicAction(
                        ActionTypeEnum.LIFE_CHANGEMENT,
                        caster,
                        (int)target.getId(),
                        effect
                );
            }
        });
    }

    @Override
    public int getValue1() {
        return 0;
    }

    @Override
    public void setValue1(int value1) {
    }

    @Override
    public int getValue2() {
        return 0;
    }

    @Override
    public void setValue2(int value2) {
    }

    @Override
    public int getValue3() {
        return 0;
    }

    @Override
    public void setValue3(int value3) {
    }

    @Override
    public int getNbTurns() {
        return 0;
    }

    @Override
    public void setNbTurns(int nbTurns) {
    }

    @Override
    public int getChance() {
        return 0;
    }

    @Override
    public void setChance(int chance) {
    }

    @Override
    public Dice getDice() {
        return dice;
    }

    @Override
    public void setDice(Dice dice) {
        this.dice = dice;
    }
}
