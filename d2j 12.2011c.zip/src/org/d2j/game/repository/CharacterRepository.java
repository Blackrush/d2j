package org.d2j.game.repository;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.game.Experience;
import org.d2j.game.game.items.Bag;
import org.d2j.game.game.statistics.CharacterStatistics;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.*;
import org.d2j.game.model.Character;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;
import org.d2j.utils.database.annotation.Dynamic;
import org.d2j.utils.database.repository.AbstractEntityRepository;
import org.d2j.utils.database.repository.IBaseEntityRepository;
import org.d2j.utils.database.repository.IEntityRepository;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 02/11/11
 * Time: 11:16
 * IDE : IntelliJ IDEA
 */
@Singleton
public class CharacterRepository extends AbstractEntityRepository<Character, Long> {
    private long nextId;

    private IBaseEntityRepository<BreedTemplate, Byte> breedTemplates;
    private IBaseEntityRepository<ExperienceTemplate, Short> experienceTemplates;
    private IEntityRepository<GameAccount, Integer> accounts;
    private IBaseEntityRepository<Map, Integer> maps;
    private IEntityRepository<Item, Long> items;

    private IBaseEntityRepository<SpellBreed, Integer> spellBreeds;

    @Inject
    public CharacterRepository(@Dynamic EntitiesContext context, IBaseEntityRepository<BreedTemplate, Byte> breedTemplates, IBaseEntityRepository<ExperienceTemplate, Short> experienceTemplates, IEntityRepository<GameAccount, Integer> accounts, IBaseEntityRepository<Map, Integer> maps, IEntityRepository<Item, Long> items, IBaseEntityRepository<SpellBreed, Integer> spellBreeds) {
        super(context);
        this.breedTemplates = breedTemplates;
        this.experienceTemplates = experienceTemplates;
        this.accounts = accounts;
        this.maps = maps;
        this.items = items;
        this.spellBreeds = spellBreeds;
    }

    public boolean nameExists(String name){
        for (Character c : entities.values())
            if (name.equalsIgnoreCase(c.getName()))
                return true;
        return false;
    }

    public Character createDefault(IGameConfiguration config, GameAccount owner, String name, Byte breed, boolean gender, int color1, int color2, int color3){
        Character character = new Character();

        character.setName(name);
        character.setOwner(owner);
        character.setBreed(breedTemplates.findById(breed));
        character.setGender(gender);

        character.setColor1(color1);
        character.setColor2(color2);
        character.setColor3(color3);
        character.setSkin((short) (breed * 10 + (gender ? 1 : 0)));
        character.setSize(config.getStartSize());

        character.setExperience(new Experience(
                config.getStartLevel(),
                experienceTemplates.findById(config.getStartLevel()).getCharacter(),
                experienceTemplates
        ));

        character.setStatistics(new CharacterStatistics(character));
        character.getStatistics().setLife(character.getStatistics().getMaxLife());
        character.getStatistics().get(CharacteristicType.ActionPoints).setBase(character.getBreed().getStartAP());
        character.getStatistics().get(CharacteristicType.MovementPoints).setBase(character.getBreed().getStartMP());
        character.getStatistics().get(CharacteristicType.Prospection).setBase(character.getBreed().getStartProspection());

        character.setEnergy(config.getStartEnergy());
        character.setKamas(config.getStartKamas());

        character.setStatsPoints((short) (config.getStartLevel() * 5 - 5));
        character.setSpellsPoints((short) (config.getStartLevel() - 1));

        character.setCurrentMap(maps.findById(config.getStartMapId()));
        character.setCurrentCellId(config.getStartCellId());
        character.setCurrentOrientation(OrientationEnum.SOUTH_EAST);
        character.setMemorizedMap(maps.findById(config.getDefaultMemorizedMapId()));

        for (SpellBreed spell : spellBreeds.all()){
            if (spell.getBreed() == character.getBreed() &&
                spell.getLevel() <= character.getExperience().getLevel())
            {
                Spell s = spell.getSpell().newInstance();
                s.setCharacter(character);
                s.setLevel(config.getSpellStartLevel());
                s.setPosition(spell.getDefaultPosition());

                character.getSpells().put(s.getTemplate().getId(), s);
            }
        }

        character.setBag(new Bag(character, items));

        create(character);

        return character;
    }

    @Override
    protected void beforeLoading() throws LoadingException {
        if (!accounts.isLoaded()) throw new LoadingException("AccountRepository must be loaded.");

        if (!breedTemplates.isLoaded()) throw new LoadingException("BreedTemplateRepository must be loaded.");

        if (!experienceTemplates.isLoaded()) throw new LoadingException("ExperienceTemplateRepository must be loaded.");

        if (!maps.isLoaded()) throw new LoadingException("MapRepository must be loaded.");
    }

    @Override
    protected void afterLoading() {
        for (Character chr : entities.values()){
            if (chr.getId() > nextId)
                nextId = chr.getId();
        }
    }

    @Override
    protected void setNextId(Character entity) {
        entity.setId(++nextId);
    }

    @Override
    protected String getCreateQuery(Character entity) {
        return StringUtil.format(
                "INSERT INTO `characters`(`id`,`ownerId`,`name`,`breed`,`gender`,`color1`,`color2`,`color3`," +
                "`skin`,`size`,`level`,`experience`,`energy`,`kamas`,`statsPoints`,`spellsPoints`," +
                "`vitality`,`wisdom`,`strength`,`intelligence`,`chance`,`agility`,`life`," +
                "`currentMap`,`currentCell`,`currentOrientation`,`memorizedMap`,`actionPoints`,`movementPoints`) " +
                "VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}'," +
                "'{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}','{24}','{25}','{26}','{27}','{28}');",

                entity.getId(),
                entity.getOwner().getId(),
                entity.getName(),
                entity.getBreed().getId(),
                entity.getGender() ? "1" : "0",
                entity.getColor1(),
                entity.getColor2(),
                entity.getColor3(),
                entity.getSkin(),
                entity.getSize(),
                entity.getExperience().getLevel(),
                entity.getExperience().getExperience(),
                entity.getEnergy(),
                entity.getKamas(),
                entity.getStatsPoints(),
                entity.getSpellsPoints(),
                entity.getStatistics().get(CharacteristicType.Vitality).getBase(),
                entity.getStatistics().get(CharacteristicType.Wisdom).getBase(),
                entity.getStatistics().get(CharacteristicType.Strength).getBase(),
                entity.getStatistics().get(CharacteristicType.Intelligence).getBase(),
                entity.getStatistics().get(CharacteristicType.Chance).getBase(),
                entity.getStatistics().get(CharacteristicType.Agility).getBase(),
                entity.getStatistics().getLife(),
                entity.getCurrentMap().getId(),
                entity.getCurrentCellId(),
                entity.getCurrentOrientation().ordinal(),
                entity.getMemorizedMap().getId(),
                entity.getStatistics().get(CharacteristicType.ActionPoints).getBase(),
                entity.getStatistics().get(CharacteristicType.MovementPoints).getBase()
        );
    }

    @Override
    protected String getDeleteQuery(Character entity) {
        return StringUtil.format(
                "DELETE FROM `characters` WHERE `id`='{0}';",
                entity.getId()
        );
    }

    @Override
    protected String getSaveQuery(Character entity) {
        return StringUtil.format(
                "UPDATE `characters` SET " +
                "`skin`='{0}', `size`='{1}', " +
                "`level`='{2}', `experience`='{3}', " +
                "`energy`='{4}', `kamas`='{5}', " +
                "`statsPoints`='{6}', `spellsPoints`='{7}', " +
                "`vitality`='{8}', `wisdom`='{9}', " +
                "`strength`='{10}', `intelligence`='{11}', " +
                "`chance`='{12}', `agility`='{13}', " +
                "`currentMap`='{14}', `currentCell`='{15}', " +
                "`currentOrientation`='{16}', " +
                "`memorizedMap`='{17}', " +
                "`life`='{18}', `actionPoints`='{19}', `movementPoints`='{20}'" +
                " WHERE `id`='{21}';",

                entity.getSkin(),
                entity.getSize(),
                entity.getExperience().getLevel(),
                entity.getExperience().getExperience(),
                entity.getEnergy(),
                entity.getKamas(),
                entity.getStatsPoints(),
                entity.getSpellsPoints(),
                entity.getStatistics().get(CharacteristicType.Vitality).getBase(),
                entity.getStatistics().get(CharacteristicType.Wisdom).getBase(),
                entity.getStatistics().get(CharacteristicType.Strength).getBase(),
                entity.getStatistics().get(CharacteristicType.Intelligence).getBase(),
                entity.getStatistics().get(CharacteristicType.Chance).getBase(),
                entity.getStatistics().get(CharacteristicType.Agility).getBase(),
                entity.getCurrentMap().getId(),
                entity.getCurrentCellId(),
                entity.getCurrentOrientation().ordinal(),
                entity.getMemorizedMap().getId(),
                entity.getStatistics().getLife(),
                entity.getStatistics().get(CharacteristicType.ActionPoints).getBase(),
                entity.getStatistics().get(CharacteristicType.MovementPoints).getBase(),

                entity.getId()
        );
    }

    @Override
    protected String getLoadQuery() {
        return "SELECT * FROM `characters`;";
    }

    @Override
    protected String getLoadOneQuery(Long id) {
        return "SELECT * FROM `characters` WHERE `id`='" + id + "';";
    }

    @Override
    protected Character loadOne(ResultSet reader) throws SQLException {
        Character chr = new Character(
                reader.getLong("id"),
                accounts.findById(reader.getInt("ownerId")),
                reader.getString("name"),
                breedTemplates.findById(reader.getByte("breed")),
                reader.getBoolean("gender"),
                reader.getInt("color1"),
                reader.getInt("color2"),
                reader.getInt("color3"),
                reader.getShort("skin"),
                reader.getShort("size"),
                new Experience(
                        reader.getShort("level"),
                        reader.getLong("experience"),
                        experienceTemplates
                ),
                null, // statistics, look at the end
                reader.getShort("energy"),
                reader.getInt("kamas"),
                reader.getShort("statsPoints"),
                reader.getShort("spellsPoints"),
                maps.findById(reader.getInt("currentMap")),
                reader.getShort("currentCell"),
                OrientationEnum.SOUTH_EAST,
                maps.findById(reader.getInt("memorizedMap"))
        );
        chr.setStatistics(new CharacterStatistics(
                chr,
                reader.getShort("life"),
                reader.getShort("actionPoints"),
                reader.getShort("movementPoints"),
                reader.getShort("vitality"),
                reader.getShort("wisdom"),
                reader.getShort("strength"),
                reader.getShort("intelligence"),
                reader.getShort("chance"),
                reader.getShort("agility")
        ));
        chr.setBag(new Bag(chr, items));

        chr.getOwner().getCharacters().put(chr.getId(), chr);

        return chr;
    }

    public Character findByName(String name) {
        for (Character c : entities.values()){
            if (name.equals(c.getName())){
                return c;
            }
        }
        return null;
    }
}
