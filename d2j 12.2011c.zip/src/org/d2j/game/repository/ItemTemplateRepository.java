package org.d2j.game.repository;

import org.d2j.common.client.protocol.enums.ItemEffectEnum;
import org.d2j.common.client.protocol.enums.ItemTypeEnum;
import org.d2j.common.random.Dice;
import org.d2j.game.game.items.ItemEffectTemplate;
import org.d2j.game.model.ItemTemplate;
import org.d2j.game.model.UsableItemTemplate;
import org.d2j.game.model.WeaponItemTemplate;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.annotation.Static;
import org.d2j.utils.database.repository.AbstractBaseEntityRepository;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.d2j.common.StringUtil.fromHex;

/**
 * User: Blackrush
 * Date: 23/12/11
 * Time: 19:55
 * IDE : IntelliJ IDEA
 */
@Singleton
public class ItemTemplateRepository extends AbstractBaseEntityRepository<ItemTemplate, Integer> {
    @Inject
    public ItemTemplateRepository(@Static EntitiesContext context) {
        super(context);
    }

    @Override
    protected String getLoadQuery() {
        return "SELECT * FROM `item_templates`;";
    }

    @Override
    protected String getLoadOneQuery(Integer id) {
        return "SELECT * FROM `item_templates` WHERE `id`='" + id + "';";
    }

    @Override
    protected ItemTemplate loadOne(ResultSet reader) throws SQLException {
        if (!reader.getString("weaponInfo").isEmpty()){
            return buildWeapon(reader);
        }
        else if (reader.getBoolean("usable")){
            return buildUsableItem(reader);
        }
        else{
            return buildItem(reader);
        }
    }

    private static WeaponItemTemplate buildWeapon(ResultSet reader) throws SQLException {
        return new WeaponItemTemplate(
                reader.getInt("id"),
                reader.getString("name"),
                ItemTypeEnum.valueOf(reader.getInt("type")),
                reader.getShort("level"),
                reader.getInt("weight"),
                reader.getBoolean("forgemageable"),
                reader.getInt("price"),
                reader.getString("conditions"),
                buildItemStats(reader.getString("stats")),
                reader.getString("weaponInfo"),
                reader.getBoolean("twoHands"),
                reader.getBoolean("isEthereal")
        );
    }

    private static UsableItemTemplate buildUsableItem(ResultSet reader) throws SQLException {
        return new UsableItemTemplate(
                reader.getInt("id"),
                reader.getString("name"),
                ItemTypeEnum.valueOf(reader.getInt("type")),
                reader.getShort("level"),
                reader.getInt("weight"),
                reader.getBoolean("forgemageable"),
                reader.getInt("price"),
                reader.getString("conditions"),
                buildItemStats(reader.getString("stats")),
                reader.getString("useEffects"),
                reader.getBoolean("targetable")
        );
    }

    private static ItemTemplate buildItem(ResultSet reader) throws SQLException {
        return new ItemTemplate(
                reader.getInt("id"),
                reader.getString("name"),
                ItemTypeEnum.valueOf(reader.getInt("type")),
                reader.getShort("level"),
                reader.getInt("weight"),
                reader.getBoolean("forgemageable"),
                reader.getInt("price"),
                reader.getString("conditions"),
                buildItemStats(reader.getString("stats"))
        );
    }

    private static Collection<ItemEffectTemplate> buildItemStats(String stats){
        List<ItemEffectTemplate> result = new ArrayList<>();

        for (String stat : stats.split(",")) if (!stat.isEmpty()) {
            String[] effects = stat.split("#");

            result.add(new ItemEffectTemplate(
                    ItemEffectEnum.valueOf(fromHex(effects[0])),
                    effects.length > 4 ? Dice.parseDice(effects[4]) : Dice.EMPTY_DICE
            ));
        }

        return result;
    }
}
