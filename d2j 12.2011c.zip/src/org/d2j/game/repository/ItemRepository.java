package org.d2j.game.repository;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.enums.ItemPositionEnum;
import org.d2j.game.game.items.ItemEffect;
import org.d2j.game.model.Character;
import org.d2j.game.model.Item;
import org.d2j.game.model.ItemTemplate;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;
import org.d2j.utils.database.annotation.Dynamic;
import org.d2j.utils.database.repository.AbstractEntityRepository;
import org.d2j.utils.database.repository.IBaseEntityRepository;
import org.d2j.utils.database.repository.IEntityRepository;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 14:38
 * IDE : IntelliJ IDEA
 */
@Singleton
public class ItemRepository extends AbstractEntityRepository<Item, Long> {
    private final IEntityRepository<Character, Long> characters;
    private final IBaseEntityRepository<ItemTemplate, Integer> itemTemplates;

    private long nextId;

    @Inject
    public ItemRepository(@Dynamic EntitiesContext context, IEntityRepository<Character, Long> characters, IBaseEntityRepository<ItemTemplate, Integer> itemTemplates) {
        super(context);
        this.characters = characters;
        this.itemTemplates = itemTemplates;
    }

    @Override
    protected void setNextId(Item entity) {
        entity.setId(++nextId);
    }

    @Override
    protected String getCreateQuery(Item entity) {
        return StringUtil.format(
                "INSERT INTO `items`(`id`,`template`,`owner`,`effects`,`position`,`quantity`) " +
                "VALUES('{0}','{1}','{2}','{3}','{4}','{5}');",

                entity.getId(),
                entity.getTemplate().getId(),
                entity.getOwner().getId(),
                statsToString(entity.getEffects()),
                entity.getPosition().value(),
                entity.getQuantity()
        );
    }

    @Override
    protected String getDeleteQuery(Item entity) {
        return "DELETE FROM `items` WHERE `id`='" + entity.getId() + "';";
    }

    @Override
    protected String getSaveQuery(Item entity) {
        return StringUtil.format(
                "UPDATE `items` SET " +
                "`owner`='{0}', " +
                "`effects`='{1}', " +
                "`position`='{2}', " +
                "`quantity`='{3}' " +
                "WHERE `id`='{4}';",

                entity.getOwner().getId(),
                statsToString(entity.getEffects()),
                entity.getPosition().value(),
                entity.getQuantity(),

                entity.getId()
        );
    }

    @Override
    protected String getLoadQuery() {
        return "SELECT * FROM `items`;";
    }

    @Override
    protected String getLoadOneQuery(Long id) {
        return "SELECT * FROM `items` WHERE `id`='" + id + "';";
    }

    @Override
    protected Item loadOne(ResultSet reader) throws SQLException {
        return new Item(
                reader.getLong("id"),
                itemTemplates.findById(reader.getInt("template")),
                characters.findById(reader.getLong("owner")),
                buildStats(reader.getString("effects")),
                ItemPositionEnum.valueOf(reader.getInt("position")),
                reader.getInt("quantity")
        );
    }

    private static Collection<ItemEffect> buildStats(String effects) {
        List<ItemEffect> result = new ArrayList<>();
        for (String effect : effects.split(";")){
            result.add(ItemEffect.parseItemEffect(effect));
        }
        return result;
    }

    private static String statsToString(Collection<ItemEffect> effects){
        StringBuilder sb = new StringBuilder(5 * effects.size());
        for (ItemEffect effect : effects){
            sb.append(effect.toString());
        }
        return sb.toString();
    }

    @Override
    protected void beforeLoading() throws LoadingException {
        super.beforeLoading();

        if (!characters.isLoaded()){
            throw new LoadingException("CharacterRepository isn't loaded.");
        }

        if (!itemTemplates.isLoaded()){
            throw new LoadingException("ItemTemplateRepository isn't loaded.");
        }
    }

    @Override
    protected void afterLoading() {
        super.afterLoading();

        for (Item item : entities.values()){
            if (item.getId() > nextId){
                nextId = item.getId();
            }
        }
    }
}
