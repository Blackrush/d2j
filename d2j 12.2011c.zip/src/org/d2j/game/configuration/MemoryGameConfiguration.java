package org.d2j.game.configuration;

import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.game.game.channels.ChannelList;
import org.d2j.utils.database.ConnectionStringBuilder;

import javax.inject.Singleton;
import java.util.HashMap;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 16:09
 * IDE : IntelliJ IDEA
 */
@Singleton
public class MemoryGameConfiguration implements IGameConfiguration {
    public String getRemoteAddress() {
        return "127.0.0.1";
    }

    public int getRemotePort() {
        return 5555;
    }

    public String getSystemAddress() {
        return "127.0.0.1";
    }

    public int getSystemPort() {
        return 4443;
    }

    public ConnectionStringBuilder getDynamicConnectionInformations() {
        return new ConnectionStringBuilder("localhost", "d2j_game1", "root", "");
    }

    public ConnectionStringBuilder getStaticConnectionInformations() {
        return new ConnectionStringBuilder("localhost", "d2j_static", "root", "");
    }

    public long getExecutionInterval() {
        return 5 * 60;
    }

    @Override
    public long getMapsLoadingLimit() {
        return -1;
    }

    @Override
    public int getSaveDatabaseInterval() {
        return 7 * 60;
    }

    public int getServerId() {
        return 1;
    }

    public boolean getCharacterNameSuggestionEnabled() {
        return true;
    }

    public short getMaxCharactersPerAccount() {
        return 6;
    }

    public int getDeletionAnswerRequiredLevel() {
        return 10;
    }

    public short getStartSize() {
        return 100;
    }

    public short getStartLevel() {
        return 200;
    }

    public short getStartEnergy() {
        return getMaxEnergy();
    }

    public int getStartKamas() {
        return 1000000;
    }

    @Override
    public Integer getStartMapId() {
        return 7411;
    }

    @Override
    public short getStartCellId() {
        return 335;
    }

    @Override
    public Integer getDefaultMemorizedMapId() {
        return 7411;
    }

    public short getMaxEnergy() {
        return 10000;
    }

    @Override
    public int getPreparationDelay() {
        return 45;
    }

    @Override
    public int getTurnDelay() {
        return 29;
    }

    @Override
    public short getSpellStartLevel() {
        return 1;
    }

    @Override
    public short getMaxLevelSpell() {
        return 6;
    }

    @Override
    public char getCommandPrefix() {
        return '!';
    }

    @Override
    public String getMotd() {
        return "Bienvenue sur <u>Hélios</u>, le serveur Dofus anka'like.";
    }

    @Override
    public int getPubInterval() {
        return 5;
    }

    @Override
    public String[] getPubMessages() {
        return new String[]{
                "Visitez notre <u><a href=\"http://www.google.fr/\">site officiel</a></u> pour " +
                "suivre toute l'actualité du serveur, échanger avec nous sur le forum et obtenir " +
                "des cadeaux en votant pour notre serveur !",

                "Message de pub olol.",

                "Visitez notre partenaire <u><a href=\"http://ankafriend.fr.nf/\">AnkaFriend</a></u>, " +
                "le forum d'émulation Dofus 1.29 !"
        };
    }

    @Override
    public String getPubColor() {
        return "C52BFF";
    }

    @Override
    public HashMap<ChannelEnum, Integer> getChannelRestrictions() {
        HashMap<ChannelEnum, Integer> restrictions = new HashMap<>();

        restrictions.put(ChannelEnum.Trade, 45);
        restrictions.put(ChannelEnum.Recruitment, 30);
        restrictions.put(ChannelEnum.Alignment, 15);

        return restrictions;
    }

    @Override
    public ChannelList getDefaultChannelList() {
        ChannelList channel = new ChannelList();

        channel.add(ChannelEnum.Information);
        channel.add(ChannelEnum.General);
        channel.add(ChannelEnum.Team);
        channel.add(ChannelEnum.Party);
        channel.add(ChannelEnum.UNKNOWN0);
        channel.add(ChannelEnum.Guild);

        return channel;
    }
}
