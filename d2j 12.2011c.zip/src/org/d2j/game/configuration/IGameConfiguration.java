package org.d2j.game.configuration;

import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.game.game.channels.ChannelList;
import org.d2j.utils.database.ConnectionStringBuilder;

import java.util.HashMap;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:19
 * IDE : IntelliJ IDEA
 */
public interface IGameConfiguration {
    String getRemoteAddress();  // for clients
    int getRemotePort();        // for clients
    String getSystemAddress();  // for Loginserver
    int getSystemPort();        // for Loginserver

    ConnectionStringBuilder getDynamicConnectionInformations();
    ConnectionStringBuilder getStaticConnectionInformations();
    long getExecutionInterval();
    long getMapsLoadingLimit();
    int getSaveDatabaseInterval();

    int getServerId();
    boolean getCharacterNameSuggestionEnabled();
    short getMaxCharactersPerAccount();
    int getDeletionAnswerRequiredLevel();

    short getStartSize();
    short getStartLevel();
    short getStartEnergy();
    int getStartKamas();
    Integer getStartMapId();
    short getStartCellId();
    Integer getDefaultMemorizedMapId();
    short getMaxEnergy();
    short getSpellStartLevel();
    short getMaxLevelSpell();

    int getPreparationDelay();
    int getTurnDelay();

    char getCommandPrefix();

    String getMotd();
    int getPubInterval();// minutes
    String[] getPubMessages();
    String getPubColor();

    HashMap<ChannelEnum, Integer> getChannelRestrictions();
    ChannelList getDefaultChannelList();
}
