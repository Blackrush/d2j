package org.d2j.game.service.game.handler;

import org.d2j.common.CollectionUtils;
import org.d2j.common.NetworkStringBuffer;
import org.d2j.common.client.protocol.BasicGameMessageFormatter;
import org.d2j.common.client.protocol.FightGameMessageFormatter;
import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.EndActionTypeEnum;
import org.d2j.common.client.protocol.enums.FightStateEnum;
import org.d2j.common.client.protocol.enums.FightTypeEnum;
import org.d2j.game.game.Cell;
import org.d2j.game.game.fights.*;
import org.d2j.game.game.fights.actions.FightMovement;
import org.d2j.game.game.fights.actions.PlayerFightMovement;
import org.d2j.game.game.fights.actions.Turn;
import org.d2j.game.game.spells.ISpell;
import org.d2j.game.model.Spell;
import org.d2j.game.service.game.GameClient;
import org.d2j.game.service.game.GameClientHandler;
import org.d2j.game.service.game.GameService;
import org.d2j.utils.Selector;

import java.util.Collection;
import java.util.Observable;

/**
 * User: Blackrush
 * Date: 15/11/11
 * Time: 18:59
 * IDE : IntelliJ IDEA
 */
public class FightHandler extends GameClientHandler implements IFightHandler {
    private final Fight fight;
    private final Fighter fighter;
    private final Team team;
    private final RolePlayHandler rolePlay;

    public FightHandler(GameService service, GameClient client, Fight fight, FightTeamEnum teamType, RolePlayHandler rolePlay) throws FightException {
        super(service, client);

        this.fight = fight;
        this.team = this.fight.getTeam(teamType);
        this.fighter = this.team != null ? new Fighter(this.fight, this.client, this) : null;
        if (this.team != null){
            this.team.addFighter(this.fighter);
        }

        this.rolePlay = rolePlay;
    }

    @Override
    public void parse(String packet) throws Exception {
        switch (packet.charAt(0)){
            case 'G':
                switch (packet.charAt(1)){
                    case 'A':
                        parseGameActionRequestMessage(
                                ActionTypeEnum.valueOf(Integer.parseInt(packet.substring(2, 5))),
                                packet.substring(5)
                        );
                        break;

                    case 'K':
                        client.getSession().write(BasicGameMessageFormatter.noOperationMessage());
                        break;

                    case 'p':
                        parseFighterPlacementRequestMessage(Short.parseShort(packet.substring(2)));
                        break;

                    case 'R':
                        parseFighterReadyRequestMessage(packet.charAt(2) == '1');
                        break;

                    case 'Q':
                        parseQuitFightRequestMessage(
                                packet.length() > 2 ?
                                        team.getFighter(Long.parseLong(packet.substring(2))) :
                                        fighter
                        );
                        break;

                    case 't':
                        parseTurnEndRequestMessage();
                        break;
                }
                break;

            default:
                rolePlay.parse(packet);
                break;
        }
    }

    @Override
    public void onClosed() throws Exception {
        rolePlay.onClosed();

        if (fight.getState() == FightStateEnum.PLACE){
            fighter.getCurrentCell().setCurrentFighter(null);
            team.removeFighter(fighter.getId());
        }
        else if (fight.getState() == FightStateEnum.ACTIVE){
            // todo
        }
        else{
            // no actions for another fight state
        }
    }

    @Override
    public void update(Observable o, Object arg) {

    }

    @Override
    public void notifyFightJoin(Team challengers, Team defenders) throws FightException {
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            buf.append(FightGameMessageFormatter.newFightMessage(
                    fight.getState(),
                    fight.getFightType() == FightTypeEnum.CHALLENGE,
                    fight.getFightType() == FightTypeEnum.CHALLENGE,
                    team.getTeamType() == FightTeamEnum.SPECTATOR,
                    fight.remainingTime(),
                    fight.getFightType()
            ));

            buf.append(FightGameMessageFormatter.startCellsMessage(
                    challengers.getPlaces(),
                    defenders.getPlaces(),
                    team.getTeamType()
            ));

            buf.append(FightGameMessageFormatter.teamMessage(
                    team.getTeamType(),
                    Fighter.toBaseFighterType(team.getFighters())
            ));

            if (!challengers.isEmpty()){
                buf.append(FightGameMessageFormatter.showFightersMessage(
                        Fighter.toBaseFighterType(challengers.getFighters())
                ));
            }

            if (!defenders.isEmpty()){
                buf.append(FightGameMessageFormatter.showFightersMessage(
                        Fighter.toBaseFighterType(defenders.getFighters())
                ));
            }
        }
    }

    @Override
    public void notifyFighterReady(IFighter fighter) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterReadyMessage(
                fighter.getId(),
                fighter.isReady()
        ));
    }

    @Override
    public void notifyAddFighter(IFighter fighter) throws FightException {
        client.getSession().write(FightGameMessageFormatter.
                showFighterMessage(fighter.toBaseFighterType())
        );
    }

    @Override
    public void notifyRemoveFighter(long fighterId) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterQuitMessage(fighterId));
    }

    @Override
    public void notifyAddFighters(Collection<IFighter> fighters) throws FightException {
        client.getSession().write(FightGameMessageFormatter.
                showFightersMessage(Fighter.toBaseFighterType(fighters))
        );
    }

    @Override
    public void notifyFighterPlacement(IFighter fighter) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterPlacementMessage(
                fighter.getId(),
                fighter.getCurrentCell().getId(),
                fighter.getCurrentOrientation()
        ));
    }

    @Override
    public void notifyFighterQuit(IFighter f) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterQuitMessage(f.getId()));
    }

    @Override
    public void notifyQuit() throws FightException {
        client.setHandler(rolePlay);
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            buf.append(FightGameMessageFormatter.fighterQuitMessage(fighter.getId()));
            rolePlay.join(buf);
        }
        client.getCharacter().getCurrentMap().addObserver(rolePlay);
    }

    @Override
    public void notifyFightStart(Collection<Turn> turns, Collection<IFighter> fighters) throws FightException {
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            buf.append(FightGameMessageFormatter.fightersPlacementMessage(
                    Fighter.toBaseFighterType(fighters)
            ));

            buf.append(FightGameMessageFormatter.fightStartMessage());

            buf.append(FightGameMessageFormatter.turnListMessage(
                    CollectionUtils.select(turns, new Selector<Turn, Long>() {
                        @Override
                        public Long select(Turn in) {
                            return in.getFighter().getId();
                        }
                    })
            ));

            buf.append(FightGameMessageFormatter.fighterInformationsMessage(
                    Fighter.toBaseFighterType(fighters)
            ));
        }
    }

    @Override
    public void notifyTurnStart(Turn turn) throws FightException {
        client.getSession().write(FightGameMessageFormatter.turnStartMessage(
                turn.getFighter().getId(),
                turn.remainingTime()
        ));
    }

    @Override
    public void notifyTurnStop(Turn turn) throws FightException {
        client.getSession().write(FightGameMessageFormatter.
                turnEndMessage(turn.getFighter().getId()));
    }

    @Override
    public void notifyFighterMovement(FightMovement movement) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterMovementMessage(
                movement.getFighter().getId(),
                movement.getPath()
        ));
    }

    @Override
    public void notifyBasicAction(ActionTypeEnum actionType, IFighter fighter, int arg) throws FightException {
        client.getSession().write(FightGameMessageFormatter.actionMessage(
                actionType,
                fighter.getId(),
                arg
        ));
    }

    @Override
    public void notifyBasicAction(ActionTypeEnum actionType, IFighter fighter, int arg1, int arg2) throws FightException {
        client.getSession().write(FightGameMessageFormatter.actionMessage(
                actionType,
                fighter.getId(),
                arg1,
                arg2
        ));
    }

    @Override
    public void notifyEndAction(EndActionTypeEnum action, IFighter fighter) throws FightException {
        client.getSession().write(FightGameMessageFormatter.endFightActionMessage(
                action,
                fighter.getId()
        ));
    }

    @Override
    public void notifyRefreshStatistics() throws FightException {
        client.getSession().write(fighter.getStatistics().getStatisticsMessage(service.getConfiguration()));
    }

    @Override
    public void notifyFightersInformations(Collection<IFighter> fighters) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fighterInformationsMessage(
                Fighter.toBaseFighterType(fighters)
        ));
    }

    @Override
    public void notifyStartAction(long fighterId) throws FightException {
        client.getSession().write(FightGameMessageFormatter.startActionMessage(fighterId));
    }

    @Override
    public void notifyCastSpell(IFighter fighter, ISpell spell, FightCell target) throws FightException {
        client.getSession().write(FightGameMessageFormatter.castSpellActionMessage(
                fighter.getId(),
                spell.getTemplate().getId(),
                spell.getTemplate().getSprite(),
                spell.getTemplate().getSpriteInfos(),
                spell.getLevel(),
                target.getId()
        ));
    }

    @Override
    public void notifyTeleportation(IFighter fighter, FightCell target) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fightActionMessage(
                ActionTypeEnum.CELL_CHANGEMENT,
                fighter.getId(),
                fighter.getId(),
                target.getId()
        ));
    }

    @Override
    public void notifySlide(IFighter caster, IFighter target) throws FightException {
        client.getSession().write(FightGameMessageFormatter.fightActionMessage(
                ActionTypeEnum.CELL_SLIDE,
                caster.getId(),
                target.getId(),
                target.getCurrentCell().getId()
        ));
    }

    @Override
    public void notifyNewBuff(IFighter fighter, FightBuffs.Buff buff) {
        client.getSession().write(FightGameMessageFormatter.fighterBuffMessage(
                fighter.getId(),
                buff.getEffect().getEffectId(),
                buff.getEffect().getValue1(),
                buff.getEffect().getValue2(),
                buff.getEffect().getValue3(),
                buff.getEffect().getChance(),
                buff.getRemainingTurn(),
                buff.getSpell().getId()
        ));
    }

    @Override
    public void notifyFightEnd(Team winners, Team losers) {
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            buf.append(FightGameMessageFormatter.fightEndMessage(
                    fight.getFightDuration() / 1000,
                    fight.getFightType() == FightTypeEnum.AGRESSION,
                    winners.getLeader().toBaseEndFighterType(),
                    Fighter.toBaseEndFighterType(winners.getFighters()),
                    Fighter.toBaseEndFighterType(losers.getFighters())
            ));

            rolePlay.join(buf);
        }

        client.setHandler(rolePlay);
    }

    private void parseFighterPlacementRequestMessage(short cellId) throws Exception {
        FightCell cell = fight.getCells()[cellId];

        if (!cell.isAvailable()){
            throw new Exception("Bad request: unavailable selected cell.");
        }
        else if (cell.getStartCell() != team.getTeamType()) {
            throw new Exception("Bad request: selected cell isn't a begin cell.");
        }
        else {
            fighter.getCurrentCell().setCurrentFighter(null);

            fighter.setCurrentCell(cell);
            fighter.getCurrentCell().setCurrentFighter(fighter);

            fight.notifyFighterPlacement(fighter);
        }
    }

    private void parseFighterReadyRequestMessage(boolean ready) throws FightException {
        fighter.setReady(ready);
        fight.notifyReady(fighter);

        fight.startIfYouCan();
    }

    private void parseQuitFightRequestMessage(IFighter target) throws Exception {
        fight.notifyFighterQuit(target);

        if (!fight.stopIfYouCan()){
            target.getCurrentCell().setCurrentFighter(null);
            target.getTeam().removeFighter(target.getId());
        }
    }

    private void parseGameActionRequestMessage(ActionTypeEnum action, String args) throws Exception {
        if (fight.getState() != FightStateEnum.ACTIVE){
            throw new Exception("Bad request: fight's state don't allow you to do this action.");
        }

        if (fight.getCurrentTurn().getFighter() != fighter){
            throw new Exception("Bad request: it isn't your turn!");
        }

        switch (action){
            case MOVEMENT:
                parseMovementRequestMessage(args);
                break;

            case CAST_SPELL:
                String[] data = args.split(";");
                parseCastSpellRequestMessage(
                        Integer.parseInt(data[0]),
                        fight.getCells()[Integer.parseInt(data[1])]
                );
                break;
        }
    }

    private void parseCastSpellRequestMessage(int spellId, FightCell target) throws Exception {
        if (fight.getCurrentTurn().getFighter() != fighter){
            throw new Exception("Invalid request: it isn't your turn.");
        }

        Spell spell = fighter.getSpells().get(spellId);
        if (spell == null){
            throw new Exception("Invalid request: unknown spell or not learned.");
        }
        else{
            spell.apply(fighter.getLogs(), fight, fighter, target);
        }
    }

    private void parseMovementRequestMessage(String path) throws Exception {
        if (path.equals("")){
            throw new Exception("Bad request: empty path.");
        }
        else if (!fighter.isAlive()){
            throw new Exception("Bad request: you're dead!");
        }

        new PlayerFightMovement(
                fight,
                fighter,
                fighter.getCurrentCell(),
                fight.getCells()[Cell.decode(path.substring(path.length() - 2))]
        ).begin();
    }

    private void parseTurnEndRequestMessage() throws Exception {
        if (fight.getCurrentTurn().getFighter() != fighter){
            throw new Exception("Bad request: it isn't your turn.");
        }

        fight.getCurrentTurn().end();
    }
}
