package org.d2j.game.service.game.handler;

import org.d2j.common.NetworkStringBuffer;
import org.d2j.common.NumUtils;
import org.d2j.common.client.protocol.*;
import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.game.game.actions.*;
import org.d2j.game.game.channels.ChannelLogs;
import org.d2j.game.game.events.*;
import org.d2j.game.model.Character;
import org.d2j.game.model.Item;
import org.d2j.game.model.ItemTemplate;
import org.d2j.game.model.Spell;
import org.d2j.game.service.game.GameClient;
import org.d2j.game.service.game.GameClientHandler;
import org.d2j.game.service.game.GameService;
import org.d2j.utils.Point;

import java.util.Date;
import java.util.Observable;

/**
 * User: Blackrush
 * Date: 05/11/11
 * Time: 12:09
 * IDE:  IntelliJ IDEA
 */
public class RolePlayHandler extends GameClientHandler {
    private final ChannelLogs channelLogs = new ChannelLogs();

    public RolePlayHandler(GameService s, GameClient c) {
        super(s, c);

        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())) {
            buf.append(ChannelGameMessageFormatter.addChannelMessage(client.getAccount().getEnabledChannels().toString()));

            buf.append(SpellGameMessageFormatter.spellListMessage(
                    Spell.toBaseSpellType(client.getCharacter().getSpells().values())
            ));

            buf.append(ChannelGameMessageFormatter.enabledEmotesMessage("")); //todo emotes

            buf.append(ApproachGameMessageFormatter.setRestrictionsMessage());

            buf.append(ItemGameMessageFormatter.inventoryStatsMessage(
                    client.getCharacter().getStatistics().getUsedPods(),
                    client.getCharacter().getStatistics().getMaxPods()
            ));

            buf.append(FriendGameMessageFormatter.
                    notifyFriendOnConnectMessage(client.getAccount().isNotifyFriendsOnConnect()));

            buf.append(BasicGameMessageFormatter.currentDateMessage(new Date()));

            buf.append(InfoGameMessageFormatter.welcomeMessage());

            if (client.getAccount().getLastConnection() != null && client.getAccount().getLastAddress() != null) {
                buf.append(InfoGameMessageFormatter.lastConnectionInformationMessage(
                        client.getAccount().getLastConnection(),
                        client.getAccount().getLastAddress()
                ));
            }
            else{
                buf.append(InfoGameMessageFormatter.currentAddressInformationMessage(client.getRemoteAddress()));
            }
        }

        client.getAccount().setLastConnection(new Date());
        client.getAccount().setLastAddress(client.getRemoteAddress());

        client.getAccount().notifyObservers();

        service.getWorld().addObserver(this);

        client.log(service.getConfiguration().getMotd());
    }

    // todo (juste une ancre pour venir plus vite :o) )
    @Override
    public void parse(String packet) throws Exception {
        String[] args;
        switch (packet.charAt(0)){
            case 'B':
                switch (packet.charAt(1)){
                    case 'D':
                        parseCurrentDateRequestMessage();
                        break;

                    case 'M':
                        args = packet.substring(2).split("\\|");
                        if (args[0].length() > 1){
                            Character target = service.getWorld().getRepositoryManager().getCharacters().findByName(args[0]);
                            parseClientPrivateRequestMessage(target, args[1]);
                        }
                        else{
                            if (args[1].charAt(0) == client.getService().getConfiguration().getCommandPrefix()){
                                parseCommandRequestMessage(args[1].substring(1).split(" "));
                            }
                            else{
                                parseClientMultiRequestMessage(ChannelEnum.valueOf(packet.charAt(2)), args[1]);
                            }
                        }
                        break;
                }
                break;

            case 'c':
                switch (packet.charAt(1)){
                    case 'C':
                        parseAddChannelRequestMessage(
                                packet.charAt(2) == '+',
                                ChannelEnum.valueOf(packet.charAt(3))
                        );
                        client.getSession().write(packet);
                        break;
                }
                break;

            case 'G':
                switch (packet.charAt(1)){
                    case 'A':
                        parseGameActionRequestMessage(
                                ActionTypeEnum.valueOf(Integer.parseInt(packet.substring(2, 5))),
                                packet.substring(5)
                        );
                        break;

                    case 'C':
                        parseGameCreationRequestMessage();
                        break;

                    case 'I':
                        parseGameInformationsRequestMessage();
                        break;

                    case 'K':
                        parseGameActionEndRequestMessage(packet.charAt(2) == 'K', packet.substring(3));
                        break;
                }
                break;

            case 'P':
                switch (packet.charAt(1)){
                    case 'A':
                        parsePartyAcceptInvitationRequestMessage();
                        break;

                    case 'I':
                        parsePartyInvitationRequestMessage(packet.substring(2));
                        break;

                    case 'R':
                        parsePartyDeclineInvitationRequestMessage();
                        break;

                    case 'V':
                        parsePartyQuitRequestMessage(
                                packet.length() > 2 ?
                                        client.getParty().getMember(Long.parseLong(packet.substring(2))) :
                                        null
                        );
                        break;
                }
                break;

            case 'S':
                switch (packet.charAt(1)){
                    case 'B':
                        parseBoostSpellRequestMessage(client.getCharacter().getSpells().get(
                                Integer.parseInt(packet.substring(2))
                        ));
                        break;

                    case 'M':
                        args = packet.substring(2).split("\\|");
                        if (args.length != 2){
                            throw new Exception("Invalid request: bad data received.");
                        }

                        parseMoveSpellRequestMessage(
                                client.getCharacter().getSpells().get(Integer.parseInt(args[0])),
                                Byte.parseByte(args[1])
                        );
                        break;
                }
                break;
        }
    }

    /**
     * GameClientHandler implementation
     */
    @Override
    public void onClosed() {
        service.getWorld().getLoginServerManager().setAccountDeconnected(client.getAccount().getId());

        client.getAccount().setClient(null);

        client.getCharacter().getCurrentMap().deleteObserver(this);
        client.getCharacter().getCurrentMap().removeActor(client.getCharacter());

        service.getWorld().deleteObserver(this);
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof IEvent){
            IEvent argEvent = (IEvent)arg;
            switch (argEvent.getEventType()){
                case MESSAGE:
                    MessageEvent messageEvent = (MessageEvent)arg;

                    if (client.getAccount().getEnabledChannels().contains(messageEvent.getChannel())){
                        client.getSession().write(ChannelGameMessageFormatter.clientMultiMessage(
                                messageEvent.getChannel().toChar(),
                                messageEvent.getActorId(),
                                messageEvent.getActorName(),
                                messageEvent.getMessage()
                        ));
                    }
                    break;

                case SYSTEM_MESSAGE:
                    SystemMessageEvent systemMessageEvent = (SystemMessageEvent)arg;
                    client.info(systemMessageEvent.getMessage());
                    break;

                case MAP_UPDATE_ACTOR:
                    updateMapUpdateActorEvent((MapUpdateActorEvent) argEvent);
                    break;

                case PARTY_UPDATE_ACTOR:
                    updatePartyUpdateActorEvent((PartyUpdateMemberEvent)argEvent);
                    break;
            }
        }
        else if (arg instanceof RolePlayMovement){
            RolePlayMovement movement = (RolePlayMovement)arg;

            client.getSession().write(GameMessageFormatter.actorMovementMessage(
                    movement.getActor().getId(),
                    movement.getPath()
            ));
        }
    }

    private void updatePartyUpdateActorEvent(PartyUpdateMemberEvent partyUpdateMemberEvent) {
        switch (partyUpdateMemberEvent.getPartyUpdateMemberType()){
            case ADD:
                client.getSession().write(PartyGameMessageFormatter.
                        addMemberMessage(partyUpdateMemberEvent.getMember().toBasePartyMemberType()));
                break;

            case REMOVE:
                if (partyUpdateMemberEvent.getMember() == client.getCharacter()){
                    client.getParty().deleteObserver(this);
                    client.setParty(null);
                    client.getSession().write(PartyGameMessageFormatter.quitMessage());
                }
                else{
                    client.getSession().write(PartyGameMessageFormatter.
                            removeMemberMessage(partyUpdateMemberEvent.getMember().getId()));
                }
                break;

            case REFRESH:
                client.getSession().write(PartyGameMessageFormatter.
                        refreshMemberMessage(partyUpdateMemberEvent.getMember().toBasePartyMemberType()));
                break;

            case LEADER:
                client.getSession().write(PartyGameMessageFormatter.
                        leaderInformationMessage(partyUpdateMemberEvent.getMember().getId()));
                break;
        }
    }

    private void updateMapUpdateActorEvent(MapUpdateActorEvent mapUpdateActorEvent){
        switch (mapUpdateActorEvent.getMapUpdateType()){
            case ADD:
                client.getSession().write(GameMessageFormatter.
                        showActorMessage(mapUpdateActorEvent.getActor().toRolePlayCharacterType()));
                break;

            case REMOVE:
                client.getSession().write(GameMessageFormatter.
                        removeActorMessage(mapUpdateActorEvent.getActor().getId()));
                break;

            case SKIN:
                break;

            case SIZE:
                break;
        }
    }

    public void join(){
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            join(buf);
        }
    }

    public void join(NetworkStringBuffer buf){
        buf.append(GameMessageFormatter.gameCreationSuccessMessage());
        buf.append(client.getCharacter().getStatistics().getStatisticsMessage(service.getConfiguration()));
        buf.append(GameMessageFormatter.mapDataMessage(
                client.getCharacter().getCurrentMap().getId(),
                client.getCharacter().getCurrentMap().getDate(),
                client.getCharacter().getCurrentMap().getKey()
        ));
        buf.append(GameMessageFormatter.fightCountMessage(client.getCharacter().getCurrentMap().getNbFights()));
    }

    private void parseGameCreationRequestMessage() throws Exception {
        join();
    }

    private void parseCurrentDateRequestMessage(){
        client.getSession().write(BasicGameMessageFormatter.currentDateMessage(new Date()));
    }

    private void parseGameInformationsRequestMessage() {
        client.getCharacter().getCurrentMap().addActor(client.getCharacter());

        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            buf.append(GameMessageFormatter.showActorsMessage(Character.toRolePlayCharacterType(
                    client.getCharacter().getCurrentMap().getActors()
            )));
            buf.append(GameMessageFormatter.mapLoadedMessage());
            buf.append(GameMessageFormatter.fightCountMessage(0)); //todo fights
        }

        client.getCharacter().getCurrentMap().addObserver(this);
    }

    private void parseGameActionRequestMessage(ActionTypeEnum actionId, String args) throws Exception {
        switch (actionId){
            case MOVEMENT:
                parseMovementRequestMessage(args);
                break;

            case ASK_FIGHT:
                parseChallengeRequestMessage(service.getWorld().getRepositoryManager().getCharacters().findById(Long.parseLong(args)));
                break;

            case ACCEPT_FIGHT:
                parseChallengeAcceptRequestMessage();
                break;

            case DECLINE_FIGHT:
                parseChallengeDeclineRequestMessage();
                break;
        }
    }

    private void parseMovementRequestMessage(String path) throws Exception {
        if (client.isBusy()){
            client.getSession().write(BasicGameMessageFormatter.noOperationMessage());
        }
        else{
            RolePlayMovement movement = new RolePlayMovement(path, client);
            client.getActions().push(movement);

            movement.begin();
        }
    }

    private void parseGameActionEndRequestMessage(boolean success, String args) throws Exception {
        if (success){
            client.getActions().pop().end();
        }
        else {
            if (client.getActions().peek().getActionType() != GameActionType.MOVEMENT)
                throw new Exception("invalid action : peeked action isn't a movement");

            ((RolePlayMovement)client.getActions().pop()).cancel(Short.parseShort(args.substring(2)));
        }
    }

    private void parseClientPrivateRequestMessage(Character target, String message) {
        if (target != null){
            target.getOwner().getClient().getSession().write(ChannelGameMessageFormatter.clientPrivateMessage(
                    true,
                    client.getCharacter().getId(),
                    client.getCharacter().getName(),
                    message
            ));

            client.getSession().write(ChannelGameMessageFormatter.clientPrivateMessage(
                    false,
                    client.getCharacter().getId(),
                    client.getCharacter().getName(),
                    message
            ));
        }
        else{
            client.getSession().write(ChannelGameMessageFormatter.clientMultiErrorMessage());
        }
    }

    private void parseClientMultiRequestMessage(ChannelEnum channel, String message) {
        if (!client.getAccount().getEnabledChannels().contains(channel)){
            client.getSession().write(BasicGameMessageFormatter.noOperationMessage());
        }
        else switch (channel){
            case General:
                client.getCharacter().getCurrentMap().speak(client.getCharacter(), channel, message);
                break;

            case Admin: if (!client.getAccount().hasRights()) break;
            case Alignment:
            case Trade:
            case Recruitment:
                if (channelLogs.getDuration(channel) >=
                    service.getConfiguration().getChannelRestrictions().get(channel))
                {
                    channelLogs.add(channel);

                    service.getWorld().speak(
                            client.getCharacter(),
                            channel,
                            message
                    );
                }
                else{
                    client.getSession().write(InfoGameMessageFormatter.
                            floodMessage(channelLogs.getRemaining(channel, service.getConfiguration())));
                }
                break;

            case Guild:
                break;

            case Party:
                if (client.getParty() != null){
                    client.getParty().speak(client.getCharacter(), message);
                }
                break;

            default:
                break;
        }
    }

    private void parseChallengeRequestMessage(Character target) throws Exception {
        if (target == null)
            throw new Exception("unknown target");

        GameClient targetClient = target.getOwner().getClient();
        if (!client.getCharacter().getCurrentMap().canFight()){
            client.log("Impossible de combattre sur cette map.");
        }
        else if (targetClient.isBusy() || client.isBusy()){
            client.log("La cible est occupée.");
        }
        else if (target.getCurrentMap() != client.getCharacter().getCurrentMap()){
            client.log("La cible n'est pas sur la même map que vous.");
        }
        else{
            ChallengeRequestInvitation invitation = new ChallengeRequestInvitation(client, targetClient);
            client.getActions().push(invitation);
            targetClient.getActions().push(invitation);

            invitation.begin();
        }
    }

    private void parseChallengeAcceptRequestMessage() throws Exception {
        if (client.getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION)
            throw new Exception("Bad request: current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");

        ChallengeRequestInvitation invitation = (ChallengeRequestInvitation)client.getActions().pop();

        if (invitation.getSender() == client)
            throw new Exception("Bad request: sender can't accept challenge.");

        if (invitation.getSender().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION)
            throw new Exception("Bad request: target's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");

        invitation.getSender().getActions().pop();

        invitation.accept();
    }

    private void parseChallengeDeclineRequestMessage() throws Exception {
        if (client.getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
            throw new Exception("Bad request: current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
        }

        ChallengeRequestInvitation invitation = (ChallengeRequestInvitation) client.getActions().pop();

        if (invitation.getSender() == client){
            if (invitation.getTarget().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
                throw new Exception("Bad request: target's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
            }
            invitation.getTarget().getActions().pop();
        }
        else{
            if (invitation.getSender().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
                throw new Exception("Bad request: sender's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
            }
            invitation.getSender().getActions().pop();
        }

        invitation.decline();
    }

    private void parseBoostSpellRequestMessage(Spell spell) {
        int cost = spell.getLevel();

        if (spell.getLevel() >= client.getService().getConfiguration().getMaxLevelSpell()){
            client.getSession().write(SpellGameMessageFormatter.boostSpellErrorMessage());
        }
        else if (cost > client.getCharacter().getSpellsPoints()){
            client.getSession().write(SpellGameMessageFormatter.boostSpellErrorMessage());
        }
        else{
            client.getCharacter().addSpellsPoints((short) -cost);
            spell.addLevel(NumUtils.ONE_SHORT);

            try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
                buf.append(SpellGameMessageFormatter.boostSpellSuccessMessage(
                        spell.getTemplate().getId(),
                        spell.getLevel()
                ));

                buf.append(client.getCharacter().getStatistics().getStatisticsMessage(service.getConfiguration()));
            }
        }
    }

    private void parseMoveSpellRequestMessage(Spell spell, byte position) {
        client.getSession().write(BasicGameMessageFormatter.noOperationMessage());

        if (spell != null){
            if (position == -1){
                spell.setPosition((byte) -1);
            }
            else{
                for (Spell s : client.getCharacter().getSpells().values()){
                    if (s.getPosition() == position){
                        s.setPosition((byte) -1);
                    }
                }

                spell.setPosition(position);
            }
        }
    }

    private void parseCommandRequestMessage(String[] args) {
        //todo

        switch (args[0]){
            case "pos":
                Point pos = client.getCharacter().getCurrentMap().getCells()[client.getCharacter().getCurrentCellId()].getPosition();
                client.log("Votre position : " + pos);
                break;

            case "item":
                int itemTemplateId = Integer.parseInt(args[1]);
                ItemTemplate itemTemplate = service.getWorld().getRepositoryManager().getItemTemplates().findById(itemTemplateId);
                if (itemTemplate != null){
                    Item item = itemTemplate.generate();
                    item.setOwner(client.getCharacter());
                    service.getWorld().getRepositoryManager().getItems().create(item);

                    client.getCharacter().getBag().add(item);
                    client.getCharacter().getBag().factorize();

                    client.log("L'objet {0} a été créé.", itemTemplate.getName());
                }
                else{
                    client.log("L'objet demandé est introuvable.");
                }
                break;

            default:
                client.log("La commande demandée n'est pas disponible.");
                break;
        }
    }

    private void parseAddChannelRequestMessage(boolean add, ChannelEnum channel) {
        if (add){
            if (!client.getAccount().getEnabledChannels().contains(channel)){
                client.getAccount().getEnabledChannels().add(channel);
            }
        }
        else{
            client.getAccount().getEnabledChannels().remove(channel);
        }
    }

    private void parsePartyInvitationRequestMessage(String targetName) throws GameActionException {
        Character targetCharacter = service.getWorld().getRepositoryManager().getCharacters().findByName(targetName);
        if (targetCharacter != null && targetCharacter != client.getCharacter()){
            GameClient target = targetCharacter.getOwner().getClient();

            if (target == null){
                client.getSession().write(PartyGameMessageFormatter.targetNotFoundMessage(targetName));
            }
            else if (target.isBusy()){
                client.log("{0} est occupé.", InfoGameMessageFormatter.urlize(targetName));
            }
            else if (target.getParty() != null){
                client.getSession().write(PartyGameMessageFormatter.targetAlreadyInPartyMessage(targetName));
            }
            else{
                PartyRequestInvitation invitation = new PartyRequestInvitation(client, target);

                client.getActions().push(invitation);
                target.getActions().push(invitation);

                invitation.begin();
            }
        }
        else{
            client.getSession().write(PartyGameMessageFormatter.targetNotFoundMessage(targetName));
        }
    }

    private void parsePartyAcceptInvitationRequestMessage() throws GameActionException {
        if (!client.currentActionIs(GameActionType.CHALLENGE_REQUEST_INVITATION)){
            ((PartyRequestInvitation)client.getCurrentAction()).accept();
        }
        else{
            client.getSession().close(true);
        }
    }

    private void parsePartyDeclineInvitationRequestMessage() throws GameActionException {
        if (!client.currentActionIs(GameActionType.CHALLENGE_REQUEST_INVITATION)){
            ((PartyRequestInvitation)client.getCurrentAction()).decline();
        }
        else{
            client.getSession().close(true);
        }
    }

    private void parsePartyQuitRequestMessage(Character member) {
        if (client.getParty() == null){
            client.getSession().close(true);
        }
        else if (member != null){
            if (client.getParty().getLeader() != client.getCharacter()){
                client.log("Vous n'êtes pas le chef du groupe.");
            }
            else{
                client.getParty().removeMember(member);
            }
        }
        else{
            client.getParty().removeMember(client.getCharacter());
            client.getParty().deleteObserver(this);
            client.setParty(null);

            client.getSession().write(PartyGameMessageFormatter.quitMessage());
        }
    }
}
