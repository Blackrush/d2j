package org.d2j.game.service.game;

import org.apache.mina.core.session.IoSession;
import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.ApproachGameMessageFormatter;
import org.d2j.common.client.protocol.ChannelGameMessageFormatter;
import org.d2j.game.game.Party;
import org.d2j.game.game.actions.GameActionType;
import org.d2j.game.game.actions.IGameAction;
import org.d2j.game.model.Character;
import org.d2j.game.model.GameAccount;

import java.util.Stack;

/**
 * User: Blackrush
 * Date: 01/11/11
 * Time: 09:48
 * IDE : IntelliJ IDEA
 */
public class GameClient {
    private final IoSession session;
    private final GameService service;
    private GameClientHandler handler;

    private GameAccount account;
    private Character character;
    private Stack<IGameAction> actions = new Stack<>();
    private Party party;

    public GameClient(GameService service, IoSession s) {
        this.service = service;
        this.session = s;

        this.session.write(ApproachGameMessageFormatter.helloGameMessage());
    }

    public IoSession getSession() {
        return session;
    }

    public GameService getService() {
        return service;
    }

    public String getRemoteAddress(){
        String address = session.getRemoteAddress().toString();
        return address.substring(1, address.indexOf(':'));
    }

    public boolean isLocalhost(){
        String address = getRemoteAddress();
        return address.equals("127.0.0.1") || address.equals("localhost");
    }

    public GameClientHandler getHandler() {
        return handler;
    }

    public void setHandler(GameClientHandler handler) {
        this.handler = handler;
    }

    public GameAccount getAccount() {
        return account;
    }

    public void setAccount(GameAccount account) {
        this.account = account;
    }

    public Character getCharacter() {
        return character;
    }

    public void setCharacter(Character character) {
        this.character = character;
    }

    public Stack<IGameAction> getActions() {
        return actions;
    }

    public boolean isBusy(){
        return actions.size() > 0;
    }

    public Party getParty() {
        return party;
    }

    public void setParty(Party party) {
        this.party = party;
    }

    public void log(String message){
        session.write(ChannelGameMessageFormatter.informationMessage("<b>(Information)</b> " + message));
    }

    public void log(String message, Object... args){
        session.write(ChannelGameMessageFormatter.informationMessage("<b>(Information)</b> " + StringUtil.formatString(message, args)));
    }

    public void info(String message){
        session.write(ChannelGameMessageFormatter.informationMessage(message));
    }

    public boolean currentActionIs(GameActionType gameActionType){
        return actions.size() > 0 && actions.peek().getActionType().equals(gameActionType);
    }

    public IGameAction getCurrentAction(){
        return actions.size() > 0 ? actions.peek() : null;
    }
}
