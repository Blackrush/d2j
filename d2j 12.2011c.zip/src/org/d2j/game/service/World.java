package org.d2j.game.service;

import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.common.client.protocol.enums.WorldStateEnum;
import org.d2j.game.RepositoryManager;
import org.d2j.game.game.events.MessageEvent;
import org.d2j.game.game.events.SystemMessageEvent;
import org.d2j.game.model.Character;
import org.d2j.game.service.game.GameService;
import org.d2j.game.service.login.ILoginServerManager;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Observable;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 18:28
 * IDE : IntelliJ IDEA
 */
@Singleton
public class World extends Observable implements IWorld {
    private ILoginServerManager loginServerManager;
    private RepositoryManager repositoryManager;
    private GameService gameService;
    private WorldStateEnum state;
    private int completion;

    @Inject
    public World(ILoginServerManager loginServerManager, RepositoryManager repositoryManager, GameService gameService) {
        this.loginServerManager = loginServerManager;
        this.repositoryManager = repositoryManager;
        this.gameService = gameService;
        this.state = WorldStateEnum.ONLINE;
        this.completion = 0;
    }

    public ILoginServerManager getLoginServerManager() {
        return loginServerManager;
    }

    public RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    public GameService getGameService() {
        return gameService;
    }

    public WorldStateEnum getState() {
        return state;
    }

    public void setState(WorldStateEnum state) {
        this.state = state;
        if (loginServerManager != null && loginServerManager.isSynchronized()){
            loginServerManager.refreshWorld();
        }
    }

    public int getCompletion() {
        return completion;
    }

    public void setCompletion(int completion) {
        this.completion = completion;
        if (loginServerManager != null && loginServerManager.isSynchronized()){
            loginServerManager.refreshWorld();
        }
    }

    public void speak(Character actor, ChannelEnum channel, String message){
        setChanged();
        notifyObservers(new MessageEvent(actor.getId(), actor.getName(), channel, message));
    }

    @Override
    public void systemMessage(SystemMessageEvent event) {
        setChanged();
        notifyObservers(event);
    }
}
