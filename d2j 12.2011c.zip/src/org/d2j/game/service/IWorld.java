package org.d2j.game.service;

import org.d2j.common.client.protocol.enums.ChannelEnum;
import org.d2j.common.client.protocol.enums.WorldStateEnum;
import org.d2j.game.RepositoryManager;
import org.d2j.game.game.events.SystemMessageEvent;
import org.d2j.game.model.Character;
import org.d2j.game.service.game.GameService;
import org.d2j.game.service.login.ILoginServerManager;

import java.util.Observer;

/**
 * User: Blackrush
 * Date: 24/12/11
 * Time: 16:40
 * IDE : IntelliJ IDEA
 */
public interface IWorld {
    ILoginServerManager getLoginServerManager();
    RepositoryManager getRepositoryManager();
    GameService getGameService();

    WorldStateEnum getState();
    void setState(WorldStateEnum state);

    int getCompletion();
    void setCompletion(int completion);

    void speak(Character actor, ChannelEnum channel, String message);

    void addObserver(Observer observer);
    void deleteObserver(Observer observer);

    void systemMessage(SystemMessageEvent event);
}
