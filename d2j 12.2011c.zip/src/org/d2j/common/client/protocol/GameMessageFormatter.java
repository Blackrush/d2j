package org.d2j.common.client.protocol;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.type.RolePlayCharacterType;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.game.statistics.ICharacteristic;
import org.d2j.game.game.statistics.IStatistics;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 09:32
 * IDE : IntelliJ IDEA
 */
public class GameMessageFormatter {
    public static String gameCreationSuccessMessage(){
        return "GCK|1|";
    }

    public static String mapDataMessage(int id, String date, String key){
        return "GDM|" + id + "|" + date + "|" + key;
    }

    public static String fightCountMessage(int fights){
        return "fC" + fights;
    }

    public static String mapLoadedMessage(){
        return "GDK";
    }

    public static String statisticsMessage
            (long currentExperience, long minExp, long maxExp,
             int kamas,
             short statsPoints, short spellsPoints,
             int alignId, short alignLevel, short alignGrade, int honor, int dishonor, boolean pvpEnabled,
             short lifePoints, short maxLifePoints,
             short energy, short maxEnergy,
             short initiative,
             short prospection,
             IStatistics statistics)
    {
        CharacteristicType[] characs = CharacteristicType.values();
        ICharacteristic actionPoints = statistics.get(CharacteristicType.ActionPoints),
                        movementPoints = statistics.get(CharacteristicType.MovementPoints);

        StringBuilder sb = new StringBuilder(500).append("As");

        sb.append(currentExperience).append(',').append(minExp).append(',').append(maxExp).append('|');
        sb.append(kamas).append('|');
        sb.append(statsPoints).append('|').append(spellsPoints).append('|');
        sb.append(alignId).append('~').append(alignId).append(',')
          .append(alignLevel).append(',')
          .append(alignGrade).append(',')
          .append(honor).append(',')
          .append(dishonor).append(',')
          .append(pvpEnabled ? "1|" : "0|");
        sb.append(lifePoints).append(',').append(maxLifePoints).append('|');
        sb.append(energy).append(',').append(maxEnergy).append('|');
        sb.append(initiative).append('|')
          .append(prospection).append('|');

        sb.append(actionPoints.getBase()).append(',')
          .append(actionPoints.getEquipments()).append(',')
          .append(actionPoints.getGifts()).append(',')
          .append(actionPoints.getContext()).append(',')
          .append(actionPoints.getSafeTotal()).append('|');

        sb.append(movementPoints.getBase()).append(',')
          .append(movementPoints.getEquipments()).append(',')
          .append(movementPoints.getGifts()).append(',')
          .append(movementPoints.getContext()).append(',')
          .append(movementPoints.getSafeTotal()); // no |  => see for-loop

        for (int i = 4; i < characs.length; ++i){
            ICharacteristic charac = statistics.get(characs[i]);

            sb.append('|');
            sb.append(charac.getBase()).append(',');
            sb.append(charac.getEquipments()).append(',');
            sb.append(charac.getGifts()).append(',');
            sb.append(charac.getContext()).append(',');
        }

        return sb.toString();
    }

    public static String showActorMessage(RolePlayCharacterType actor){
        StringBuilder sb = new StringBuilder(40).append("GM|+");
        getRolePlayCharacterTypePattern(sb, actor);
        return sb.toString();
    }

    public static String showActorsMessage(Collection<RolePlayCharacterType> actors){
        StringBuilder sb = new StringBuilder(10 + 30 * actors.size()).append("GM");
        for (RolePlayCharacterType actor : actors){
            sb.append("|+");
            getRolePlayCharacterTypePattern(sb, actor);
        }
        return sb.toString();
    }

    private static void getRolePlayCharacterTypePattern(StringBuilder sb, RolePlayCharacterType player){
        sb.append(player.getCurrentCellId()).append(';')
          .append(player.getCurrentDirection().ordinal()).append(';')
          .append("0;");

        sb.append(player.getId()).append(';')
          .append(player.getName()).append(';')
          .append(player.getBreedId()).append(';')
          .append(player.getSkin()).append('^').append(player.getSize()).append(';')
          .append(player.isGender() ? '1' : '0').append(';');

        sb.append("0,0,0,0").append(';'); //todo alignment

        sb.append(StringUtil.toHexOrNegative(player.getColor1())).append(';')
          .append(StringUtil.toHexOrNegative(player.getColor2())).append(';')
          .append(StringUtil.toHexOrNegative(player.getColor3())).append(';');

        boolean first = true;
        for (int accessory : player.getAccessories()){
            if (first) first = false;
            else sb.append(',');

            sb.append(accessory == 0 ? "" : StringUtil.toHex(accessory));
        }
        sb.append(';');

        sb.append(player.getLevel() >= 100 ? (player.getLevel() == 200 ? '2' : '1') : '0');

        sb.append(';')
          .append(';');

        sb.append(player.getGuildName()).append(';');

        sb.append(';')
          .append("0;;");
    }

    public static String removeActorMessage(Long id) {
        return "GM|-" + id;
    }

    public static String actorMovementMessage(long actorId, String path){
        return "GA1;1;" + actorId + ";" + path;
    }

    public static String changeMapMessage(long actorId){
        return "GA;2;" + actorId + ";";
    }

    public static String challengeRequestMessage(long senderId, long challengedId){
        return "GA;900;" + senderId + ";" + challengedId;
    }

    public static String challengeAcceptedMessage(long senderId, long challengedId){
        return "GA;901;" + senderId + ";" + challengedId;
    }

    public static String challengeDeclinedMessage(long senderId, long challengedId){
        return "GA;902;" + senderId + ";" + challengedId;
    }
}
