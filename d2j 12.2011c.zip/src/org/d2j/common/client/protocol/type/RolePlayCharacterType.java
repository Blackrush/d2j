package org.d2j.common.client.protocol.type;

import org.d2j.common.client.protocol.enums.OrientationEnum;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 12:41
 * IDE : IntelliJ IDEA
 */
public class RolePlayCharacterType {
    private long id;
    private String name;
    private byte breedId;
    private short skin, size;
    private boolean gender;
    private short level;
    //todo alignment
    private int color1, color2, color3;
    private int[] accessories;
    private short currentCellId;
    private OrientationEnum currentDirection;
    private String guildName;

    public RolePlayCharacterType() {

    }

    public RolePlayCharacterType(long id, String name, byte breedId, short skin, short size, boolean gender, short level, int color1, int color2, int color3, int[] accessories, short currentCellId, OrientationEnum currentDirection, String guildName) {
        this.id = id;
        this.name = name;
        this.breedId = breedId;
        this.skin = skin;
        this.size = size;
        this.gender = gender;
        this.level = level;
        this.color1 = color1;
        this.color2 = color2;
        this.color3 = color3;
        this.accessories = accessories;
        this.currentCellId = currentCellId;
        this.currentDirection = currentDirection;
        this.guildName = guildName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte getBreedId() {
        return breedId;
    }

    public void setBreedId(byte breedId) {
        this.breedId = breedId;
    }

    public short getSkin() {
        return skin;
    }

    public void setSkin(short skin) {
        this.skin = skin;
    }

    public short getSize() {
        return size;
    }

    public void setSize(short size) {
        this.size = size;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public short getLevel() {
        return level;
    }

    public void setLevel(short level) {
        this.level = level;
    }

    public int getColor1() {
        return color1;
    }

    public void setColor1(int color1) {
        this.color1 = color1;
    }

    public int getColor2() {
        return color2;
    }

    public void setColor2(int color2) {
        this.color2 = color2;
    }

    public int getColor3() {
        return color3;
    }

    public void setColor3(int color3) {
        this.color3 = color3;
    }

    public int[] getAccessories() {
        return accessories;
    }

    public void setAccessories(int[] accessories) {
        this.accessories = accessories;
    }

    public short getCurrentCellId() {
        return currentCellId;
    }

    public void setCurrentCellId(short currentCellId) {
        this.currentCellId = currentCellId;
    }

    public OrientationEnum getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(OrientationEnum currentDirection) {
        this.currentDirection = currentDirection;
    }

    public String getGuildName() {
        return guildName;
    }

    public void setGuildName(String guildName) {
        this.guildName = guildName;
    }
}
