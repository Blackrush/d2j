package org.d2j.common.client.protocol;

/**
 * User: Blackrush
 * Date: 06/11/11
 * Time: 10:15
 * IDE:  IntelliJ IDEA
 */
public class ItemGameMessageFormatter {
    public static String inventoryStatsMessage(int usedPods, int maxPods){
        return "Ow" + usedPods + "|" + maxPods;
    }
}
