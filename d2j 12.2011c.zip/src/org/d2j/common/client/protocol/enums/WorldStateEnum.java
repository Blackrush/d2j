package org.d2j.common.client.protocol.enums;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 10:29
 * IDE : IntelliJ IDEA
 */
public enum WorldStateEnum {
    OFFLINE,
    ONLINE,
    SAVING;
}
