package org.d2j.game.model;

import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.common.client.protocol.type.BaseCharacterType;
import org.d2j.common.client.protocol.type.RolePlayCharacterType;
import org.d2j.game.game.Experience;
import org.d2j.game.game.statistics.CharacterStatistics;
import org.d2j.utils.database.IEntity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Observable;

/**
 * User: Blackrush
 * Date: 01/11/11
 * Time: 18:33
 * IDE : IntelliJ IDEA
 */
public class Character extends Observable implements IEntity<Long> {
    public static Collection<BaseCharacterType> toBaseCharacterType(Collection<Character> characters){
        List<BaseCharacterType> t = new ArrayList<>(characters.size());
        for (Character c : characters)
            t.add(c.toBaseCharacterType());
        return t;
    }

    public static Collection<RolePlayCharacterType> toRolePlayCharacterType(Collection<Character> characters){
        List<RolePlayCharacterType> t = new ArrayList<>(characters.size());
        for (Character c : characters){
            t.add(c.toRolePlayCharacterType());
        }
        return t;
    }

    private Long id;
    private GameAccount owner;
    private String name;
    private BreedTemplate breed;
    private boolean gender;
    private int color1, color2, color3;
    private short skin, size;
    private Experience experience;
    private CharacterStatistics statistics;
    private short energy;
    private int kamas;
    private short statsPoints, spellsPoints;
    private int[] accessories = new int[5];
    private Map currentMap;
    private short currentCellId;
    private OrientationEnum currentOrientation;
    private Map memorizedMap;

    public Character() {

    }

    public Character(Long id, GameAccount owner, String name, BreedTemplate breed, boolean gender, int color1, int color2, int color3, short skin, short size, Experience experience, CharacterStatistics statistics, short energy, int kamas, short statsPoints, short spellsPoints, Map currentMap, short currentCellId, OrientationEnum currentOrientation, Map memorizedMap) {
        this.id = id;
        this.owner = owner;
        this.name = name;
        this.breed = breed;
        this.gender = gender;
        this.color1 = color1;
        this.color2 = color2;
        this.color3 = color3;
        this.skin = skin;
        this.size = size;
        this.experience = experience;
        this.statistics = statistics;
        this.energy = energy;
        this.kamas = kamas;
        this.statsPoints = statsPoints;
        this.spellsPoints = spellsPoints;
        this.currentMap = currentMap;
        this.currentCellId = currentCellId;
        this.currentOrientation = currentOrientation;
        this.memorizedMap = memorizedMap;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public GameAccount getOwner() {
        return owner;
    }

    public void setOwner(GameAccount owner) {
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BreedTemplate getBreed() {
        return breed;
    }

    public void setBreed(BreedTemplate breed) {
        this.breed = breed;
    }

    public boolean getGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public int getColor1() {
        return color1;
    }

    public void setColor1(int color1) {
        this.color1 = color1;
    }

    public int getColor2() {
        return color2;
    }

    public void setColor2(int color2) {
        this.color2 = color2;
    }

    public int getColor3() {
        return color3;
    }

    public void setColor3(int color3) {
        this.color3 = color3;
    }

    public short getSkin() {
        return skin;
    }

    public void setSkin(short skin) {
        this.skin = skin;
    }

    public short getSize() {
        return size;
    }

    public void setSize(short size) {
        this.size = size;
    }

    public Experience getExperience() {
        return experience;
    }

    public void setExperience(Experience experience) {
        this.experience = experience;
    }

    public CharacterStatistics getStatistics() {
        return statistics;
    }

    public void setStatistics(CharacterStatistics statistics) {
        this.statistics = statistics;
    }

    public short getEnergy() {
        return energy;
    }

    public void setEnergy(short energy) {
        this.energy = energy;
    }

    public int getKamas() {
        return kamas;
    }

    public void setKamas(int kamas) {
        this.kamas = kamas;
    }

    public short getStatsPoints() {
        return statsPoints;
    }

    public void setStatsPoints(short statsPoints) {
        this.statsPoints = statsPoints;
    }

    public short getSpellsPoints() {
        return spellsPoints;
    }

    public void setSpellsPoints(short spellsPoints) {
        this.spellsPoints = spellsPoints;
    }

    public int[] getAccessories() {
        return accessories;
    }

    public Map getCurrentMap() {
        return currentMap;
    }

    public void setCurrentMap(Map currentMap) {
        this.currentMap = currentMap;
    }

    public short getCurrentCellId() {
        return currentCellId;
    }

    public void setCurrentCellId(short currentCellId) {
        this.currentCellId = currentCellId;
    }

    public OrientationEnum getCurrentOrientation() {
        return currentOrientation;
    }

    public void setCurrentOrientation(OrientationEnum currentOrientation) {
        this.currentOrientation = currentOrientation;
    }

    public Map getMemorizedMap() {
        return memorizedMap;
    }

    public void setMemorizedMap(Map memorizedMap) {
        this.memorizedMap = memorizedMap;
    }

    public BaseCharacterType toBaseCharacterType(){
        return new BaseCharacterType(
                id,
                name,
                experience.getLevel(),
                skin,
                color1, color2, color3,
                accessories
        );
    }

    public RolePlayCharacterType toRolePlayCharacterType(){
        return new RolePlayCharacterType(
                id,
                name,
                breed.getId(),
                skin,
                size,
                gender,
                experience.getLevel(),
                color1, color2, color3,
                accessories,
                currentCellId,
                currentOrientation,
                ""
        );
    }

    public void beforeCreate() {

    }

    public void beforeDelete() {

    }

    public void onCreated() {

    }

    public void onDeleted() {

    }

    public void beforeSave() {

    }

    public void onSaved() {

    }
}
