package org.d2j.game.repository;

import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.model.BreedTemplate;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:19
 * IDE : IntelliJ IDEA
 */
public class RepositoryManager {
    private static final Logger logger = LoggerFactory.getLogger(RepositoryManager.class);

    private final IGameConfiguration configuration;

    private final EntitiesContext dynamicContext;
    private final EntitiesContext staticContext;
    private boolean started;

    private final AccountRepository accounts;
    private final CharacterRepository characters;

    private final BreedTemplateRepository breedTemplates;
    private final ExperienceTemplateRepository experienceTemplates;
    private final MapRepository maps;
    private final MapTriggerRepository mapTriggers;

    public RepositoryManager(IGameConfiguration c) throws ClassNotFoundException {
        this.configuration = c;

        dynamicContext = new EntitiesContext(
                configuration.getDynamicConnectionInformations(),
                configuration.getExecutionInterval()
        );
        staticContext = new EntitiesContext(
                configuration.getStaticConnectionInformations(),
                -1
        );

        breedTemplates = new BreedTemplateRepository(staticContext);
        experienceTemplates = new ExperienceTemplateRepository(staticContext);
        maps = new MapRepository(staticContext);
        mapTriggers = new MapTriggerRepository(staticContext, maps);

        accounts = new AccountRepository(dynamicContext);
        characters = new CharacterRepository(
                dynamicContext,

                breedTemplates,
                experienceTemplates,
                accounts,
                maps
        );
    }

    private void loadStaticContext() throws SQLException, LoadingException {
        logger.info("{} breed templates loaded.", breedTemplates.loadAll());
        logger.info("{} experience templates loaded.", experienceTemplates.loadAll());
        logger.info("{} maps loaded.", maps.loadAll(configuration.getMapsLoadingLimit()));
        logger.info("{} map triggers loaded.", mapTriggers.loadAll());
    }

    private void loadDynamicContext() throws SQLException, LoadingException {
        logger.info("{} accounts loaded.", accounts.loadAll());
        logger.info("{} characters loaded.", characters.loadAll());
    }

    private void saveDynamicContext() throws SQLException {
        logger.info("{} characters saved.", characters.saveAll());
        logger.info("{} accounts saved.", accounts.saveAll());
    }

    public void start(){
        if (started) return;

        try {
            staticContext.start();
            loadStaticContext();
            staticContext.stop();

            dynamicContext.start();
            loadDynamicContext();

            started = true;
        } catch (SQLException e) {
            logger.error("Can't begin RepositoryManager.", e.getCause());
        } catch (LoadingException e){
            logger.error("Can't load RepositoryManager.", e.getCause());
        }
    }

    public void stop(){
        if (!started) return;

        try {
            dynamicContext.commit();

            saveDynamicContext();
            dynamicContext.commit();

            dynamicContext.stop();

            started = false;
        } catch (SQLException e) {
            logger.error("Can't end RepositoryManager.", e.getCause());
        }
    }

    public AccountRepository getAccounts() {
        return accounts;
    }

    public CharacterRepository getCharacters() {
        return characters;
    }

    public BreedTemplateRepository getBreedTemplates() {
        return breedTemplates;
    }

    public ExperienceTemplateRepository getExperienceTemplates() {
        return experienceTemplates;
    }

    public MapRepository getMaps() {
        return maps;
    }

    public MapTriggerRepository getMapTriggers() {
        return mapTriggers;
    }
}
