package org.d2j.game.repository;

import org.d2j.game.model.Map;
import org.d2j.game.model.MapTrigger;
import org.d2j.utils.database.BaseEntityRepository;
import org.d2j.utils.database.EntitiesContext;
import org.d2j.utils.database.LoadingException;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 17:14
 * IDE : IntelliJ IDEA
 */
public class MapTriggerRepository extends BaseEntityRepository<MapTrigger, Integer> {
    private final MapRepository maps;

    protected MapTriggerRepository(EntitiesContext context, MapRepository maps) {
        super(context);

        this.maps = maps;
    }

    @Override
    protected String getLoadQuery() {
        return "SELECT * FROM `map_triggers`;";
    }

    @Override
    protected String getLoadOneQuery(Integer id) {
        return "SELECT * FROM `map_triggers` WHERE `id`='" + id + "';";
    }

    @Override
    protected MapTrigger loadOne(ResultSet reader) throws SQLException {
        Map map     = maps.findById(reader.getInt("map")),
            nextMap = maps.findById(reader.getInt("nextMap"));
        if (map == null || nextMap == null) return null;

        MapTrigger trigger = new MapTrigger(
                reader.getInt("id"),
                map,
                reader.getShort("cell"),
                nextMap,
                reader.getShort("nextCell")
        );

        map.getTriggers().put(trigger.getCellId(), trigger);

        return trigger;
    }

    @Override
    protected void beforeLoading() throws LoadingException {
        if (!maps.isLoaded()) throw new LoadingException("MapRepository must be loaded.");
    }
}
