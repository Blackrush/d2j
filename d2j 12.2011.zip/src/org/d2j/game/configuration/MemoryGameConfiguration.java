package org.d2j.game.configuration;

import org.d2j.utils.database.ConnectionStringBuilder;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 16:09
 * IDE : IntelliJ IDEA
 */
public class MemoryGameConfiguration implements IGameConfiguration {
    public String getRemoteAddress() {
        return "127.0.0.1";
    }

    public int getRemotePort() {
        return 5555;
    }

    public String getSystemAddress() {
        return "127.0.0.1";
    }

    public int getSystemPort() {
        return 4443;
    }

    public ConnectionStringBuilder getDynamicConnectionInformations() {
        return new ConnectionStringBuilder("localhost", "d2j_game1", "root", "");
    }

    public ConnectionStringBuilder getStaticConnectionInformations() {
        return new ConnectionStringBuilder("localhost", "d2j_static", "root", "");
    }

    public long getExecutionInterval() {
        return 5 * 60;
    }

    @Override
    public long getMapsLoadingLimit() {
        return -1;
    }

    public int getServerId() {
        return 1;
    }

    public boolean getCharacterNameSuggestionEnabled() {
        return true;
    }

    public short getMaxCharactersPerAccount() {
        return 6;
    }

    public int getDeletionAnswerRequiredLevel() {
        return 10;
    }

    public short getStartSize() {
        return 100;
    }

    public short getStartLevel() {
        return 151;
    }

    public short getStartEnergy() {
        return getMaxEnergy();
    }

    public int getStartKamas() {
        return 1000000;
    }

    @Override
    public int getStartMapId() {
        return 7411;
    }

    @Override
    public short getStartCellId() {
        return 335;
    }

    @Override
    public int getDefaultMemorizedMapId() {
        return 7411;
    }

    public short getMaxEnergy() {
        return 10000;
    }

    @Override
    public int getPreparationDelay() {
        return 45;
    }

    @Override
    public int getTurnDelay() {
        return 29;
    }
}
