package org.d2j.game;

import org.d2j.common.service.protocol.MessageFactory;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.configuration.MemoryGameConfiguration;
import org.d2j.game.repository.RepositoryManager;
import org.d2j.game.service.World;
import org.d2j.game.service.game.GameService;
import org.d2j.game.service.login.LoginServerManager;

import java.io.IOException;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 13:18
 * IDE : IntelliJ IDEA
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException, IOException {
        MessageFactory.getInstance().init();
        IGameConfiguration configuration = new MemoryGameConfiguration();

        World world = new World();

        world.setRepositoryManager(new RepositoryManager(configuration));
        world.setLoginServerManager(new LoginServerManager(configuration, world));
        world.setGameService(new GameService(configuration, world));

        world.getRepositoryManager().start();
        world.getLoginServerManager().start();
        world.getGameService().start();

        waitForInput();

        world.getGameService().stop();
        world.getLoginServerManager().stop();
        world.getRepositoryManager().stop();
    }

    private static void waitForInput() throws IOException {
        System.in.read();
    }
}
