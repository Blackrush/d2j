package org.d2j.game.service.game.handler;

import org.d2j.common.NetworkStringBuffer;
import org.d2j.common.client.protocol.*;
import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.game.game.actions.ChallengeRequestInvitation;
import org.d2j.game.game.actions.GameActionType;
import org.d2j.game.game.actions.RolePlayMovement;
import org.d2j.game.game.maps.ActorSpeechChange;
import org.d2j.game.game.maps.AddActorChange;
import org.d2j.game.game.maps.MapChange;
import org.d2j.game.game.maps.RemoveActorChange;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.Character;
import org.d2j.game.service.game.GameClient;
import org.d2j.game.service.game.GameClientHandler;
import org.d2j.game.service.game.GameService;

import java.util.Date;
import java.util.Observable;

/**
 * User: Blackrush
 * Date: 05/11/11
 * Time: 12:09
 * IDE:  IntelliJ IDEA
 */
public class RolePlayHandler extends GameClientHandler {
    public static final short ZERO = (short)0;

    public RolePlayHandler(GameService s, GameClient c) {
        super(s, c);

        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession(), 8)) {
            buf.append(ChannelGameMessageFormatter.addChannelMessage(client.getAccount().getEnabledChannels()));
            buf.append(SpellGameMessageFormatter.spellListMessage());
            buf.append(ChannelGameMessageFormatter.enabledEmotesMessage("")); //todo emotes
            buf.append(ApproachGameMessageFormatter.setRestrictionsMessage());

            buf.append(ItemGameMessageFormatter.inventoryStatsMessage(
                    client.getCharacter().getStatistics().getUsedPods(),
                    client.getCharacter().getStatistics().getMaxPods()
            ));
            buf.append(FriendGameMessageFormatter.
                    notifyFriendOnConnectMessage(client.getAccount().isNotifyFriendsOnConnect()));

            buf.append(InfoGameMessageFormatter.welcomeMessage());

            if (client.getAccount().getLastConnection() != null && client.getAccount().getLastAddress() != null) {
                buf.append(InfoGameMessageFormatter.lastConnectionInformationMessage(
                        client.getAccount().getLastConnection(),
                        client.getAccount().getLastAddress()
                ));
            }
            else{
                buf.append(InfoGameMessageFormatter.currentAddressInformationMessage(client.getRemoteAddress()));
            }
        }

        client.getAccount().setLastConnection(new Date());
        client.getAccount().setLastAddress(client.getRemoteAddress());

        client.getAccount().notifyObservers();
    }

    @Override
    public void parse(String packet) throws Exception {
        String[] args;
        switch (packet.charAt(0)){
            case 'B':
                switch (packet.charAt(1)){
                    case 'D':
                        parseCurrentDateRequestMessage();
                        break;

                    case 'M':
                        args = packet.substring(2).split("\\|");
                        if (args[0].length() > 1){
                            Character target = service.getWorld().getRepositoryManager().getCharacters().findByName(args[0]);
                            parseClientPrivateRequestMessage(target, args[1]);
                        }
                        else{
                            parseClientMultiRequestMessage(packet.charAt(2), args[1]);
                        }
                        break;
                }
                break;

            case 'G':
                switch (packet.charAt(1)){
                    case 'A':
                        parseGameActionRequestMessage(
                                ActionTypeEnum.valueOf(Integer.parseInt(packet.substring(2, 5))),
                                packet.substring(5)
                        );
                        break;

                    case 'C':
                        parseGameCreationRequestMessage();
                        break;

                    case 'I':
                        parseGameInformationsRequestMessage();
                        break;

                    case 'K':
                        parseGameActionEndRequestMessage(packet.charAt(2) == 'K', packet.substring(3));
                        break;
                }
                break;
        }
    }

    /**
     * GameClientHandler implementation
     */
    @Override
    public void onClosed() {
        service.getWorld().getLoginServerManager().setAccountDeconnected(client.getAccount().getId());

        client.getCharacter().getCurrentMap().deleteObserver(this);
        client.getCharacter().getCurrentMap().removeActor(client.getCharacter().getId());
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof MapChange){
            update((MapChange)arg);
        }
        else if (arg instanceof RolePlayMovement){
            RolePlayMovement movement = (RolePlayMovement)arg;
            client.getSession().write(GameMessageFormatter.actorMovementMessage(
                    movement.getActor().getId(),
                    movement.getPath()
            ));
        }
    }

    public void update(MapChange arg){
        switch (arg.getChangeType()){
            case ADD_ACTOR:
                client.getSession().write(GameMessageFormatter.showActorMessage(
                        ((AddActorChange) arg).getAddedActor()
                                              .toRolePlayCharacterType()
                ));
                break;

            case REMOVE_ACTOR:
                client.getSession().write(GameMessageFormatter.removeActorMessage(
                        ((RemoveActorChange) arg).getRemovedActor()
                                .getId()
                ));
                break;

            case SPEECH:
                ActorSpeechChange a = (ActorSpeechChange)arg;
                client.getSession().write(ChannelGameMessageFormatter.clientMultiMessage(
                        a.getChannel(),
                        a.getActor().getId(),
                        a.getActor().getName(),
                        a.getMessage()
                ));
                break;
        }
    }

    public String getStatisticsMessage(){
        return GameMessageFormatter.statisticsMessage(
                client.getCharacter().getExperience().getExperience(),
                client.getCharacter().getExperience().min(),
                client.getCharacter().getExperience().max(),
                client.getCharacter().getKamas(),
                client.getCharacter().getStatsPoints(),
                client.getCharacter().getSpellsPoints(),
                0, ZERO, ZERO, 0, 0, false, //todo alignment
                client.getCharacter().getStatistics().getLife(),
                client.getCharacter().getStatistics().getMaxLife(),
                client.getCharacter().getEnergy(),
                service.getConfiguration().getMaxEnergy(),
                client.getCharacter().getStatistics().get(CharacteristicType.Initiative).getTotal(),
                client.getCharacter().getStatistics().get(CharacteristicType.Prospection).getTotal(),
                client.getCharacter().getStatistics()
        );
    }

    public void join(){
        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession())){
            join(buf);
        }
    }

    public void join(NetworkStringBuffer buf){
        buf.append(GameMessageFormatter.gameCreationSuccessMessage());
        buf.append(getStatisticsMessage());
        buf.append(GameMessageFormatter.mapDataMessage(
                client.getCharacter().getCurrentMap().getId(),
                client.getCharacter().getCurrentMap().getDate(),
                client.getCharacter().getCurrentMap().getKey()
        ));
        buf.append(GameMessageFormatter.fightCountMessage(client.getCharacter().getCurrentMap().getNbFights()));
    }

    private void parseGameCreationRequestMessage() throws Exception {
        join();
    }

    private void parseCurrentDateRequestMessage(){
        client.getSession().write(BasicGameMessageFormatter.currentDateMessage(new Date()));
    }

    private void parseGameInformationsRequestMessage() {
        client.getCharacter().getCurrentMap().addActor(client.getCharacter());

        try (NetworkStringBuffer buf = new NetworkStringBuffer(client.getSession(), 3)){
            buf.append(GameMessageFormatter.showActorsMessage(Character.toRolePlayCharacterType(
                    client.getCharacter().getCurrentMap().getActors()
            )));
            buf.append(GameMessageFormatter.mapLoadedMessage());
            buf.append(GameMessageFormatter.fightCountMessage(0)); //todo fights
        }

        client.getCharacter().getCurrentMap().addObserver(this);
    }

    private void parseGameActionRequestMessage(ActionTypeEnum actionId, String args) throws Exception {
        switch (actionId){
            case MOVEMENT:
                parseMovementRequestMessage(args);
                break;

            case ASK_FIGHT:
                parseChallengeRequestMessage(service.getWorld().getRepositoryManager().getCharacters().findById(Long.parseLong(args)));
                break;

            case ACCEPT_FIGHT:
                parseChallengeAcceptRequestMessage();
                break;

            case DECLINE_FIGHT:
                parseChallengeDeclineRequestMessage();
                break;
        }
    }

    private void parseMovementRequestMessage(String path) throws Exception {
        if (client.isBusy()){
            client.getSession().write(BasicGameMessageFormatter.noOperationMessage());
        }
        else{
            RolePlayMovement movement = new RolePlayMovement(path, client);
            client.getActions().push(movement);

            movement.begin();
        }
    }

    private void parseGameActionEndRequestMessage(boolean success, String args) throws Exception {
        if (success){
            client.getActions().pop().end();
        }
        else {
            if (client.getActions().peek().getActionType() != GameActionType.MOVEMENT)
                throw new Exception("invalid action : peeked action isn't a movement");

            ((RolePlayMovement)client.getActions().pop()).cancel(Short.parseShort(args.substring(2)));
        }
    }

    private void parseClientPrivateRequestMessage(Character target, String message) {
        if (target != null){
            target.getOwner().getClient().getSession().write(ChannelGameMessageFormatter.clientPrivateMessage(
                    true,
                    client.getCharacter().getId(),
                    client.getCharacter().getName(),
                    message
            ));

            client.getSession().write(ChannelGameMessageFormatter.clientPrivateMessage(
                    false,
                    client.getCharacter().getId(),
                    client.getCharacter().getName(),
                    message
            ));
        }
        else{
            client.getSession().write(ChannelGameMessageFormatter.clientMultiErrorMessage());
        }
    }

    private void parseClientMultiRequestMessage(char channel, String message) {
        switch (channel){
            case '*':
                client.getCharacter().getCurrentMap().speak(channel, message, client.getCharacter());
                break;
        }
    }

    private void parseChallengeRequestMessage(Character target) throws Exception {
        if (target == null)
            throw new Exception("unknown target");

        GameClient targetClient = target.getOwner().getClient();
        if (!client.getCharacter().getCurrentMap().canFight()){
            client.log("Impossible de combattre sur cette map.");
        }
        else if (targetClient.isBusy() || client.isBusy()){
            client.log("La cible est occupée.");
        }
        else if (target.getCurrentMap() != client.getCharacter().getCurrentMap()){
            client.log("La cible n'est pas sur la même map que vous.");
        }
        else{
            ChallengeRequestInvitation invitation = new ChallengeRequestInvitation(client, targetClient);
            client.getActions().push(invitation);
            targetClient.getActions().push(invitation);

            invitation.begin();
        }
    }

    private void parseChallengeAcceptRequestMessage() throws Exception {
        if (client.getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION)
            throw new Exception("Bad request: current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");

        ChallengeRequestInvitation invitation = (ChallengeRequestInvitation)client.getActions().pop();

        if (invitation.getSender() == client)
            throw new Exception("Bad request: sender can't accept challenge.");

        if (invitation.getSender().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION)
            throw new Exception("Bad request: target's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");

        invitation.getSender().getActions().pop();

        invitation.accept();
    }

    private void parseChallengeDeclineRequestMessage() throws Exception {
        if (client.getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
            throw new Exception("Bad request: current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
        }

        ChallengeRequestInvitation invitation = (ChallengeRequestInvitation) client.getActions().pop();

        if (invitation.getSender() == client){
            if (invitation.getTarget().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
                throw new Exception("Bad request: target's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
            }
            invitation.getTarget().getActions().pop();
        }
        else{
            if (invitation.getSender().getActions().peek().getActionType() != GameActionType.CHALLENGE_REQUEST_INVITATION){
                throw new Exception("Bad request: sender's current action isn't a [" + GameActionType.CHALLENGE_REQUEST_INVITATION + "].");
            }
            invitation.getSender().getActions().pop();
        }

        invitation.decline();
    }
}
