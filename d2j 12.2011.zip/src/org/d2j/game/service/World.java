package org.d2j.game.service;

import org.d2j.common.client.protocol.enums.WorldStateEnum;
import org.d2j.game.repository.RepositoryManager;
import org.d2j.game.service.game.GameService;
import org.d2j.game.service.login.LoginServerManager;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 18:28
 * IDE : IntelliJ IDEA
 */
public class World {
    private LoginServerManager loginServerManager;
    private RepositoryManager repositoryManager;
    private GameService gameService;
    private WorldStateEnum state;
    private int completion;

    public World() {
        state = WorldStateEnum.ONLINE;
        completion = 0;
    }

    public LoginServerManager getLoginServerManager() {
        return loginServerManager;
    }

    public void setLoginServerManager(LoginServerManager loginServerManager) {
        this.loginServerManager = loginServerManager;
    }

    public RepositoryManager getRepositoryManager() {
        return repositoryManager;
    }

    public void setRepositoryManager(RepositoryManager repositoryManager) {
        this.repositoryManager = repositoryManager;
    }

    public GameService getGameService() {
        return gameService;
    }

    public void setGameService(GameService gameService) {
        this.gameService = gameService;
    }

    public WorldStateEnum getState() {
        return state;
    }

    public void setState(WorldStateEnum state) {
        this.state = state;
        if (loginServerManager != null && loginServerManager.isSynchronized()){
            loginServerManager.refreshWorld();
        }
    }

    public int getCompletion() {
        return completion;
    }

    public void setCompletion(int completion) {
        this.completion = completion;
        if (loginServerManager != null && loginServerManager.isSynchronized()){
            loginServerManager.refreshWorld();
        }
    }
}
