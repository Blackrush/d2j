package org.d2j.game.game.fights;

import org.d2j.common.client.protocol.enums.FightStateEnum;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/**
 * User: Blackrush
 * Date: 16/11/11
 * Time: 09:08
 * IDE : IntelliJ IDEA
 */
public class Team {
    private final Fight fight;
    private final FightTeamEnum teamType;
    private final String places;

    private HashMap<Long, IFighter> fighters = new HashMap<>();
    private int availablePlaces;

    public Team(Fight fight, FightTeamEnum teamType, String places) {
        this.fight = fight;
        this.teamType = teamType;
        this.places = places;

        for (int i = 0; i < fight.getCells().length; ++i){
            if (fight.getCells()[i].getStartCell() == this.teamType) {
                this.availablePlaces++;
            }
        }
    }

    public FightTeamEnum getTeamType() {
        return teamType;
    }

    public int getNbFighters() {
        return fighters.size();
    }

    public String getPlaces() {
        return places;
    }

    public void addFighter(IFighter fighter) throws IndexOutOfBoundsException, FightException {
        if (availablePlaces <= 0){
            throw new IndexOutOfBoundsException("There is no more available places in this team.");
        }

        --availablePlaces;
        fighters.put(fighter.getId(), fighter);

        fighter.setTeam(this);
        fighter.setCurrentCell(FightCell.getFirstAvailableStartCell(teamType, fight.getCells()));

        if (fight.getState() != FightStateEnum.INIT){
            fighter.getHandler().notifyFightJoin(
                    fight.getTeam(FightTeamEnum.CHALLENGER),
                    fight.getTeam(FightTeamEnum.DEFENDER)
            );

            fight.notifyShowFighter(fighter);
        }
    }

    public IFighter removeFighter(long id) throws IndexOutOfBoundsException {
        IFighter fighter = fighters.remove(id);

        if (fighter != null)
            ++availablePlaces;

        return fighter;
    }

    public IFighter getFighter(long id) throws IndexOutOfBoundsException {
        return fighters.get(id);
    }

    public IFighter getLeader() {
        return fighters.values().iterator().next();
    }

    public Collection<IFighter> getFighters(){
        return fighters.values();
    }

    public boolean isReady(){
        if (fighters.isEmpty()){
            return false;
        }

        Iterator<IFighter> it = fighters.values().iterator();
        boolean ready = it.next().isReady();
        while (it.hasNext()){
            ready = ready && it.next().isReady();
        }

        return ready;
    }

    public boolean isEmpty(){
        return fighters.isEmpty();
    }
}
