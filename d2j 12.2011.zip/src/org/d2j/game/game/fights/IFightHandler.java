package org.d2j.game.game.fights;

import org.d2j.common.client.protocol.enums.ActionTypeEnum;
import org.d2j.common.client.protocol.enums.EndActionTypeEnum;
import org.d2j.game.game.fights.actions.FightMovement;
import org.d2j.game.game.fights.actions.Turn;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 18/11/11
 * Time: 17:21
 * IDE : IntelliJ IDEA
 */
public interface IFightHandler {
    void notifyFightJoin(Team challengers, Team defenders) throws FightException;
    void notifyFighterReady(IFighter fighter) throws FightException;
    void notifyShowFighter(IFighter fighter) throws FightException;
    void notifyShowFighters(Collection<IFighter> fighters) throws FightException;
    void notifyFighterPlacement(IFighter fighter) throws FightException;
    void notifyFighterQuit(IFighter fighter) throws FightException;
    void notifyQuit() throws FightException;
    void notifyFightStart(Collection<Turn> turns, Collection<IFighter> fighters) throws FightException;
    void notifyTurnStart(Turn turn) throws FightException;
    void notifyTurnStop(Turn turn) throws FightException;
    void notifyFighterMovement(FightMovement movement) throws FightException;
    void notifyBasicAction(ActionTypeEnum actionType, IFighter fighter, int arg) throws FightException;
    void notifyBasicAction(ActionTypeEnum actionType, IFighter fighter, int arg1, int arg2) throws FightException;
    void notifyEndAction(EndActionTypeEnum action, IFighter fighter) throws FightException;
    void notifyRefreshStatistics() throws FightException;
    void notifyFightersInformations(Collection<IFighter> fighters) throws FightException;
}
