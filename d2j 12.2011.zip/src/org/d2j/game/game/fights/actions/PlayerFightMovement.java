package org.d2j.game.game.fights.actions;

import org.d2j.common.client.protocol.enums.EndActionTypeEnum;
import org.d2j.game.game.fights.Fight;
import org.d2j.game.game.fights.FightException;
import org.d2j.game.game.fights.IFightHandler;
import org.d2j.game.game.fights.IFighter;
import org.d2j.game.game.maps.Cell;
import org.d2j.game.game.pathfinding.PathfindingException;

/**
 * User: Blackrush
 * Date: 24/11/11
 * Time: 18:03
 * IDE : IntelliJ IDEA
 */
public class PlayerFightMovement extends FightMovement {
    public PlayerFightMovement(Fight fight, IFighter fighter, Cell start, Cell end) throws PathfindingException {
        super(fight, fighter, start, end);
    }

    @Override
    public boolean isNPC() {
        return false;
    }

    @Override
    public void notifyEnd(IFightHandler handler) throws FightException {
        super.notifyEnd(handler);
        handler.notifyEndAction(EndActionTypeEnum.MOVEMENT, getFighter());
    }
}
