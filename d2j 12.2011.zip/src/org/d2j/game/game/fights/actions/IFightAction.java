package org.d2j.game.game.fights.actions;

import org.d2j.game.game.fights.FightException;
import org.d2j.game.game.fights.IFightHandler;
import org.d2j.game.game.fights.IFighter;

/**
 * User: Blackrush
 * Date: 24/11/11
 * Time: 17:56
 * IDE : IntelliJ IDEA
 */
public interface IFightAction {
    void begin() throws FightException;
    void end() throws FightException;

    void notifyBegin(IFightHandler handler) throws FightException;
    void notifyEnd(IFightHandler handler) throws FightException;

    IFighter getFighter();
}
