package org.d2j.game.game.fights;

import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.common.client.protocol.type.BaseFighterType;
import org.d2j.game.game.statistics.IStatistics;

import java.util.Collection;

/**
 * User: Blackrush
 * Date: 16/11/11
 * Time: 09:24
 * IDE : IntelliJ IDEA
 */
public interface IFighter {
    long getId();

    boolean isReady();
    Team getTeam();
    void setTeam(Team team);

    FightCell getCurrentCell();
    void setCurrentCell(FightCell currentCellId);

    OrientationEnum getCurrentOrientation();

    IStatistics getStatistics();
    boolean isAlive();

    IFightHandler getHandler();

    BaseFighterType toBaseFighterType();
}
