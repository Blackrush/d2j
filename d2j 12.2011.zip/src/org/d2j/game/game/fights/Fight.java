package org.d2j.game.game.fights;

import org.d2j.common.CollectionUtils;
import org.d2j.common.client.protocol.enums.FightStateEnum;
import org.d2j.common.client.protocol.enums.FightTypeEnum;
import org.d2j.game.configuration.IGameConfiguration;
import org.d2j.game.game.fights.actions.IFightAction;
import org.d2j.game.game.fights.actions.Turn;
import org.d2j.game.game.statistics.CharacteristicType;
import org.d2j.game.model.Map;
import org.d2j.utils.Action;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.util.*;

/**
 * User: Blackrush
 * Date: 14/11/11
 * Time: 20:36
 * IDE : IntelliJ IDEA
 */
public class Fight {
    private final IGameConfiguration configuration;
    private final Map map;
    private final FightTypeEnum type;
    private final FightCell[] cells;
    private final Team challengers, defenders;
    private final long preparationDeadline;
    private final Timer preparationTimer;
    private Queue<Turn> turns;
    private Collection<IFighter> fighters;

    private FightStateEnum state;

    public Fight(IGameConfiguration configuration, Map map, FightTypeEnum type) {
        this.configuration = configuration;
        this.map = map;
        this.type = type;
        this.cells = FightCell.toFightCell(map.getCells(), map.getPlaces());

        this.preparationDeadline = System.currentTimeMillis() + this.configuration.getPreparationDelay() * 1000;
        this.preparationTimer = new Timer(this.configuration.getPreparationDelay() * 1000, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    start();
                } catch (FightException e1) {
                    e1.printStackTrace();
                }
            }
        });

        String[] places = map.getPlaces().split("\\|");
        this.challengers = new Team(this, FightTeamEnum.CHALLENGER, places[0]);
        this.defenders = new Team(this, FightTeamEnum.DEFENDER, places[1]);

        this.state = FightStateEnum.INIT;
    }

    public static final int MAX_EXCEPTIONS_ALLOWED = 4;
    private void foreach(Action<IFighter> action) throws FightException {
        int exceptions = 0;

        for (IFighter challenger : challengers.getFighters()){
            try {
                action.call(challenger);
            } catch (Exception e) {
                ++exceptions;
                throw new FightException(e);
            }

            if (exceptions >= MAX_EXCEPTIONS_ALLOWED)
                break;
        }
        for (IFighter defender : defenders.getFighters()){
            try {
                action.call(defender);
            } catch (Exception e) {
                ++exceptions;
                throw new FightException(e);
            }

            if (exceptions >= MAX_EXCEPTIONS_ALLOWED)
                break;
        }
    }

    private void generateTurns(){
        LinkedList<Turn> lTurns = new LinkedList<>();

        for (IFighter fighter : challengers.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }
        for (IFighter fighter : defenders.getFighters()){
            lTurns.add(new Turn(fighter, this));
        }

        Collections.sort(lTurns, new Comparator<Turn>() {
            @Override
            public int compare(Turn o1, Turn o2) {
                return o2.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal() -
                        o1.getFighter().getStatistics().get(CharacteristicType.Initiative).getTotal();
            }
        });

        turns = lTurns;
    }

    public IGameConfiguration getConfiguration() {
        return configuration;
    }

    public Map getMap() {
        return map;
    }

    public FightStateEnum getState() {
        return state;
    }

    public FightTypeEnum getFightType() {
        return type;
    }

    public FightCell[] getCells() {
        return cells;
    }

    public Team getTeam(FightTeamEnum teamType){
        switch (teamType){
            case CHALLENGER:
                return challengers;
            case DEFENDER:
                return defenders;
            default:
                return null;
        }
    }

    public int remainingTime() {
        return type == FightTypeEnum.CHALLENGE ?
                -1 :
                (int) (System.currentTimeMillis() - preparationDeadline);
    }

    public Turn getCurrentTurn(){
        return turns.peek();
    }

    public void init() throws FightException {
        state = FightStateEnum.PLACE;

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFightJoin(
                        challengers,
                        defenders
                );
            }
        });

        if (type != FightTypeEnum.CHALLENGE){
            preparationTimer.start();
        }
    }

    public void start() throws FightException {
        state = FightStateEnum.ACTIVE;

        preparationTimer.stop();

        //todo remove blades

        generateTurns();

        fighters = CollectionUtils.concat(challengers.getFighters(), defenders.getFighters());

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFightStart(turns, fighters);
            }
        });

        turns.peek().begin();
    }

    public void stop() throws FightException {
        FightStateEnum oldState = state;
        state = FightStateEnum.FINISHED;

        if (oldState == FightStateEnum.PLACE){
            foreach(new Action<IFighter>() {
                @Override
                public void call(IFighter obj) throws Exception {
                    obj.getHandler().notifyQuit();
                }
            });
        }
        else if (oldState == FightStateEnum.ACTIVE){
            //todo
        }
    }

    public void nextTurn() throws FightException {
        Turn turn = turns.poll();
        if (turn.isValid()){
            turns.add(turn);
        }

        turns.peek().begin();
    }

    public void notifyReady(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE)
            throw new FightException("Bad request: fight's state is [" + state + "] and must be [" + FightStateEnum.PLACE + "].");

        try{
            if (challengers.isReady() && defenders.isReady()){
                start();
            }
            else{
                foreach(new Action<IFighter>() {
                    @Override
                    public void call(IFighter obj) throws Exception {
                        obj.getHandler().notifyFighterReady(fighter);
                    }
                });
            }
        }
        catch (Exception e){
            throw new FightException(e);
        }
    }

    public void notifyShowFighter(final IFighter fighter) throws FightException {
        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                if (fighter != obj)
                    obj.getHandler().notifyShowFighter(fighter);
            }
        });
    }

    public void notifyFighterPlacement(final IFighter fighter) throws FightException {
        if (state != FightStateEnum.PLACE)
            throw new FightException("Bad request: fight's state is [" + state + "] and must be [" + FightStateEnum.PLACE + "].");

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFighterPlacement(fighter);
            }
        });
    }

    public void notifyFighterQuit(final IFighter fighter) throws FightException {
        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFighterQuit(fighter);
            }
        });

        if (challengers.isEmpty() || defenders.isEmpty()){
            stop();
        }
    }

    public void notifyBeginAction(final IFightAction action) throws FightException {
        if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: the fight isn't started or is stoped.");
        }

        if (turns.peek().getFighter() != action.getFighter()){
            throw new FightException("FATAL ERROR: it isn't your turn!");
        }

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                action.notifyBegin(obj.getHandler());
            }
        });
    }

    public void notifyEndAction(final IFightAction action) throws FightException {
        if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: the fight isn't started or is stoped.");
        }

        if (turns.peek().getFighter() != action.getFighter()){
            throw new FightException("FATAL ERROR: it isn't your turn!");
        }

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                action.notifyEnd(obj.getHandler());
            }
        });
    }

    public void notifyBeginTurn(final Turn turn) throws FightException {
        if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: the fight isn't started or is stoped.");
        }

        if (turn != turns.peek()){
            throw new FightException("Invalid request: it isn't your turn!");
        }

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyTurnStart(turn);
            }
        });
    }

    public void notifyEndTurn(final Turn turn) throws FightException {
        if (state != FightStateEnum.ACTIVE){
            throw new FightException("Invalid request: the fight isn't started or is stoped.");
        }

        if (turn != turns.peek()){
            throw new FightException("Invalid request: it isn't your turn!");
        }

        foreach(new Action<IFighter>() {
            @Override
            public void call(IFighter obj) throws Exception {
                obj.getHandler().notifyFightersInformations(fighters);
                obj.getHandler().notifyTurnStop(turn);
            }
        });
    }
}
