package org.d2j.game.game.maps;

import org.d2j.game.model.Character;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 14:09
 * IDE : IntelliJ IDEA
 */
public class AddActorChange implements MapChange {
    private Character addedActor;

    public AddActorChange(Character addedActor) {
        this.addedActor = addedActor;
    }

    @Override
    public MapChangeType getChangeType() {
        return MapChangeType.ADD_ACTOR;
    }

    public Character getAddedActor() {
        return addedActor;
    }
}
