package org.d2j.game.game.maps;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 14:07
 * IDE : IntelliJ IDEA
 */
public enum MapChangeType {
    ADD_ACTOR,
    REMOVE_ACTOR,
    MOVEMENT,
    SPEECH,
}
