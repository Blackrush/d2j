package org.d2j.game.game.maps;

import org.d2j.game.model.Character;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 14:10
 * IDE : IntelliJ IDEA
 */
public class RemoveActorChange implements MapChange {
    private Character removedActor;

    public RemoveActorChange(Character removedActor) {
        this.removedActor = removedActor;
    }

    @Override
    public MapChangeType getChangeType() {
        return MapChangeType.REMOVE_ACTOR;
    }

    public Character getRemovedActor() {
        return removedActor;
    }
}
