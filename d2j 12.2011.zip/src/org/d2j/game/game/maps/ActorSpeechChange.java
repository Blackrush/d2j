package org.d2j.game.game.maps;

import org.d2j.game.model.*;
import org.d2j.game.model.Character;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 19:22
 * IDE : IntelliJ IDEA
 */
public class ActorSpeechChange implements MapChange {
    private Character actor;
    private char channel;
    private String message;

    public ActorSpeechChange(char channel, String message, Character actor) {
        this.channel = channel;
        this.message = message;
        this.actor = actor;
    }

    @Override
    public MapChangeType getChangeType() {
        return MapChangeType.SPEECH;
    }

    public char getChannel() {
        return channel;
    }

    public void setChannel(char channel) {
        this.channel = channel;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Character getActor() {
        return actor;
    }

    public void setActor(Character actor) {
        this.actor = actor;
    }
}
