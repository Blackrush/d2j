package org.d2j.game.game.pathfinding;

import java.util.ArrayList;

/**
 * User: Blackrush
 * Date: 26/11/11
 * Time: 20:18
 * IDE : IntelliJ IDEA
 */
public class NodeList extends ArrayList<Node> {
    public boolean contains(Node node){
        return contains(node.getId());
    }

    public boolean contains(short id){
        for (Node node : this) {
            if (node.getId() == id) {
                return true;
            }
        }
        return false;
    }

    public Node removeFirst(){
        Node first = get(0);
        remove(0);
        return first;
    }
}
