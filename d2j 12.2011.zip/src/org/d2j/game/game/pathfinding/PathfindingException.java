package org.d2j.game.game.pathfinding;

/**
 * User: Blackrush
 * Date: 30/11/11
 * Time: 17:02
 * IDE : IntelliJ IDEA
 */
public class PathfindingException extends Exception {
    public PathfindingException() {
    }

    public PathfindingException(String message) {
        super(message);
    }
}
