package org.d2j.game.game.pathfinding;

import org.d2j.common.client.protocol.enums.OrientationEnum;
import org.d2j.game.game.maps.Cell;
import org.d2j.utils.Point;

import java.util.*;

/**
 * User: Blackrush
 * Date: 26/11/11
 * Time: 20:25
 * IDE : IntelliJ IDEA
 */
public class Pathfinding {
    public static Point position(short nNum, int _loc4) {
        double _loc5 = Math.floor(nNum / (_loc4 * 2 - 1)),
               _loc6 = nNum - _loc5 * (_loc4 * 2 - 1),
               _loc7 = _loc6 % _loc4;

        Point result = new Point();
        result.setY((int) (_loc5 - _loc7));
        result.setX(nNum - (_loc4 - 1) * result.getY() / _loc4);

        return result;
    }

    public static int distanceBetween(Point p1, Point p2){
        return Math.abs(p1.getX() - p2.getX()) +
               Math.abs(p1.getY() - p2.getY());
    }

    public static int estimateTime(int steps){
        return 900 + steps * 100;
    }

    private static void computeG(Point start, Node node){
        node.setG(distanceBetween(start, node.getPosition()));
    }

    private static void computeH(Point end, Node node){
        node.setH(distanceBetween(node.getPosition(), end));
    }

    private static Cell getCellByOrientation(int mapWidth, int mapHeight, Cell[] cells, Node node, OrientationEnum direction){
        switch (direction)
        {
            case EAST:
                return node.getPosition().getX() == mapWidth * 2 - 2 || node.getPosition().getX() == mapWidth - 1 ? null : cells[node.getId() + 1];
            case SOUTH_EAST:
                return node.getPosition().getX() == mapWidth * 2 - 2 || node.getPosition().getX() == mapWidth - 1 && node.getPosition().getY() == mapHeight - 1 ? null : cells[node.getId() + mapWidth];
            case SOUTH:
                return node.getPosition().getY() == mapHeight - 1 ? null : cells[node.getId() + ( mapWidth * 2 - 1 )];
            case SOUTH_WEST:
                return node.getPosition().getX() == 0 && node.getPosition().getY() == mapHeight - 1 ? null : cells[node.getId() + ( mapWidth - 1 )];
            case WEST:
                return node.getPosition().getX() == 0 || node.getPosition().getX() == mapWidth ? null : cells[node.getId() - 1];
            case NORTH_WEST:
                return node.getPosition().getX() == 0 && node.getPosition().getY() == 0 ? null : cells[node.getId() - mapWidth];
            case NORTH:
                return node.getPosition().getY() == 0 ? null : cells[node.getId() - ( mapWidth * 2 - 1 )];
            case NORTH_EAST:
                return node.getPosition().getX() == mapWidth * 2 - 2 || node.getPosition().getX() == mapWidth - 1 && node.getPosition().getY() == 0 ? null : cells[node.getId() - mapWidth + 1];
            default:
                throw new IllegalArgumentException("Unknown direction");
        }
    }

    private static Collection<Node> adjacentNodes(int mapWidth, int mapHeight, Cell[] cells, Node node){
        return Arrays.asList(
                new Node(node, OrientationEnum.NORTH_EAST, getCellByOrientation(mapWidth, mapHeight, cells, node, OrientationEnum.NORTH_EAST)),
                new Node(node, OrientationEnum.SOUTH_EAST, getCellByOrientation(mapWidth, mapHeight, cells, node, OrientationEnum.SOUTH_EAST)),
                new Node(node, OrientationEnum.SOUTH_WEST,  getCellByOrientation(mapWidth, mapHeight, cells, node, OrientationEnum.SOUTH_WEST)),
                new Node(node, OrientationEnum.NORTH_WEST,  getCellByOrientation(mapWidth, mapHeight, cells, node, OrientationEnum.NORTH_WEST))
        );
    }

    private static List<Node> getPath(NodeList close){
        List<Node> nodes = new ArrayList<>(close.size());
        Node last = close.get(close.size() - 1);
        while (last.getParent() != null){
            nodes.add(last);
            last = last.getParent();
        }
        Collections.reverse(nodes);
        return nodes;
    }

    public static List<Node> bestPath(int mapWidth, int mapHeight, OrientationEnum pCurrentOrientation, Cell[] pCells, Cell pStart, Cell pEnd) throws PathfindingException {
        if (!pStart.isWalkable() || !pEnd.isWalkable()){
            throw new IllegalArgumentException("pStart or pEnd isn't walkable.");
        }

        NodeList open  = new SortedNodeList(),
                 close = new NodeList();

        Node start = new Node(pStart.getId(), pStart.getPosition(), true, pCurrentOrientation),
             end   = new Node(pEnd.getId(),   pEnd.getPosition());

        open.add(start);

        while (!close.contains(pEnd.getId()) && !open.isEmpty()){
            Node best = open.removeFirst();
            close.add(best);

            if (best.equals(end)) break;

            for (Node node : adjacentNodes(mapWidth, mapHeight, pCells, best)){
                if (node.isWalkable() && !close.contains(node) && !open.contains(node)){
                    computeG(start.getPosition(), node);
                    computeH(end.getPosition(),   node);

                    open.add(node);
                }
            }

            if (open.isEmpty()){
                throw new PathfindingException("no solutions.");
            }
        }

        return getPath(close);
    }
}
