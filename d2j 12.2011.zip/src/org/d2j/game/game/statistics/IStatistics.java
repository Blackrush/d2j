package org.d2j.game.game.statistics;

/**
 * User: Blackrush
 * Date: 12/11/11
 * Time: 10:43
 * IDE : IntelliJ IDEA
 */
public interface IStatistics {
    ICharacteristic get(CharacteristicType type);

    short getLife();
    void setLife(short life);

    short getMaxLife();

    short getUsedPods();
    short getMaxPods();

    void reset();
    void resetContext();

    void refresh();
    IStatistics copy();
}
