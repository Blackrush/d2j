package org.d2j.game.game.actions;

/**
 * User: Blackrush
 * Date: 13/11/11
 * Time: 15:16
 * IDE : IntelliJ IDEA
 */
public enum GameActionType {
    MOVEMENT,
    CHALLENGE_REQUEST_INVITATION,
}
