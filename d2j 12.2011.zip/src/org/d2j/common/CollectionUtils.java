package org.d2j.common;

import org.d2j.utils.Selector;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: Blackrush
 * Date: 22/11/11
 * Time: 19:28
 * IDE : IntelliJ IDEA
 */
public class CollectionUtils {
    public static <TIn, TOut> Collection<TOut> select(Collection<TIn> objs, Selector<TIn, TOut> selector){
        List<TOut> selected = new ArrayList<>(objs.size());

        for (TIn obj : objs){
            selected.add(selector.select(obj));
        }

        return selected;
    }

    public static <T> List<T> concat(Collection<T> first, Collection<T> second){
        List<T> objs = new ArrayList<>();
        objs.addAll(first);
        objs.addAll(second);

        return objs;
    }

    public static <T> T last(List<T> list){
        return list.isEmpty() ? null : list.get(list.size() - 1);
    }
}
