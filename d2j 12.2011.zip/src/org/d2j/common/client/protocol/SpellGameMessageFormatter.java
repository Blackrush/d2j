package org.d2j.common.client.protocol;

/**
 * User: Blackrush
 * Date: 06/11/11
 * Time: 10:09
 * IDE:  IntelliJ IDEA
 */
public class SpellGameMessageFormatter {
    public static String spellListMessage(){
        return "SL";
    }
}
