package org.d2j.common.client.protocol;

import org.d2j.common.StringUtil;
import org.d2j.common.client.protocol.type.BaseCharacterType;

import java.text.MessageFormat;
import java.util.Collection;

/**
 * User: Blackrush
 * Date: 01/11/11
 * Time: 18:08
 * IDE : IntelliJ IDEA
 */
public class ApproachGameMessageFormatter {
    public static String helloGameMessage(){
        return "HG";
    }

    public static String authenticationSuccessMessage(int community){
        return "ATK" + community;
    }

    public static String authenticationFailureMessage(){
        return "ATE";
    }

    public static String regionalVersionResponseMessage(int community){
        return "AV" + community;
    }

    public static String charactersListMessage(int serverId, long remainingSubscriptionTime, Collection<BaseCharacterType> characters){
        StringBuilder sb = new StringBuilder(50);
        sb.append("ALK" + remainingSubscriptionTime).append("|")
          .append(characters.size());

        for (BaseCharacterType character : characters){
            sb.append("|");

            sb.append(character.getId()).append(";")
              .append(character.getName()).append(";")
              .append(character.getLevel()).append(";")
              .append(character.getSkin()).append(";")
              .append(StringUtil.toHexOrNegative(character.getColor1())).append(";")
              .append(StringUtil.toHexOrNegative(character.getColor2())).append(";")
              .append(StringUtil.toHexOrNegative(character.getColor3())).append(";");

            boolean first = true;
            for (int accessory : character.getAccessories()){
                if (first) first = false;
                else sb.append(',');
                sb.append(accessory == 0 ? "" : StringUtil.toHex(accessory));
            }

            sb.append(";0;") // seller ?
              .append(serverId).append(';')
              .append(';') // is dead ?  (heroic)
              .append(';') // nb deathes (heroic)
              .append("");            // level max
        }
        return sb.toString();
    }

    public static String characterNameSuggestionSuccessMessage(String name){
        return "APK" + name;
    }

    public static String characterNameSuggestionFailureMessage(){
        return "APE";
    }

    public static String accountFullMessage()
    {
        return "AAEf";
    }

    public static String characterNameAlreadyExistsMessage()
    {
        return "AAEa";
    }

    public static String characterCreationSuccessMessage(){
        return "AAK";
    }

    public static String characterDeletionFailureMessage(){
        return "ADE";
    }

    public static String characterSelectionFailureMessage(){
        return "ASE";
    }

    public static String characterSelectionSucessMessage(long id, String name, int level, int breedId, boolean gender,
                                                         short skin, int color1, int color2, int color3){
        return MessageFormat.format(
                "ASK|{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}",
                id,
                name,
                level,
                breedId,
                gender ? "1" : "0",
                skin,
                StringUtil.toHexOrNegative(color1),
                StringUtil.toHexOrNegative(color2),
                StringUtil.toHexOrNegative(color3),
                "" // todo items
        );
    }

    public static String setRestrictionsMessage(){
        return "AR6bk"; // 6bk(base 36) todo
    }
}
