package org.d2j.utils.database;

/**
 * User: Blackrush
 * Date: 31/10/11
 * Time: 14:42
 * IDE : IntelliJ IDEA
 */
public interface IBaseEntityRepository<T extends IBaseEntity<TKey>, TKey> {
    long loadAll() throws LoadingException;
    T loadOne(TKey id) throws LoadingException;

    boolean isLoaded();
    T findById(TKey id);
}
