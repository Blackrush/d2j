package org.d2j.utils.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 00:42
 * IDE : IntelliJ IDEA
 */
public abstract class BaseEntityRepository<T extends IBaseEntity<TKey>, TKey>
    implements IBaseEntityRepository<T, TKey>
{
    private boolean loaded;

    protected final EntitiesContext context;
    protected Map<TKey, T> entities = new HashMap<>();

    protected BaseEntityRepository(EntitiesContext context){
        this.context = context;
    }

    protected abstract String getLoadQuery();
    protected abstract String getLoadOneQuery(TKey id);

    protected abstract T loadOne(ResultSet reader) throws SQLException;

    protected void beforeLoading() throws LoadingException {
    }

    protected void afterLoading(){

    }

    public long loadAll() throws LoadingException {
        beforeLoading();

        context.query(new Query() {
            public void query(Statement statement) throws Exception {
                ResultSet results = statement.executeQuery(getLoadQuery());
                while (results.next()){
                    T entity = loadOne(results);
                    if (entity != null)
                        entities.put(entity.getId(), entity);
                }
                results.close();
            }
        });

        loaded = true;

        afterLoading();

        return entities.size();
    }

    public long loadAll(final long limit) throws LoadingException {
        beforeLoading();

        if (limit <= 0)
            return loadAll();

        context.query(new Query() {
            public void query(Statement statement) throws Exception {
                ResultSet results = statement.executeQuery(getLoadQuery());
                for (int i = 0; i < limit && results.next(); ++i){
                    T entity = loadOne(results);
                    entities.put(entity.getId(), entity);
                }
                results.close();
            }
        });

        loaded = true;

        afterLoading();

        return entities.size();
    }

    public synchronized T loadOne(final TKey id) throws LoadingException {
        beforeLoading();

        T entity = context.query(new ReturnQuery<T>() {
            public T query(Statement statement) throws Exception {
                ResultSet result = statement.executeQuery(getLoadOneQuery(id));
                result.beforeFirst();
                if (!result.next())
                    return null;
                return loadOne(result);
            }
        });

        if (entity != null){
            entities.put(entity.getId(), entity);
        }

        loaded = true;

        afterLoading();

        return entity;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public synchronized T findById(TKey id){
        return entities.get(id);
    }

    public synchronized boolean contains(TKey id){
        return entities.containsKey(id);
    }

    public Collection<T> all(){
        return entities.values();
    }
}
