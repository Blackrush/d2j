package org.d2j.utils.database;

import java.sql.SQLException;

/**
 * User: Blackrush
 * Date: 30/10/11
 * Time: 09:08
 * IDE : IntelliJ IDEA
 */
public abstract class SaveableEntityRepository<T extends ISaveableEntity<TKey>, TKey> extends BaseEntityRepository<T, TKey> {
    protected SaveableEntityRepository(EntitiesContext context) {
        super(context);
    }

    protected abstract String getSaveQuery(T entity);

    public void save(T entity){
        entity.beforeSave();
        context.execute(getSaveQuery(entity));
        entity.onSaved();
    }

    public long saveAll() throws SQLException {
        for (T entity : entities.values()){
            entity.beforeSave();
            context.execute(getSaveQuery(entity));
            entity.onSaved();
        }
        return entities.size();
    }
}
