package org.d2j.login.service.login;

import org.d2j.common.StringUtil;
import org.d2j.common.crypto.PasswordCipher;

/**
 * User: Blackrush
 * Date: 29/10/11
 * Time: 21:31
 * IDE : IntelliJ IDEA
 */
public class DofusPasswordCipher extends PasswordCipher {
    @Override
    protected String makeTicket() {
        return StringUtil.random(32);
    }

    @Override
    public String getEncryptedPassword(String clearPassword) {
        StringBuilder encrypted = new StringBuilder();

        for ( int i = 0; i < clearPassword.length(); i++ )
        {
            char ppass = clearPassword.charAt(i);
            char pkey = ticket.charAt(i);

            int apass = ppass / 16;
            int akey = ppass % 16;

            int anb = ( apass + pkey ) % StringUtil.HASH.length();
            int anb2 = ( akey + pkey ) % StringUtil.HASH.length();

            encrypted.append(StringUtil.HASH.charAt(anb));
            encrypted.append(StringUtil.HASH.charAt(anb2));
        }
        return encrypted.toString();
    }
}
