package org.d2j.login;

import org.apache.mina.core.buffer.IoBuffer;
import org.d2j.common.service.protocol.MessageFactory;
import org.d2j.common.service.protocol.messages.HelloConnectMessage;
import org.d2j.login.configuration.ILoginConfiguration;
import org.d2j.login.configuration.MemoryLoginConfiguration;
import org.d2j.login.repository.RepositoryManager;
import org.d2j.login.service.game.GameServerManager;
import org.d2j.login.service.login.DofusPasswordCipher;
import org.d2j.login.service.login.LoginService;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * User: Blackrush
 * Date: 29/10/11
 * Time: 16:49
 * IDE : IntelliJ IDEA
 */

public class Main {

    public static void main(String[] args) throws Exception {
        MessageFactory.getInstance().init();
        ILoginConfiguration configuration = new MemoryLoginConfiguration();

        RepositoryManager repositoryManager = new RepositoryManager(configuration);
        GameServerManager gameServerManager = new GameServerManager(configuration, repositoryManager);
        LoginService service = new LoginService(configuration, repositoryManager, gameServerManager);

        repositoryManager.start();
        gameServerManager.start();
        service.start();

        waitForInput();

        service.stop();
        gameServerManager.stop();
        repositoryManager.stop();
    }

    private static void waitForInput(){
        try {
            System.in.read();
        } catch (IOException e) { }
    }
}
